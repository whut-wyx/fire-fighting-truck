#ifndef MYDATAPROCESS_H
#define MYDATAPROCESS_H

#include <QList>
#include "myapp.h"

typedef unsigned char INT8U;
typedef unsigned short INT16U;
typedef unsigned int INT32U;

enum smartUpdateData{
    SUBSTATAUS = 1,
    CARINFO = 2,
    TOOLINFO = 4,
    BOXDOORINFO = 8,
    RANGEINFO = 16,
    LIQUIDINFO = 32,
    PHOTOINFO = 64,
};

//数据上报 命令码0x4005
typedef struct _smart_ReportDatainfo{
    INT8U DeviceNo[12];       //状态设备编号
    INT8U CarNum[16];         //车牌号
    INT8U DriveID[16];        //当前司机编号
    INT8U mColDataTime[4];    //实际的采集时间，time函数
    INT8U X[4];               //经度 0-未定位，度
    INT8U Y[4];               //纬度 0-未定位，度
    INT8U direc[4];           //卫星定位角度 0-未定位
    INT32U WarnMsgVal;        //报警类型                （新增）
    INT32U speed:8,          //当前的速度 km/h
        bMainDev:2,         //状态子系统是否安装
        bLiquidDev:2,         //液位子系统是否安装
        bOilCtlDev:2,         //远程油门子系统是否安装
        bAutoStart:2;         //一键启动是否已经安装
    INT16U DataLen;           //后面的状态数据长度，后面附加的数据长度和安装的子系统上报数据
}smart_ReportDatainfo;

typedef struct _smart_Datainfo{
    INT32U DevType:8,         //数据上传设备子类型  0x01-状态子系统 0x02-液位监测子系统 0x04-远程油门子系统 0x08-一键启动子系统
        DataType:8,           //数据类型 data中包含的数据类型 11=>状态子系统基础数据 12=>胎温胎压数据 13=>工具缺失数据 14=>箱门开关数据
                              //15=>周边距离数据  16=>照片和视频数据  21=>罐内液位监测子系统基础数据
        DataLen:16;           //后面data的长度

}smart_Datainfo;

//1.状态子系统基础数据
typedef struct _smart_SubStatusinfo{
    INT16U rpm;               //发动机转速/转
    INT16U mTyreCount;        //检测的轮胎个数
    float CoolLiquidTemp;     //冷却液温度
    float OilTemp;            //机油温度
    float OilLevel;           //油箱油位
    float PowerTakeTemp;      //取力器温度
    float PowerOilLevel;      //取力器内机油位
    INT32U PltWarnVale;       //底盘上的故障告警
    INT32U ToolsDetect;       //工具检测状态
}smart_SubStatusinfo;

//2.胎温胎压数据
typedef struct _smart_Carinfo{
    INT8U TryeWarType;        //轮胎报警类型 0-无效 1-温度报警 2-压力报警 3-急漏气报警 4-轮胎传感器异常报警
    INT8U TryeID;             //轮胎编号 安装时标定，从1开始
    INT16U TempValue;         //轮温值
    INT16U PressValue;        //轮压值
}smart_Carinfo;

//3.工具缺失数据
typedef struct _smart_Toolinfo{
    INT8U ToolsID[4];         //工具编号，ToolsDetect不为1时，对应的编号为工具缺失的编号，由平台统一对工具进行编号并且下发 0x4002
}smart_Toolinfo;

//4.箱门开关状态
typedef struct _smart_BoxDoorinfo{
    INT32U BoxDoorCount:8,   //箱门个数
        bOPend:24;           //箱门开关状态 bit8 - bit31 1-打开 0-关闭
} smart_BoxDoorinfo;

//5.周边检测数据
typedef struct _smart_Rangeinfo{
    INT32U mFront:8,        //前向
        mLeft:8,
        mRight:8,
        mBehind:8;
}smart_Rangeinfo;

//6.照片视频数据
typedef struct _smart_photoinfo{
    INT8U FileName[20];   //照片或视频文件名称
    INT8U url[256];       //照片或者视频的下载链接
}smart_photoinfo;

//7.罐内液位监测子系统基础数据
typedef struct _smart_LiquidDevinfo{
    INT32U RpmSpeed;      //水泵转速
    float FlowRate;       //消防炮出水流量  m3/min
    float wPressLow;      //管道出水压力(低压)
    float wPressMid;      //管道出水压力(中压)
    float mAirPress;      //吸水管道真空气压
    float mfoamLevel;     //泡沫罐液位
    float mWaterLevel;    //水罐内液位
    float mpimpRuntime;   //水泵运转时间
    float mGetWatertime;  //引水时间
} smart_LiquidDevinfo;

//全局变量声明
extern smart_ReportDatainfo  reportInfo;
extern smart_Datainfo  dataInfo;
extern smart_SubStatusinfo subStatusInfo;
extern smart_Carinfo carInfo;
//extern smart_Toolinfo* toolInfo;
extern smart_BoxDoorinfo boxDoorInfo;
extern smart_Rangeinfo rangeInfo;
extern smart_LiquidDevinfo liquidInfo;


//生成数据上报buff
void generateDataBuff(unsigned char *data, int *dataLen,QList <int> updateNum);

//设置门状态
void setDoorState(int bit,int value);

void reportTest();

//打印缓冲区
void LogBuffer(unsigned char* buf,int len);

//检测网络设备
char * interface_name_cut (char *buf, char **name);

int check_interface_fromproc(char *inter);

//上传报警信息
void getWarnVal(unsigned int& warnVal);

int warnMsgVal(warnValueLimit valueLimit,float value);
#endif // MYDATAPROCESS_H
