#ifndef INITSMARTINFO_H
#define INITSMARTINFO_H

typedef unsigned char INT8U;
typedef unsigned short INT16U;
typedef unsigned int INT32U;

enum warnType{
    engineSpeed = 103,    //发动机转速
    engineTemp = 201,    //发动机温度（机油温度）
    coolTemp = 2101,   //冷却液温度
    PTOTemp = 301,       //取力器温度（取不到）
    typeTemp = 401,      //胎温
    typePre = 502,       //胎压
    PTOOil = 607,        //取力器油位（取不到）
    fuelLevel = 707,      //油箱油位
    rpmSpeed = 803,     //水泵转速
    rpmTime = 904,       //水泵工作时间
    fireMontor = 1008,   //消防炮出水量
    pressLow = 2002,  //管道出水压力  低压
    airPress = 1202,      //真空度
    pressMid = 2102,   //管道出水压力  中压
    drawWaterTime = 1306,  //引水时间
    waterLeve = 1409,      //水罐液位
    foamLeve = 1509,     //泡沫液位
    leftDistance = 1609,   //左侧障碍物距离
    righteDistance = 1709,  //右侧障碍物距离
    fontDistance = 1809,     //前侧障碍物距离
    bhindDistance = 1909,     //后侧障碍物距离

};
//设备登录请求  命令码 0x4000
typedef  struct _smart_login
{
    INT8U IMEISN[16];      //15个字节的MIEISN
    INT8U ICCID[24];       //SIM卡ID
    INT8U ZDDevID[12];     //状态设备ID长11字节ZD0001
    INT8U SysParam[4];     //参数版本
    INT8U mFlag;           //固定为0xff
    INT8U mType;           //车辆类型  消防车为13
    INT8U Major[4];        //4种设备程序主版本号 -0xFF表示
    INT8U Min[4];          //4种设备程序次版本号
}smart_login;

//设备登录 应答码 0x4000
typedef struct _smart_login_ack
{
    INT8U Random[8];       //保留-后期加密密钥
    INT8U SystemClock[6]; //时钟，用于系统校时
    INT8U CarSn[16];       //车辆编号
    INT8U CarNumber[16];   //绑定的车辆编号
    INT8U CarType[4];      //车辆类型
    INT16U NeedLiveUp:8,   //1-表示需要升级，0-无需升级
           Locked:2,       //设备是不是锁定
           devtype:2,      //设备类型
           DevisRegister:2,//设备已经注册
           DevisBind:2;    //设备已经绑定   十六进制无法表示
}smart_login_ack;

//下载工作参数请求 命令码0x4001
typedef struct _smart_GetParamReq
{
    INT8U DEVICESN[12];    //状态子系统设备编号
    INT8U IMEISN[16];      //读取4G模块的IMEI码
}smart_GetParamReq;

//下载工作参数 应答码0x4001  定义消防车报警阀值
typedef struct _StruSysParam
{
    INT8U uaParamVer[3];    //系统参数版本例如1.1
    INT8U mSpeedLimit;      //最大速度限制 km/h 0-为不限制
    INT8U bDrvVfyEnable;    //司机在线人脸识别验证使能
    INT8U mDrvVfyTimer;     //司机人脸验证的时间间隔一分钟
    INT8U mMaxStatDelay;    //定位最大延时分钟
    INT8U mAcctimer;        //ACC关闭之后的关机延时一分钟
    INT8U mPhotoupeTimer;   //定时抓拍照片时间间隔 分钟
    INT8U mDataUpLoadTimer; //数据实时上报时间间隔（1-255秒）
    INT8U mCarColor;        //车辆颜色
    INT8U mTyreCount;       //轮胎个数
    INT8U mDePTNO[8];       //使用单位编号
    INT8U BoxDoorCount;     //门的个数
    INT8U VideoServ[64];    //流媒体服务器地址
    INT32U mVideoPort:16,   //流媒体服务器推流端口
        bMainDev:4,         //状态子系统是否已经安装
        bLiquidDev:4,       //液位子系统是否安装
        bOilCtlDev:4,       //液位子系统是否安装
        bAutoStart:4;       //一键子系统是否安装
    //包含多个结构体

}StruSysParam;
typedef struct _WarnValueLmt
{
    INT32U mParamType:16,   //报警参数阀值类型
           bDevType:8,      //1-状态子系统 2-液位子系统 3-远程油门 4-一键启动子系统
           bValueMde:8;     //0x01-高阀值有效  0x02-低阀值有效 0x03-高低阀值均有效
    float mHighVal;         //阀值高位
    float mLowVal;          //阀值低位
}WarnValueLmt;
//下载工具编码表请求 命令码0x4002
typedef struct _smart_GetToolsTableReq
{
    INT8U DEVICESN[12];   //状态子系统设备编号
    INT8U IMEISN[16];     //读取4G模块的IMEI码
}smart_GetToolsTableReq;

//下载工具编码表 命令码0x4002
typedef struct _ToolsInfo
{
    INT8U ToolsCode[4];   //工具编码
    INT8U ToolsName[20];  //工具名称
    INT8U eLableID[24];   //对应的电子标签ID
}ToolsInfo;

typedef struct _StruSysToolsTable
{
    INT16U DataLen;       //工具表长度数量
    //包含多个ToolsInfo
}StruSysToolsTable;

//登录请求 0x4000
void smartLoginReq(smart_login* myLogin,int* dataLen);

//登录应答 0x4000
void smartLoginRetu(smart_login_ack* loginAck,int dataLen);

//工作参数请求 0x4001
void smartgetParamReq(smart_GetParamReq* myParam,int* dataLen);

//工作参数应答 0x4001
void smartParamRetu(unsigned char* buff,int dataLen,int headLen);

//工具编码表请求 0x4002
void smartGetToolsReq(smart_GetToolsTableReq* myToolsTable,int* dataLen);

//工具编码表应答 0x4002
void smartToolsTableRetu(unsigned char* buff,int dataLen,int headLen);

#endif // INITSMARTINFO_H
