#ifndef _SMART_4GEC20_HEAD_FILE_
#define _SMART_4GEC20_HEAD_FILE_

#include "ServTypes.h"



struct DATE
{
	unsigned short year;
	unsigned short mon;
	unsigned short day;
	unsigned short dow;
	
};
struct TIME
{
	unsigned char hour;
	unsigned char min;
	unsigned char sec;
	
};

extern struct DATE g_CurrentDate;
extern struct TIME g_CurrentTime;

#define SMART_UART_EC20 4   //4Gģ��Ĵ���
extern int Smart_OpenEC20Dev(void);
extern void Smart_CloseEC20Dev(int fd);
extern int Smart_SendEC20ComCmd(int fd ,int Command,char *outBuf);
 
//����AT����
#define SMART_AT_DISPLAY_PRODUCT_INFO   0x01  //��ʾ��Ʒ��ʶ��Ϣ
#define SMART_AT_DISPLAY_MANFACTURER_INFO   0x02  //��ʾ  Manufacturer Identification
#define SMART_AT_DISPLAY_ECHOMODE_CLOSE   0x03  //�رջ���ģʽ
#define SMART_AT_DISPLAY_ECHOMODE_OPEN   0x04  //�رջ���ģʽ

#define SMART_AT_DISPLAY_CURRCONF   0x11  //Display Current Configuration
#define SMART_AT_POWER_RIGHTNOW     0x50  //�����ر�ģ���Դ AT+QPOWD=0
#define SMART_AT_POWER_NORMAL       0x51  //�����ر�ģ���Դ AT+QPOWD=1
#define SMART_AT_SET_MODULE_RTC     0x52  //����ģ���RTCʱ�� AT+CCLK=<time> ʱ���ַ����ĸ�ʽ ��yy/MM/dd,hh:mm:ss��zz��,
#define SMART_AT_GET_IMEI     0x53 	 //��ȡģ���IMIE
#define SMART_AT_GET_SIM_STATUS     0x54  	//��ȡSIM����״̬
#define SMART_AT_GET_ICCID     0x55  	//��ȡSIM����ICCID
/////////////////////////////////////////////////////////////////
//  GPS ģ�� AT ָ��
/////////////////////////////////////////////////////////////////
#define SMART_AT_GNSS_CONFIG   0x101  //����Configure GNSS  AT+QGPSCFG Configure GNSS
#define SMART_OPEN_GPS_ENG     0x110  //��GPS����
#define SMART_CLOSE_GPS_ENG     0x111  //�ر�GPS����
#define SMART_GET_GPS_INFO     0x112  //��ȡGPS��λ��Ϣ

#define SMART_ENABLE_NMEA_INFO     0x113  //ʹ��NMEA��Ϣ
#define SMART_GET_NMEA_INFO     0x114  //��ȡNMEA��Ϣ
#define SMART_CLOSE_NMEA_INFO     0x115  //ʹ��NMEA��Ϣ

#define SMART_GPS_DEL_DATA_COLD     0x116  //������
#define SMART_GPS_DEL_DATA_HOT     0x117  //������
#define SMART_GPS_DEL_DATA_WARM     0x118  //������

#define SMART_ENABLE_GPS_VTG        0x119   //���ó���
#define SMART_GET_NMEA_GGA_INFO     0x120   //GGAЭ��







extern int Smart_EC20Check(void);
extern void Smart_EC20GNSSDisable( void );


extern void Smart_UpdateGpsStatTime(void);
extern void Smart_InitGprsStatus(void);


//����ΪGPRS TCP/IP AT ����
#define SMART_TCPIP_CFG_PARA     0x200  //Configure Parameters of a TCP/IP Context
#define SMART_TCPIP_ACTIVE_PDP    0x201  //ACTIVE PDP
#define SMART_TCPIP_DEACTIVE_PDP  0x202  //DEACTIVE PDP
#define SMART_TCPIP_OPEN_SOCKET  0x203  //Open a Socket Service
#define SMART_TCPIP_CLOSE_SOCKET  0x204  //Close a Socket Service
#define SMART_TCPIP_QUERY_SOCKET_STATUS 0x205 //��ѯsocket״̬
#define SMART_TCPIP_SEND_DATA 0x207           //��������
#define SMART_TCPIP_RECV_DATA 0x208           //�������� AT+QIRD Retrieve the Received TCP/IP Data
#define SMART_TCPIP_SEND_HEX_STRING 0x209           //����16��������
#define SMART_TCPIP_SWITCH_DATA_ACC_MODE 0x20a          //�л����ݷ��ʷ�ʽ
#define SMART_PING_REMOTE 0x20B          //ping Զ������
#define SMART_SYNC_TIME_WITH_NTP_SERV 0x20C          //Synchronize Local Time with NTP Server
#define SMART_CONF_DNS_SERV 0x20D          //AT+QIDNSCFG Configure Address of DNS Server
#define SMART_GETIP_FROM_DOMAIN_NAME 0x20E          //Get IP Address by Domain Name
#define SMART_CONF_OPTION_PARA 0x20F          //���ÿ�ѡ����
#define SMART_SEND_DATA_ECHO 0x210          //Control Whether to Echo the Data for AT+QISEND
#define SMART_QUERY_LAST_ERROR_CODE 0x211          //��ѯ���һ�δ�����

#define SMART_TCPIP_OPEN_UPDATE_SOCKET  0x220   //����������������socket
















//���������
#define EC20_INVALID_PARA  501 //Invalid parameter(s)
#define EC20_OPT_NOT_SUPPORT  502 //Operation not supported
#define EC20_SUBSYTEM_BUSY  503 //GNSS subsystem busy
#define EC20_SESSION_IS_ONGOING  504 //Session is ongoing
#define EC20_SESSION_NOT_ACTIVITY  505 //Session not activity
#define EC20_OPT_TIMEOUT  506 //Operation timeout
#define EC20_FUNCTION_IS_NOT_ENABLE  507 //Function not enabled
#define EC20_TIME_INFO_ERROR  508 //Time information error
#define EC20_XTRA_NOT_ENABLE  509 //XTRA not enabled
#define EC20_XTRA_FILE_OPEN_ERR  510 //XTRA file open failed
#define EC20_XTRA_BAD_CRC  511 //Bad CRC for XTRA data file
#define EC20_TIME_IS_VALID  512 //Validity time is out of range
#define EC20_INNER_RESOURCE_ERR  513 //Internal resource error
#define EC20_GNSS_LOCKED  514 //GNSS locked
#define EC20_END_BY_E911  515 //End by E911
#define EC20_NOT_FIXED_NOW  516 //Not fixed now
#define EC20_UNKNOW_ERROR  549 //Unknown error



#define EC20_TCP_OPTOK 0 //Operation successful
#define EC20_TCP_UNKNOW_ERR 550 //Unknown error
#define EC20_TCP_OPT_BLOCKED 551 //Operation blocked
#define EC20_TCP_INVALID_PARA 552 //Invalid parameters
#define EC20_TCP_MEMORY_NO_ENOUGH 553 //Memory not enough
#define EC20_TCP_CREATE_SK_ERR 554 //Create socket failed
#define EC20_TCP_OPT_NO_SUPPLY 555 //Operation not supported
#define EC20_TCP_SK_BIND_FAILURE 556 //Socket bind failed
#define EC20_TCP_SK_LISTEN_FAILURE 557 //Socket listen failed
#define EC20_TCP_SK_WRITE_FAILURE 558 //Socket write failed
#define EC20_TCP_SK_READ_FAILURE 559 //Socket read failed
#define EC20_TCP_SK_ACCEPT_FAILURE 560 //Socket accept failed
#define EC20_TCP_OPEN_PDP_FAILURE 561 //Open PDP context failed
#define EC20_TCP_CLOSE_PDP_FAILURE 562 //Close PDP context failed
#define EC20_TCP_SK_IDENT_BUSY 563 //Socket identity has been used
#define EC20_TCP_DNS_BUDY 564 //DNS busy
#define EC20_TCP_DNS_PARSE_FAILURE 565 //DNS parse failed
#define EC20_TCP_SK_CONNECT_FAILURE 566 //Socket connect failed
#define EC20_TCP_SK_CLOSED 567 //Socket has been closed
#define EC20_TCP_OPT_BUSY 568 //Operation busy
#define EC20_TCP_OPT_TIMEOUT 569 //Operation timeout
#define EC20_TCP_PDP_DOWN 570 //PDP context broken down
#define EC20_TCP_CANCLE_SEND 571 //Cancel send
#define EC20_TCP_OPT_NO_ALLOW 572 //Operation not allowed
#define EC20_TCP_APN_NOT_CONFIG 573 //APN not configured
#define EC20_TCP_PORT_BUSY 574 //Port busy Quectel



extern int Smart_Send4GPacketToServer(unsigned char *Data,int DataLen);
extern int Smart_ConnectToServer(void);
extern int Smart_Send4GPacketToServer(unsigned char *Data,int DataLen);


/////////////////////////////////////////////////
////  GPRS ��ǰ״̬
/////////////////////////////////////////////////
#define SMART_GPRS_CONNECT_OK  1            	      //���ӳɹ�
#define SMART_GPRS_CONNECT_FAILURE  0       	      //����ʧ��
#define SMART_GPRS_CONNECT_ING  3       	      //��������

extern INT8U Smart_GprsIsConnect(void);
extern void Smart_EC20FastGetGPSInfo(void);



/****** shixing ********
 *
 * ���Ӻ�������
 *
 * */

extern int Smart_EC20CheckInsertCard(void);

extern int Smart_EC20GetIMEIInfo(void);

extern int Smart_EC20GetICCIDInfo(unsigned char* buff);

extern void Smart_EC20GetGPSInfo(int forceUpload,SwapWarnMsgBody *pCurrentMsg);

#endif
