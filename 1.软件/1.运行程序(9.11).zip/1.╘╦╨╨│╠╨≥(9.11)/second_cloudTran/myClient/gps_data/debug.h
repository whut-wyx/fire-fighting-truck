#ifndef FSS_USER_MANAGER_DEBUG_HEAD_FILE
#define FSS_USER_MANAGER_DEBUG_HEAD_FILE
extern void MyDebug(const char *fmt, ...);
extern void Smart_ShowErrorInfo(const char *fmt, ...);
#endif