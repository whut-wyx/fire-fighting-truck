/*******************************************************
 *   JPUART.c ���ڲ���
 *    For Linux
 *    ���ߣ�ʷ����
 *    ����ʱ��:2006-9-19 16:28
 *    �޸�:   
 *******************************************************/

#include "ServUART.h"

int Smart_UartSetup(int fd,int nSpeed, int nBits, char nEvent, int nStop)
{    
	struct termios newtio,oldtio;    
	if  ( tcgetattr( fd,&oldtio)  !=  0) 
	{ 
		perror("SetupSerial 1");
		return -1; 
	}
	bzero( &newtio, sizeof( newtio ) );
	newtio.c_cflag  |=  CLOCAL | CREAD; 
		 
		 
		 //
		 newtio.c_cflag &= ~CSIZE;  //
		 newtio.c_cflag |= CS8;
		  
		 
		  switch( nEvent ) 
		   { 
		   	case 'O':                     // 
		   		 newtio.c_cflag |= PARENB;
		   		 newtio.c_cflag |= PARODD;
		   		 newtio.c_iflag |= (INPCK | ISTRIP);
		   		 break;
		   	case 'E':                     //
		   		newtio.c_iflag |= (INPCK | ISTRIP);
		   		newtio.c_cflag |= PARENB;
		   		newtio.c_cflag &= ~PARODD;
		   		break; 
		   case 'N':                    // 
		   	 //newtio.c_cflag &= ~PARENB; 
		   	 //newtio.c_cflag &= ~INPCK; 
		   	 newtio.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); /*Input*/
        		 newtio.c_oflag &= ~OPOST;   /*Output*/
		   	 
		   	  break;
		   }
		   
		   switch( nSpeed )
		   { 
		   
		   case 4800: 
		   	cfsetispeed(&newtio, B4800);
		   	cfsetospeed(&newtio, B4800);
		   	break;
		   case 9600:
		   	cfsetispeed(&newtio, B9600);
		   	cfsetospeed(&newtio, B9600);
		   	break;
		    case 19200:
		   	cfsetispeed(&newtio, B19200);
		   	cfsetospeed(&newtio, B19200);
		   	break;
		   case 38400:
		   	cfsetispeed(&newtio, B38400);
		   	cfsetospeed(&newtio, B38400);
		   	break;
		   case 57600:
		   	cfsetispeed(&newtio, B57600);
		   	cfsetospeed(&newtio, B57600);
		   	break;
		   case 115200:
		   		cfsetispeed(&newtio, B115200);
		   		cfsetospeed(&newtio, B115200);
		   		break;
		   default:
		   	cfsetispeed(&newtio, B9600);
		   	cfsetospeed(&newtio, B9600);
		   	break;
		   }
		   
		   
		//STOP  
	if( nStop == 1 )
	{ 
		newtio.c_cflag &=  ~CSTOPB;
	}
	else if ( nStop == 2 )
	{  
		newtio.c_cflag |=  CSTOPB;
	}  
	
		    
		    
    newtio.c_cflag &= ~HUPCL;
     newtio.c_iflag &= ~INPCK;
     newtio.c_iflag |= IGNBRK;
     newtio.c_iflag &= ~ICRNL;
     newtio.c_iflag &= ~IXON;
     newtio.c_lflag &= ~IEXTEN;
     newtio.c_lflag &= ~ECHOK;
     newtio.c_lflag &= ~ECHOCTL;
     newtio.c_lflag &= ~ECHOKE;
     newtio.c_oflag &= ~ONLCR;
		   
     newtio.c_cc[VTIME]  = 5;
     newtio.c_cc[VMIN] = 1;
     tcflush(fd,TCIFLUSH);
     if((tcsetattr(fd,TCSANOW,&newtio))!=0)
    { 
		perror("com set error");
		return -1;
    } 
    //cdbg("set done!\n");
    return 0;
}
		   	


int Smart_UartOpen(int comport)
{ 
	char *dev[]={"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5"};
	long  vdisable;
	int fd;
	if(comport<0 || comport>5)
	{
		cdbg(" UART %d not supply \n",comport);
		return(-1);
	}
	fd = open( dev[comport], O_RDWR|O_NOCTTY|O_NDELAY);
	if (-1 == fd)
	{
		cdbg("open %s failure .....\n", dev[comport]);
		perror("Can't Open Serial Port");
		return(-1);
	}
	else
	
	
	if(fcntl(fd, F_SETFL, 0)<0)
	{ 
		cdbg("fcntl failed!\n");
	}
	
	if(isatty(STDIN_FILENO)==0)
	{        
		  //cdbg("standard input is not a terminal device\n");   
	}
	return fd;
}


void Smart_UartClose(int fd)
{
	if(fd>0)
	{
		close(fd);
	}
	
}


int Smart_UartWrite(int fd,unsigned char *Data,unsigned short DataL)
{

	if(fd<=0 || !Data || !DataL)
	{
		return -1;
	}
	return write(fd,Data,DataL);
}


int Smart_UartRead(int fd,unsigned char *Data,unsigned short DataL)
{
	if(fd<=0 || !Data || !DataL)
	{
		cdbg("%s[%d] \n",__FILE__,__LINE__);
		return -1;
	}
	return read(fd,Data,DataL);
}


int Smart_UartWaitRecvData(int fd,int WaitSeconds)
{
	int iErr=0;
	fd_set rfds,maskfds;
	struct timeval timeout={WaitSeconds,0};
	FD_ZERO(&rfds);
	FD_SET(fd, &rfds);
	maskfds = rfds;
	iErr = select(fd+1, &maskfds,NULL, NULL, &timeout);
	if(iErr<=0)
	{
		if(iErr==0)
		{
			cdbg("%s[%d].wait timeout\n",__FILE__,__LINE__);
			return -1;
			
		}
		else
		{
			//cdbg("%s[%d]\n",__FILE__,__LINE__);
			return -1;
		}
	}
	if(FD_ISSET(fd,&maskfds))
	{
		return 0;
	}
	return -1;
}
