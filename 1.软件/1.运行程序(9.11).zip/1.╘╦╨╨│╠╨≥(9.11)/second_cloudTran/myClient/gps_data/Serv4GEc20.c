/*******************************************************
 *   JP4GEC20.c 4GGPS��GPRSģ��
 *    For Linux
 *    ���ߣ�ʷ����
 *    ����ʱ��:2006-9-19 16:28
 *    �޸�:   
 *******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <time.h>
#include "ServTypes.h"
#include "Serv4GEc20.h"


#define UART1_BPS    115200        
unsigned char SMART_RESPONE_OK[4]= {0x4F,0x4B,0x0D,0x0A};
unsigned char SMART_RESPONE_ERROR[5]= {0x45, 0x52, 0x52, 0x4F, 0x52};

struct Smart_CurrGpsInfo  g_CurrentGpsInfo;
struct Smart_GprsInfo g_GprsStatus;
struct Smart_GpsAdvanceInfo g_mGpsAdvnceInfo;



unsigned long Smart_TransStringTol(char *strbuf)
{
	unsigned long value;
	if(strbuf==NULL || strlen(strbuf)==0)
		return 0;
	value = strtol(strbuf,NULL,10);
	return value;
}

////////////////
int Smart_WaitHandleTimeout(int fd,int timeoutv)
{
	static fd_set mask0; 
	fd_set rfds; 
	int error,nfds = 0,retval=0;
	struct timeval timeout; 
	FD_ZERO(&rfds);
	FD_SET(fd, &rfds);
	nfds = fd+1; 
	timeout.tv_sec = timeoutv;
	timeout.tv_usec = 0; //
	error = select(nfds, &rfds, (fd_set *)0, (fd_set *)0, &timeout); 
	if (FD_ISSET(fd, &rfds)) 
	{ 
		retval=0;
	} 
	else  //��ʱ 
	{ 
		retval=-1;
	}
	return  retval;
}

//�ָ�һ���ָ��
unsigned long Smart_SplitData(unsigned char *Data
,int dataLen
,int indxStart
,int indxEnd
,char splitchar
,unsigned char *OutBuf
,unsigned int OutBufLen
)
{

	int i,j=0;
	int splitnum=0;
	for(i=0;i<dataLen;i++)
	{
		if(Data[i]==splitchar)
		{
			splitnum++;
			if(splitnum==indxEnd)
			{
				break;
			}
			continue;
		}
		else
		{
			if(splitnum == indxStart)
			{
				OutBuf[j]=Data[i];
				j++;
				if(j>=OutBufLen)
				{
					break;
				}
			}
		}
	}
	return j;
}



unsigned long Smart_TransGpsData(unsigned char *Data)
{
	unsigned char DataBuf[16];
	int i,j;
	memset(DataBuf,0,sizeof(DataBuf));
	if(!Data)
	{
		return 0;
	}
	j=0;
	for(i=0;i<strlen((char *)Data);i++)
	{
		if(Data[i]!='-' && Data[i]!='.')
		{
			DataBuf[j]=Data[i];
			j++;
		}
	}
	return Smart_TransStringTol((char *)DataBuf);
}

//ȥ��С���㱣����10֮һǧ��/Сʱ
unsigned long Smart_TransGBSpeedKMData(unsigned char *Data)
{
	unsigned char DataBuf[16];
	int i,j,hasSplit=0;
	memset(DataBuf,0,sizeof(DataBuf));
	if(!Data)
	{
		return 0;
	}
	j=0;
	for(i=0;i<strlen((char *)Data);i++)
	{
		
		if(hasSplit==0 && Data[i]=='.')
		{
			hasSplit=1;
			break;
		}
		else 
		{
			DataBuf[j]=Data[i];
			j++;
			if(hasSplit==1)
			{
				break;
			}
		}
	}
	return Smart_TransStringTol((char *)DataBuf);
}


int Smart_CmpStrNoCase(char *str1,char *str2)
{
		if(!str1 || !str2)
		return 0;
	if(strlen(str1) == strlen(str2) && strlen(str2)>0 && strncasecmp(str1,str2,strlen(str1))==0)
		return 1;
	else
		return 0;
}

/*************************************************************************************************/
/*                ���� GPS NMEA���ݸ�ʽ
 *************************************************************************************************/
static int  do_SearchInfoEx(char *pSrc,int SrcLen,char *pdStr,int DstLen)
{
	int i;
	
	if(!pSrc|| !pdStr)
	{
		return 0;
	}
	if(SrcLen < DstLen)
	{
		return 0;
	}
	for(i=0;i<DstLen;i++)
	{
		if(pSrc[i] != pdStr[i])
		{
			break;
		}
	}
	if(i==DstLen)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

char * Smart_SearchInfoEx(char *pSrc,int SrcLen,char *pdStr,int DstLen)
{
	char *Findp=NULL;
	int i;
	if(!pSrc|| !pdStr || SrcLen < DstLen)
	{
		return Findp;
	}
	for(i=0;i<SrcLen;i++)
	{
		if(do_SearchInfoEx(&pSrc[i],SrcLen-i,pdStr,DstLen))
		{
			Findp=&pSrc[i];
			break;
		}
	}
	return Findp;
}


int Smart_nCpyLine(char *pSrc,int SrcLen, char *pdst,int pdstLen,char *Flag,int FlagLen)
{
	char *Findp=NULL;
	int cpyLen=0;
	if(!pSrc|| !pdst || !Flag || SrcLen<=0 || pdstLen<=0)
	{
		return cpyLen;
	}
	Findp = Smart_SearchInfoEx(pSrc,SrcLen,Flag,FlagLen);
	if(Findp)
	{
		cpyLen = (int)Findp - (int)pSrc;
		if(cpyLen && cpyLen <= pdstLen)
		{
			memcpy(pdst,pSrc,(int)Findp - (int)pSrc);
		}
		else if(cpyLen)
		{
			memcpy(pdst,pSrc,pdstLen);
		}
		*(pdst+cpyLen)=0;
	}
	else
	{
		cpyLen = 0;	
	}
	return cpyLen;
}


unsigned long Smart_TransStringToHEX(char *strbuf,int Len)
{
	unsigned long value;
	unsigned char tempbuf[40];
	if(strbuf==NULL || strlen(strbuf)==0)
		return 0;
	memset(tempbuf,0,sizeof(tempbuf));
	memcpy(tempbuf,strbuf,Len);
	value = strtol((const char *)tempbuf,( char **)NULL,16);
	return value;
}


unsigned long Smart_TransStringToDec(char *strbuf,int Len)
{
	unsigned long value;
	unsigned char tempbuf[40];
	if(strbuf==NULL || strlen(strbuf)==0)
		return 0;
	memset(tempbuf,0,sizeof(tempbuf));
	memcpy(tempbuf,strbuf,Len);
	value = strtol((const char *)tempbuf,( char **)NULL,10);
	return value;
}

void Smart_GpsCacheInfoInit(void)
{
	memset((char *)&g_CurrentGpsInfo,0,sizeof(g_CurrentGpsInfo));
	memset((char *)&g_mGpsAdvnceInfo,0,sizeof(g_mGpsAdvnceInfo));
}



//������������ ����������ȥ�� 0x0D �� 0x0A
unsigned char * Smart_Enc20ErrCode(unsigned short errCode)
{	
	unsigned char *Errp;
	switch(errCode)
	{
		case EC20_INVALID_PARA:
		{
			Errp = "�������";
		}
		break;
		case EC20_OPT_NOT_SUPPORT:
		{
			Errp = "������֧��";
		}
		break;
		case EC20_SUBSYTEM_BUSY:
		{
			Errp = "��ϵͳæ";
		}
		break;
		case EC20_SESSION_IS_ONGOING:
		{
			Errp = "�Ѿ���";
		}
		break;
		case EC20_SESSION_NOT_ACTIVITY:
		{
			Errp = "����δ����";
		}
		break;
		case EC20_OPT_TIMEOUT:
		{
			Errp = "������ʱ";
		}
		break;
		case EC20_FUNCTION_IS_NOT_ENABLE:
		{
			Errp = "����δ����";
		}
		break;
		case EC20_TIME_INFO_ERROR:
		{
			Errp = "ʱ����Ϣ����";
		}
		break;
		case EC20_XTRA_NOT_ENABLE:
		{
			Errp = "XTRA δʹ��";
		}
		break;
		case EC20_XTRA_FILE_OPEN_ERR:
		{
			Errp = "XTRA�ļ��򿪴���";
		}
		break;
		case EC20_XTRA_BAD_CRC:
		{
			Errp = "XTRA �����CRC��֤��";
		}
		break;
		case EC20_TIME_IS_VALID:
		{
			Errp = "ʱ�䳬����Χ";
		}
		break;case EC20_INNER_RESOURCE_ERR:
		{
			Errp = "�ڲ���Դ����";
		}
		break;
		case EC20_GNSS_LOCKED:
		{
			Errp = "GNSSģ�鱻����";
		}
		break;
		case EC20_END_BY_E911:
		{
			Errp = "��E911��ֹ";
		}
		break;
		case EC20_NOT_FIXED_NOW:
		{
			Errp = "ģ��δ��λ";
		}
		break;
		case EC20_UNKNOW_ERROR:
		{
			Errp = "δ֪����";
		}
		break;
		//TCP������
		case EC20_TCP_UNKNOW_ERR:
		{
			Errp = "δ֪����";
		}
		break;
		case EC20_TCP_OPT_BLOCKED:
		{
			Errp = "��������";
		}
		break;
		case EC20_TCP_INVALID_PARA:
		{
			Errp = "�쳣����";
		}
		break;
		case EC20_TCP_MEMORY_NO_ENOUGH:
		{
			Errp = "�ڴ治��";
		}
		break;
		case EC20_TCP_CREATE_SK_ERR:
		{
			Errp = "����SOCKET����";
		}
		break;
		case EC20_TCP_OPT_NO_SUPPLY:
		{
			Errp = "������֧��";
		}
		break;
		case EC20_TCP_SK_BIND_FAILURE:
		{
			Errp = "SOCKET �󶨴���";
		}
		break;
		case EC20_TCP_SK_LISTEN_FAILURE:
		{
			Errp = "SOCKET ����";
		}
		break;
		case EC20_TCP_SK_WRITE_FAILURE:
		{
			Errp = "SOCKET д��ʧ��";
		}
		break;
		case EC20_TCP_SK_READ_FAILURE:
		{
			Errp = "SOCKET ��ȡʧ��";
		}
		break;
		break;
		case EC20_TCP_SK_ACCEPT_FAILURE:
		{
			Errp = "SOCKET Accpet ʧ��";
		}
		break;
		case EC20_TCP_OPEN_PDP_FAILURE:
		{
			Errp = "Open PDPʧ��";
		}
		break;
		case EC20_TCP_CLOSE_PDP_FAILURE:
		{
			Errp = "Close PDPʧ��";
		}
		break;
		case EC20_TCP_SK_IDENT_BUSY:
		{
			Errp = "Socket ��ʶ�ѱ�ʹ��";
		}
		break;
		case EC20_TCP_DNS_BUDY:
		{
			Errp = "DNSæ";
		}
		break;
		case EC20_TCP_DNS_PARSE_FAILURE:
		{
			Errp = "DNS ����ʧ��";
		}
		break;
		case EC20_TCP_SK_CONNECT_FAILURE:
		{
			Errp = "Socket ����ʧ��";
		}
		break;
		case EC20_TCP_SK_CLOSED:
		{
			Errp = "Socket�Ѿ����ر�";
		}
		break;
		case EC20_TCP_OPT_BUSY:
		{
			Errp = "����æ";
		}
		break;
		case EC20_TCP_OPT_TIMEOUT:
		{
			Errp = "������ʱ";
		}
		break;
		case EC20_TCP_PDP_DOWN:
		{
			Errp = "PDP Down";
		}
		break;
		case EC20_TCP_CANCLE_SEND:
		{
			Errp = "ȡ������";
		}
		break;
		case EC20_TCP_OPT_NO_ALLOW:
		{
			Errp = "����������";
		}
		break;
		case EC20_TCP_APN_NOT_CONFIG:
		{
			Errp = "APNδ����";
		}
		break;
		case EC20_TCP_PORT_BUSY:
		{
			Errp = "�˿�æ";
		}
		break;
	}
	return Errp;
    
}



//������������ ����������ȥ�� 0x0D �� 0x0A
int Smart_GetAtRespond(unsigned char *RecvBuf,int RecvBufL,unsigned char *outbuf)
{	
	int  offset=0,i,j=0;
	char StartTagLen;
	unsigned char *startp=NULL;
	StartTagLen=4;
	startp = Smart_SearchInfoEx((char *)RecvBuf,RecvBufL,SMART_RESPONE_OK,StartTagLen);
	if(startp)
	{
		offset= startp-RecvBuf;
		for(i=0;i<offset;i++)
		{
			if(RecvBuf[i]!=0x0D && RecvBuf[i]!=0x0A)
			{
				outbuf[j]=RecvBuf[i];
				j++;
			}
		}
		
	}
	return j;
    
}

int Smart_ReadSMS( void )
{
	return 0;	
}

//���� -1 ��ʾ��Ӧ��   ����0 �ɹ� 0ʧ��
int Smart_SendEC20ComCmd(int fd,int Command,char *outBuf)
{
	unsigned char buffer[128];
	unsigned char Respond[1024];
	int Len=0,retv=0,faiNum=0,offset=0;
	switch(Command)
	{
		case SMART_AT_DISPLAY_PRODUCT_INFO:   //��ʾ��Ʒ��ʶ��Ϣ
			Len=sprintf((char *)buffer,"ATI");
		break;
		
		case SMART_AT_DISPLAY_MANFACTURER_INFO:   //��ʾ��Ʒ��ʶ��Ϣ
			Len=sprintf((char *)buffer,"AT+GMM");
		break;
        case SMART_AT_DISPLAY_ECHOMODE_CLOSE: //�ر�echo
			Len=sprintf((char *)buffer,"ATE 0");
		break;
		case SMART_AT_DISPLAY_ECHOMODE_OPEN:
			Len=sprintf((char *)buffer,"ATE 1");
		break;
		case SMART_AT_GET_IMEI:
		{
			Len=sprintf((char *)buffer,"AT+GSN");
		}
		break;
		case SMART_AT_GET_SIM_STATUS:
		{
			Len=sprintf((char *)buffer,"AT+QSIMSTAT?");
		}
		break;
		case SMART_AT_GET_ICCID:  //��ȡICCID
		{
			Len=sprintf((char *)buffer,"AT+QCCID");
		}
		break;
		//GNSS
		case SMART_AT_GNSS_CONFIG: //��ȡGNSS����
		{
			Len=sprintf((char *)buffer,"AT+QGPSCFG=?");
		}
		break;
		case SMART_OPEN_GPS_ENG:  //����GPS
		{
			Len=sprintf((char *)buffer,"AT+QGPS=1");
		}
		break;
		
		case SMART_ENABLE_GPS_VTG:  //����GPS
		{
			Len=sprintf((char *)buffer,"AT+QGPSGNMEA=\"VTG\"");
		}
		break;
		
		case SMART_GPS_DEL_DATA_COLD:  //ɾ����������-������
		{
			Len=sprintf((char *)buffer,"AT+QGPSDEL=0");
		}
		break;
		case SMART_GPS_DEL_DATA_HOT:  //ɾ����������-������
		{
			Len=sprintf((char *)buffer,"AT+QGPSDEL=1");
		}
		break;
		case SMART_GPS_DEL_DATA_WARM:  //ɾ����������-������
		{
			Len=sprintf((char *)buffer,"AT+QGPSDEL=2");
		}
		break;
		case SMART_CLOSE_GPS_ENG:  //�ر�GPS
		{
			Len=sprintf((char *)buffer,"AT+QGPSEND");
			//Len=sprintf((char *)buffer,"AT+QGPS=0");
			
		}
		break;
		case SMART_GET_GPS_INFO: //��ȡGPS��λ��Ϣ
		{
			Len=sprintf((char *)buffer,"AT+QGPSLOC=2");
			//Len=sprintf((char *)buffer,"AT+QGPSLOC?");
		}
		break;
		
		case SMART_ENABLE_NMEA_INFO: //����NMEA
		{
			
			Len=sprintf((char *)buffer,"AT+QGPSCFG=\"nmeasrc\",1");
		}
		break;
		case  SMART_GET_NMEA_INFO:    //��ȡ NMEA Sentences
		{
			Len=sprintf((char *)buffer,"AT+QGPSGNMEA=\"VTG\"");
		}
		break;
		case SMART_GET_NMEA_GGA_INFO:
		{
			Len=sprintf((char *)buffer,"AT+QGPSGNMEA=\"RMC\"");
		}
		break;
		case SMART_CLOSE_NMEA_INFO:  //�ر�NMEA
		{
			Len=sprintf((char *)buffer,"AT+QGPSCFG=\"nmeasrc\",0");
		}
		break;
		///////////////////////////////////////////////////////////////////////////////////
		default:
		{
			cdbg("%s[%d] �����ָ��\n",__FILE__,__LINE__);
		}
		break;
	}
	
	*(buffer+Len)=0x0D;
	*(buffer+Len+1)=0x00;
	Len++;
	
	retv=Smart_UartWrite(fd,(unsigned char *)buffer,Len);
	retv=-1;
	memset(Respond,0,sizeof(Respond));
	//SJG �޸� 2020-8-2 02:39PM
	offset=0;
	faiNum=0;
	do
	{
		if(faiNum>5)
		{
			retv=-1;
			offset=-1;
			return -1;
		}
		
		if(Smart_WaitHandleTimeout(fd,3)==0)
		{
			
			retv=Smart_UartRead(fd,(unsigned char *)Respond+offset,sizeof(Respond)-offset);
			if(retv>0 )
			{
				offset=offset+retv;
				if(Smart_SearchInfoEx((char *)Respond,offset,SMART_RESPONE_OK,4)
				  || Smart_SearchInfoEx((char *)Respond,offset,SMART_RESPONE_ERROR,5))
				{
					
					if(outBuf)
						memcpy(outBuf,Respond,offset);
					 break;
				}
				else
				{
					faiNum++;
				}
			}
		}
		else
		{
			cdbg("%s[%d] Wait  time out buffer=%s\n",__FILE__,__LINE__,buffer);
			retv=-1;
			offset=-1;
			break;
		}
	}while(1);
	return offset;
}




//��ȡģ��Ĳ�Ʒ��Ϣ
void Smart_EC20ProductInfo(void)
{
	unsigned char productInfo[200];
	int readL=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ProductInfo Error");
		return;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_DISPLAY_PRODUCT_INFO,(char *)productInfo);
	return ;
}

//��ȡģ��Ĳ�Ʒ��Ϣ
void Smart_EC20ManFacturerInfo(void)
{
	unsigned char productInfo[200];
	int readL=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_DISPLAY_MANFACTURER_INFO,(char *)productInfo);
	return ;
}



//#define SMART_SIM_COM_SIMCAR_GETCCID          200           //��ȡIMEI��
int Smart_EC20GetIMEIInfo(void)
{
	unsigned char productInfo[200];
	int readL=0;
	unsigned char *startp=NULL;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return -1;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_GET_IMEI,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_OK,4)))
	{ 
		//����
		Smart_SplitData((unsigned char *)productInfo
		,readL
		,1
		,2
		,0x0A
		,(unsigned char *)g_GprsStatus.simSn
		,15
		);
		//����IMEI��
		
		cdbg("Smart_EC20GetIMEIInfo [%s]\n",g_GprsStatus.simSn);
	}
	return 0;
}




//��ȡSIM�� ICCID
int Smart_EC20GetICCIDInfo(unsigned char* dataBuff)
{
	unsigned char productInfo[200];
	int readL=0;
	unsigned char *startp=NULL;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return -1;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_GET_ICCID,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_OK,4))
	&& readL>8)
	{ 
        memcpy(dataBuff,productInfo+10,20);
		/*
		memset((char *)g_SysUserInfo.ICCID,0,sizeof(g_SysUserInfo.ICCID));
		Smart_SplitData((unsigned char *)productInfo+10
		,readL-10
		,0
		,1
		,0x0D
		,(unsigned char *)g_SysUserInfo.ICCID
		,24
		);
		cdbg("ICCID [%s]\n",(unsigned char *)g_SysUserInfo.ICCID);
		*/
	}
	return 0;
}




///////*************///////////
//��ȡSIM����״̬ 
int Smart_EC20GetSimReGInfo(void)
{
	return 0;
}


int Smart_EC20CheckInsertCard(void)
{
	unsigned char productInfo[200],tmpbuf[4];
	int readL=0;
	unsigned char *startp=NULL;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return -1;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_GET_SIM_STATUS,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_OK,4)))
	{ 
		
		//����
		Smart_SplitData((unsigned char *)productInfo
		,readL
		,1
		,2
		,','
		,(unsigned char *)tmpbuf
		,4
		);
		if(Smart_TransStringTol(tmpbuf)!=1)
		{
			cdbg("Sim Car Is not ready\n");
			g_GprsStatus.SimCardReady=0;
		}
		else
		{
			//cdbg("Sim Car Is Insert\n");
			g_GprsStatus.SimCardReady=1;
		}
	}
	return 0;
}




int Smart_EC20OpenPower(void)
{
	
	  return 0;
}

//���EC20״̬
void Smart_EC20ModuleShut(void)
{
	
}
int Smart_CheckEC20HasConnect(void)
{
	return 0;	
	
}
int Smart_EC20Connect(INT8U mForceConnect)
{
	return 0;
}
void Smart_EC20ModuleInit( void )
{
	return;
}


void Smart_EC20GNSSConfig( void )
{
	
	unsigned char productInfo[1024];
	int readL=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_AT_GNSS_CONFIG,(char *)productInfo);
	
	return ;
}

void Smart_EC20GNSSEnable( void )
{
	
	unsigned char productInfo[1024];
	unsigned char ErrorCode[10];
	unsigned char *startp=NULL;
	unsigned char Flag[2]={0x0D,0x0A};
	int readL=0;
	if(g_mJPV5Fd.gps_fd<0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return;
	}
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_OPEN_GPS_ENG,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - productInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		cdbg("Err Code=%d[%s]\n",Smart_TransStringTol((char *)ErrorCode),Smart_Enc20ErrCode(Smart_TransStringTol((char *)ErrorCode)));
	}
	
	
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_ENABLE_NMEA_INFO,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - productInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		cdbg("Err Code=%d[%s]\n",Smart_TransStringTol((char *)ErrorCode),Smart_Enc20ErrCode(Smart_TransStringTol((char *)ErrorCode)));
	}
	
	return ;
}

void Smart_EC20GNSSDisable( void )
{
	
	unsigned char productInfo[1024];
	unsigned char ErrorCode[10];
	unsigned char *startp=NULL;
	unsigned char Flag[2]={0x0D,0x0A};
	int readL=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return;
	}
	
	
	
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_CLOSE_NMEA_INFO,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - productInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		cdbg("Err Code=%d[%s]\n",Smart_TransStringTol((char *)ErrorCode),Smart_Enc20ErrCode(Smart_TransStringTol((char *)ErrorCode)));
	}
	
	
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_CLOSE_GPS_ENG,(char *)productInfo);
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - productInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		cdbg("Err Code=%d[%s]\n",Smart_TransStringTol((char *)ErrorCode),Smart_Enc20ErrCode(Smart_TransStringTol((char *)ErrorCode)));
	}
	g_CurrentGpsInfo.IsStat = 0;
	return ;
}

void Smart_EC20GNSSColdRestart( void )
{
	unsigned char InfoBuf[20];
	unsigned char productInfo[1024];
	unsigned char ErrorCode[10];
	unsigned char *startp=NULL;
	unsigned char Flag[2]={0x0D,0x0A};
	unsigned long mStartTime,mEndTime,dissec=0;
	int readL=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("Smart_EC20ManFacturerInfo Error");
		return;
	}
	
	cdbg("Close GPS\n");
	Smart_EC20GNSSDisable();
	memset((char *)productInfo,0,sizeof(productInfo));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_GPS_DEL_DATA_COLD,(char *)productInfo);
	
	if((startp = Smart_SearchInfoEx((char *)productInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - productInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		cdbg("Err Code=%d[%s]\n",Smart_TransStringTol((char *)ErrorCode),Smart_Enc20ErrCode(Smart_TransStringTol((char *)ErrorCode)));
	}
	Smart_EC20GNSSEnable();
	/////////////////////////////////////////////////////
	cdbg("OPEN GPS ..\n");
	
	time(&mStartTime);
	for(;;)
	{
		unsigned char GpsInfo[1024];
		int ErrVal=0;
		memset((char *)GpsInfo,0,sizeof(GpsInfo));
		readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_GET_GPS_INFO,(char *)GpsInfo);
		
		if((startp = Smart_SearchInfoEx((char *)GpsInfo,readL,SMART_RESPONE_ERROR,5)))
		{ 
			Smart_nCpyLine(startp+6+1,readL-(startp - GpsInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
			ErrVal = Smart_TransStringTol((char *)ErrorCode);
			if(ErrVal == EC20_NOT_FIXED_NOW)
			{
				g_CurrentGpsInfo.IsStat = 0; //δ��λ
			}
			usleep(500*1000);
			continue;
		}
		else
		{
			g_CurrentGpsInfo.IsStat = 1;
		}
		time(&mEndTime);
		break;
	}
	dissec=mEndTime-mStartTime;
	
	snprintf(InfoBuf,20,"%d���λ\n",dissec);
	cdbg("%s\n",(unsigned char *)InfoBuf);
	
	return ;
}

void Smart_SetupCurrentGpsInfo(unsigned char *datap,int BufferL)
{
    cdbg("datap: %s\n",datap);
	int Len;
	unsigned char tbuf[20];
	g_CurrentGpsInfo.IsStat = 1;
	
	//ά�� -dd.ddddd  ��ʽ	
	Len = Smart_SplitData((char *)datap,BufferL,1,2,',',g_CurrentGpsInfo.Latitude,8);
	if(Len<=0)
    {
		
		goto error;
	}

	if(g_CurrentGpsInfo.Latitude[0]=='-')
	{
		g_CurrentGpsInfo.LatitudeType = 'S';
	}
	else
	{
		g_CurrentGpsInfo.LatitudeType = 'N';
	}
	*((char *)g_CurrentGpsInfo.Latitude+Len)=0;
	
	g_CurrentGpsInfo.Latitudev=Smart_TransGpsData(g_CurrentGpsInfo.Latitude);

	//����-ddd.ddddd ��ʽ	
        cdbg("11111\n");
        Len = Smart_SplitData((char *)datap,BufferL,2,3,',',g_CurrentGpsInfo.Indicator,9);
	if(Len<=0)
	{
		cdbg("%s[%d] \n",__FILE__,__LINE__);
		goto error;
	}
	*((char *)g_CurrentGpsInfo.Indicator+Len)=0;
	cdbg("22222\n");
        
        if(g_CurrentGpsInfo.Indicator[0]=='-')
	{
		g_CurrentGpsInfo.IndicatorType = 'W';
	}
	else
	{
		g_CurrentGpsInfo.IndicatorType = 'E';
	}
	cdbg("33333\n");
    g_CurrentGpsInfo.Indicatorv=Smart_TransGpsData(g_CurrentGpsInfo.Indicator);
    indicator = g_CurrentGpsInfo.Indicatorv;
    latitude = g_CurrentGpsInfo.Latitudev;
    cdbg("Indicatorv: %s\n",g_CurrentGpsInfo.Indicator);
cdbg("Latitude: %s\n",g_CurrentGpsInfo.Latitude);
error:
	return;
	
	
}

void Smart_SetupCurrentGpsSpeedInfo(unsigned char *datap,int BufferL)
{
	int Len;
	unsigned char tbuf[20];
	//�����ٶ�
	Len = Smart_SplitData((char *)datap,BufferL,7,8,',',g_CurrentGpsInfo.SpeedBuf,20);
	if(Len<0)
	{
		return;
	}
	*((char *)g_CurrentGpsInfo.SpeedBuf+Len)=0;
	g_CurrentGpsInfo.CurrentSpeed = Smart_TransGBSpeedKMData((char *)g_CurrentGpsInfo.SpeedBuf);
	
	return;
}


int Smart_GpsIsFixed(void)
{
	if(g_CurrentGpsInfo.IsStat==1 || g_CurrentGpsInfo.IsStat==2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void Smart_EC20GetGPSInfo(int forceUpload,SwapWarnMsgBody *pCurrentMsg)
{	
    printf("����getgpsinfo����\n");
	unsigned char GpsInfo[1024],SpeedBuf[128];
	unsigned char ErrorCode[10];
	unsigned char *startp=NULL;
	unsigned char Flag[2]={0x0D,0x0A};
	int readL=0,ErrVal=0,SpeedBufL=0;
	unsigned long mGpsTimer=0,dbugVal;
	if(g_mJPV5Fd.gps_fd<0)
	{
		cdbg("%s[%d] gps_fd Error\n",__FILE__,__LINE__);
		return;
	}
        
	
	{
		mGpsTimer=30;
	}
	
	memset((char *)ErrorCode,0,sizeof(ErrorCode));
	memset((char *)SpeedBuf,0,sizeof(SpeedBuf));
	SpeedBufL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_GET_NMEA_INFO,(char *)SpeedBuf);
	memset((char *)GpsInfo,0,sizeof(GpsInfo));
	
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_GET_GPS_INFO,(char *)GpsInfo);
	if((startp = Smart_SearchInfoEx((char *)GpsInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
        printf("error\n");
		Smart_nCpyLine(startp+6+1,readL-(startp - GpsInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		ErrVal = Smart_TransStringTol((char *)ErrorCode);
		if(ErrVal == EC20_NOT_FIXED_NOW)
		{
			g_CurrentGpsInfo.IsStat = 0; //δ��λ
		}
	}
	else
	{
		
        printf("success\n");
         Smart_SetupCurrentGpsInfo((unsigned char *)GpsInfo,readL);
         //Smart_SetupCurrentGpsSpeedInfo((unsigned char *)SpeedBuf,SpeedBufL);
		 
	}
	
	
	dbugVal=time(NULL) - g_CurrentGpsInfo.lastStateTime;
	if(dbugVal < mGpsTimer && forceUpload==0)
	{
		return ;
	}
	
	if(dbugVal >= mGpsTimer || forceUpload==1)
	{
		time(&g_CurrentGpsInfo.lastStateTime);
		//Smart_HHUpLoadGpsInfo(g_CurrentGpsInfo.IsStat,pCurrentMsg);
	}
	return ;
}







void Smart_EC20SyncGPSDateTimeInfo(void)
{
	
	unsigned char GpsInfo[1024];
	unsigned char ErrorCode[10];
	unsigned char *startp=NULL;
	unsigned char Flag[2]={0x0D,0x0A};
	int readL=0,ErrVal=0;
	unsigned long mGpsTimer=0;
	if(g_mJPV5Fd.gps_fd<=0)
	{
		cdbg("%s[%d] gps_fd Error\n",__FILE__,__LINE__);
		return;
	}
	time(&g_CurrentGpsInfo.lastStateTime);
	memset((char *)GpsInfo,0,sizeof(GpsInfo));
	memset((char *)ErrorCode,0,sizeof(ErrorCode));
	readL = Smart_SendEC20ComCmd(g_mJPV5Fd.gps_fd,SMART_GET_GPS_INFO,(char *)GpsInfo);
	if((startp = Smart_SearchInfoEx((char *)GpsInfo,readL,SMART_RESPONE_ERROR,5)))
	{ 
		//����
		Smart_nCpyLine(startp+6+1,readL-(startp - GpsInfo)-7,(char *)ErrorCode,10,(char *)Flag,2);
		ErrVal = Smart_TransStringTol((char *)ErrorCode);
		if(ErrVal == EC20_NOT_FIXED_NOW)
		{
			g_CurrentGpsInfo.IsStat = 0; //δ��λ
		}
	}
	else
	{
		
		 Smart_SetupCurrentGpsInfo((unsigned char *)GpsInfo,readL);
	}
	return ;
}




int Smart_OpenEC20Dev(void)
{
	int fd;
	int i;
	if((fd=Smart_UartOpen(SMART_UART_EC20))<0)
	{
		cdbg("open SMART_UART_EC20(%d) Error \n",SMART_UART_EC20);
	 	return -1;
	}
	
	if((Smart_UartSetup(fd,115200,8,'N',1))<0)
	{
		cdbg("set_opt error");
		close(fd);
		return -1;
	}
	cdbg("%s[%d] SMART_UART_EC20=%d \n",__FILE__,__LINE__,SMART_UART_EC20);
	
	//�رջ���ģʽ
	if(Smart_SendEC20ComCmd(fd,SMART_AT_DISPLAY_ECHOMODE_CLOSE,NULL)<0)
	{
		cdbg("Close Echo Error");
	}
	
	g_mJPV5Fd.gps_fd=fd;
	Smart_EC20GNSSEnable();
	return fd;
}

void Smart_CloseEC20Dev(int fd)
{
	Smart_UartClose(fd);
}


//���ģ��Ĳ����ʣ�Ĭ��Ϊ115200
int Smart_EC20Check(void)
{
	int   name_arr[] = {38400,  19200,  9600,  4800,  2400,  1200,  300,57600, 115200};
	unsigned char productInfo[200];
	int readL=0;
	int fd,i,find=0;
	
	{
		if((fd=Smart_UartOpen(SMART_UART_EC20))<0)
		{
			perror("open_port error");
		 	return -1;
		}
		if((Smart_UartSetup(fd,115200,8,'N',1))<0)
		{
			perror("set_opt error");
			close(fd);
			return -1;
		}
		readL = Smart_SendEC20ComCmd(fd,SMART_AT_DISPLAY_ECHOMODE_CLOSE,(char *)productInfo);
		if(readL>0)
		{
			
			cdbg("%s\n",productInfo);
		}
		memset((char *)productInfo,0,sizeof(productInfo));
		readL = Smart_SendEC20ComCmd(fd,SMART_AT_DISPLAY_MANFACTURER_INFO,(char *)productInfo);
		if(readL>0)
		{
			
			cdbg("%s\n",productInfo);
		
		}
		close(fd);
	}
	return 0;
	
	
	
}



