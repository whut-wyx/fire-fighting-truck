
/****** shixing *****
 *
 *
 *
 * 获得gps信息
 *
 * *****/

//初始化GPS
extern void getIMEIInfo(unsigned char* IMEI);

extern void initGPSInfo();

extern void getICCIDInfo(unsigned char* ICCID);

//循环调用
extern void getGPSInfo(unsigned long* indica,unsigned long* latitu);


