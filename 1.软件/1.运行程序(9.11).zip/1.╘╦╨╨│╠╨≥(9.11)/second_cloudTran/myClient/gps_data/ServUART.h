/****
 *
 *
 *
 * 增加一些函数的声明
 *
 *
 *
 *
 * */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include "Serv4GEc20.h"

extern int Smart_uartSetup(int fd,int nSpeed, int nBits, char nEvent, int nStop);

extern int Smart_UartOpen(int comport);

extern void Smart_UartClose(int fd);

extern int Smart_UartWrite(int fd,unsigned char *Data,unsigned short DataL);

extern int Smart_UartRead(int fd,unsigned char *Data,unsigned short DataL);

extern void Smart_UartClose(int fd);

extern int Smart_UartWrite(int fd,unsigned char *Data,unsigned short DataL);

extern int Smart_UartRead(int fd,unsigned char *Data,unsigned short DataL);

extern int Smart_UartWaitRecvData(int fd,int WaitSeconds);

