#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <getopt.h>
#include <dirent.h>
#include <netdb.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/times.h>
#include <sys/select.h>
#include <signal.h>
#include <pthread.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/types.h>
#include <fcntl.h>
#include <poll.h>
#include "Serv4GEc20.h"
#include "getGPS_info.h"

int ServerExit=0;
extern int g_TimeIsChange;
extern smart_mutex g_Mutex;
mJPV5Fd g_mJPV5Fd;
unsigned long indicator = 11341246;
unsigned long latitude = 3170847;
#define SMART_MAX_PHOTO_FIND_NUMBER 100
SwapWarnMsgBody msgBody;

void OurSing(int sig)
{
    Smart_EC20GNSSDisable();
    ServerExit=1;
    signal(SIGINT,SIG_DFL);

}

void initGPSInfo(){

    memset((char *)&g_mJPV5Fd,-1,sizeof(g_mJPV5Fd));
    g_mJPV5Fd.gps_fd = Smart_OpenEC20Dev();
    if(g_mJPV5Fd.gps_fd <0)
    {
       cdbg("%s[%d] Open EC20 Uart failure SMART_UART_EC20=%d \n",__FILE__,__LINE__,SMART_UART_EC20);

       Smart_CloseEC20Dev(g_mJPV5Fd.gps_fd);
       g_mJPV5Fd.gps_fd = 0;

    }
    //屏蔽信号
   signal(SIGINT,OurSing);//执行OurSing函数，然后在函数中恢复此信号默认处理
   signal(SIGCHLD,SIG_IGN);
}
#if 1
//获得IMEI号
void getIMEIInfo(unsigned char* IMEI){
    Smart_EC20GetIMEIInfo();
    memcpy(IMEI,g_GprsStatus.simSn,16);
}
//获得ID号
void getICCIDInfo(unsigned char* ICCID){
    unsigned char buff[24] = {0};
    Smart_EC20GetICCIDInfo(buff);
    memcpy(ICCID,buff,24);
}

void getGPSInfo(unsigned long* indica,unsigned long* latitu){
    Smart_EC20GetGPSInfo(1,&msgBody);
    *indica = indicator;
    *latitu = latitude;
}
#else

int main_()
{
//     pthread_t mLedThr,mNetThr,mMonThr;
//     int mKeyBoadValue=1,index,mretry=0;
//     unsigned char LastKeyValue;
//     int pid=-1;
     memset((char *)&g_mJPV5Fd,-1,sizeof(g_mJPV5Fd));

     g_mJPV5Fd.gps_fd = Smart_OpenEC20Dev();
     if(g_mJPV5Fd.gps_fd <0)
     {
        cdbg("%s[%d] Open EC20 Uart failure SMART_UART_EC20=%d \n",__FILE__,__LINE__,SMART_UART_EC20);
        goto end;
     }
     //mretry=0;

     //屏蔽信号
    signal(SIGINT,OurSing);
    signal(SIGCHLD,SIG_IGN);
    //初始化并加载盲区缓冲区
    //Smart_LoadAllDeadZoneCacheInfo();
    //获取IMIEID
    Smart_EC20CheckInsertCard();
    Smart_EC20GetIMEIInfo();
    //Smart_EC20GetICCIDInfo();

    SwapWarnMsgBody msgBody;
    Smart_EC20GetGPSInfo(1,&msgBody);



end:


    if(g_mJPV5Fd.gps_fd >=0)
    {
        Smart_CloseEC20Dev(g_mJPV5Fd.gps_fd);
        g_mJPV5Fd.gps_fd = 0;
    }

    return 0;
}

#endif
