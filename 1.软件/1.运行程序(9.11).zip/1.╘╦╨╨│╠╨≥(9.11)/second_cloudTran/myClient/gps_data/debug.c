#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <getopt.h>
#include <dirent.h>
#include <sys/stat.h>
#include <signal.h>
#include "debug.h"
void MyDebug(const char *fmt, ...)
{
	
	{
		char debugbuff[2048];
		int outlen;
		va_list ap;
		va_start(ap, fmt);
		outlen=vsprintf(debugbuff,fmt,ap);
		va_end(ap);
		*(debugbuff+outlen) = 0;
		printf("%s",debugbuff);
		
	}

	
}

void Smart_ShowErrorInfo(const char *fmt, ...)
{
	
	{
		char debugbuff[2048];
		int outlen;
		va_list ap;
		va_start(ap, fmt);
		outlen=vsprintf(debugbuff,fmt,ap);
		va_end(ap);
		*(debugbuff+outlen) = 0;
		printf("%s",debugbuff);
		
	}

	
}