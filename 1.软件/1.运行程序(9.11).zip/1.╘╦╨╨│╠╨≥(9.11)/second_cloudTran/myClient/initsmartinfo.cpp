#include "initsmartinfo.h"
#include "myapp.h"
#include "mydataprocess.h"
extern "C"{
#include "gps_data/getGPS_info.h"
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <QString>
#include <QDebug>

unsigned char IMEI[16] = {0};
unsigned char ICCID[24] = {0};

//登录请求 0x4000
void smartLoginReq(smart_login* myLogin,int* dataLen)
{
    *dataLen = sizeof (smart_login);
    if(*dataLen){
        //IMEISN号指4g模块
        getIMEIInfo(IMEI);
        //strcpy((char*)myLogin->IMEISN,"123456789015345");
        memcpy((char*)myLogin->IMEISN,IMEI,16);

        //ICCID号
        //strcpy((char*)myLogin->ICCID,"141134567890");
        getICCIDInfo(ICCID);
        memcpy((char*)myLogin->ICCID,ICCID,24);

        strcpy((char*)myLogin->ZDDevID,"ZD000028");

        myLogin->mFlag = 0xff;
        myLogin->mType = 0xd;

        strcpy((char*)myLogin->Major,"1111");

        strcpy((char*)myLogin->Min,"0000");

    }
}
//获取工作参数请求 0x4001
void smartgetParamReq(smart_GetParamReq* myParam,int* dataLen)
{
    *dataLen = sizeof(smart_GetParamReq);
    if(*dataLen){
       strcpy((char*)myParam->DEVICESN,"ZD000028");
       //strcpy((char*)myParam->IMEISN,"123456789015345");
       memcpy((char*)myParam->IMEISN,IMEI,16);
    }
}
//工具编码表请求 0x4002
void smartGetToolsReq(smart_GetToolsTableReq *myToolsTable, int *dataLen)
{
    *dataLen = sizeof(smart_GetToolsTableReq);
    if(*dataLen){
        strcpy((char*)myToolsTable->DEVICESN,"ZD000028");
        //strcpy((char*)myToolsTable->IMEISN,"123456789015345");
        memcpy((char*)myToolsTable->IMEISN,IMEI,16);
    }
}
//登录请求返回
void smartLoginRetu(smart_login_ack* loginAck,int dataLen){
    smart_login_ack* parseLogin = NULL;
    parseLogin = loginAck;
    QString strRandom,strCarsn,strCarNum,strCartype;
    int liveUp,locked,devType,devRegis,devBind;
    unsigned char dataTime[6] = {0};//存储的是整型，不是char类型
    strRandom = QString(QLatin1String((char*)parseLogin->Random));
    memcpy(dataTime,parseLogin->SystemClock,6);
    strCarsn = QString(QLatin1String((char*)parseLogin->CarSn));
    strCarNum = QString(QLatin1String((char*)parseLogin->CarNumber));
    strCartype = QString(QLatin1String((char*)parseLogin->CarType));
    printf("the car type is %s\n",parseLogin->CarType);
    liveUp = (int)parseLogin->NeedLiveUp;
    locked = (int)parseLogin->Locked;
    devType = (int)parseLogin->devtype;
    devRegis = (int)parseLogin->DevisRegister;
    devBind = (int)parseLogin->DevisBind;
    //存储到myapp
    myApp::writeLoginToConfig(strRandom,strCarsn,strCarNum,strCartype,dataTime,liveUp,locked,devType,devRegis,devBind);
    myApp::writeConfig();
}

//工作参数返回
void smartParamRetu(unsigned char* buff,int dataLen,int headLen)
{
    int headL = headLen;
    int dataL = dataLen;
    int subBuff = 0;
    unsigned char tempBuff[2048] = {0};
    memcpy(tempBuff,buff,sizeof (tempBuff));
    subBuff += headL;
    WarnValueLmt* warnValue = NULL;
    StruSysParam* paramAck = (StruSysParam*)((char*)tempBuff+subBuff);
    QString strVersion,strDepNo;            //版本号和使用单位编号
    myApp::dataTran = paramAck->mDataUpLoadTimer;
    int tyreCount;
    strVersion = QString(QLatin1String((char*)paramAck->uaParamVer)); //默认为char类型存储
    strDepNo = QString(QLatin1String((char*)paramAck->mDePTNO));
    tyreCount = (int)paramAck->mTyreCount;
    printf("the typeCount is %d\n",tyreCount);
    //存储到myApp
    myApp::writeSysParamToConfig(strVersion,strDepNo,tyreCount);
    subBuff += sizeof (StruSysParam);
    int warnType;
    int warnDevType,warnValMde;
    float highVal,lowVal;
    int i = 0;
    while(subBuff < dataL){
        i++;
        warnValue = (WarnValueLmt*)((char*)tempBuff+subBuff);
        /*********  *****/
        warnType = (int)warnValue->mParamType;
        warnDevType = (int)warnValue->bDevType;
        warnValMde = (int)warnValue->bValueMde;
        highVal = warnValue->mHighVal;
        //printf("第 %d 条：the highLevel is %f\n",i,highVal);
        lowVal = warnValue->mLowVal;
        //printf("第 %d 条：the lowLevel is %f\n",i,lowVal);
        printf("\n");
        //存储到myApp
        switch (warnType) {
        case engineSpeed:
            myApp::engineSpeedStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case engineTemp:
            myApp::engineTempStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case coolTemp:
            myApp::coolLiquidStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case PTOTemp:
            myApp::PTOTempStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case PTOOil:
            myApp::PTOOilLevelStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case fuelLevel:
            myApp::fuelLevelStr = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
            /******* ==============  ******* */
        case typeTemp:
            myApp::typeTemp = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case typePre:
            myApp::typePre = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case rpmSpeed:
            myApp::rpmSpeed = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case rpmTime:
            myApp::rpmTime = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case fireMontor:
            myApp::fireMontor = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case pressLow:
            myApp::mPressLow = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case airPress:
            myApp::airPress = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case pressMid:
            myApp::mPressMid = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case drawWaterTime:
            myApp::drawWaterTime = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case waterLeve:
            myApp::waterLev = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case foamLeve:
            myApp::foamLev = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case leftDistance:
            myApp::leftDistance = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case righteDistance:
            myApp::rightDistance = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case fontDistance:
            myApp::fontDistance = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;
        case bhindDistance:
            myApp::bhindDsitance = warnValueLimit(warnType,warnDevType,warnValMde,highVal,lowVal);
            break;

        default:
            break;
        }
        subBuff += sizeof (WarnValueLmt);
    }
    printf("%d\n",i);
    myApp::writeConfig();
}
//工具参数返回
void smartToolsTableRetu(unsigned char* buff,int dataLen,int headLen)
{
    int headL = headLen;
    int dataL = dataLen;
    int subBuff = 0;
    int toolsTableDataL = 0;
    unsigned char tempBuff[2048] = {0};
    memcpy(tempBuff,buff,sizeof (tempBuff));
    subBuff += headL;
    ToolsInfo* toolInfo = NULL;
    StruSysToolsTable* toolACK = (StruSysToolsTable*)((char*)tempBuff + subBuff);
    toolsTableDataL = (int)toolACK->DataLen;
    //存储到myapp 工具总数量
    myApp::writeToolsTableToConfig(toolsTableDataL);
    subBuff += sizeof (StruSysToolsTable);
    int toolsCode;
    QString toolsName;
    while (subBuff < dataL) {
        toolInfo = (ToolsInfo*)((char*)tempBuff + subBuff);
        toolsCode = QString(QLatin1String((char*)toolInfo->ToolsCode)).toInt(); //字符型存储
        printf("the toolCode is %s\n",toolInfo->ToolsCode);
        toolsName = QString::fromLocal8Bit((char*)toolInfo->ToolsName);
        printf("the tool name is %s\n",toolInfo->ToolsName);
        printf("the eLableID is %s\n",toolInfo->eLableID);
        printf("\n");
        //存储到myapp
        myApp::bindToolsCode.append(toolsCode);
        subBuff += sizeof (ToolsInfo);
    }

}
