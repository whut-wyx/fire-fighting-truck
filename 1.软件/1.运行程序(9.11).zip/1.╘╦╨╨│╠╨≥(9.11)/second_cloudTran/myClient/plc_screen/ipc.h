#ifndef IPC_H
#define IPC_H

/**
*@file ipc.h
*@brief  完成和plc、触摸屏的共享数据
*/
#include <QtCore>
#include "myapp.h"

union semun{
    int val;
    struct semid_ds* buf;
    unsigned short* array;
};

//plc数据结构体
extern int semScreen_id;
extern int shmScreen_id;
extern unsigned char plcSend[3];
extern unsigned char plcRecv[20];
extern unsigned char pipePress;
extern unsigned char foamRate;
extern unsigned char clean_pim;
//触摸屏数据结构体

extern unsigned char rfidClicked; //确定rfid扫描是否被按下 发送can数据帧
extern int semPlc_id;
extern int shmPlc_id;

typedef struct screenStruct{
    unsigned char rfidFlag;       //是否发送can数据
    unsigned char door[7];        //1-打开 0-关闭
    unsigned char distance[3];    //dm
    unsigned char warn[6];        //1-报警 0-不报警 取力器温度和取力器机油位暂无数据 默认为报警
    unsigned char tool[39];       //1-无 0-有
    unsigned char engine[2];      //发动机转速
    unsigned char coolLiquid[2];  //冷却液温度
    unsigned char oilLevel[2];    //燃油液位
    //第二期新增火场温度及可燃气体浓度
    unsigned char fireTemp;       //火场周边温度
    unsigned char gasRate;        //可燃气体浓度
}screenStr;

//线程获得数据函数 包括plc 和 触摸屏
void get_screen_plc_data();

//填充剩余触摸屏数据  需要和云端下达的阀值比较
void fillScreenComplete();
int getWarnValue(warnValueLimit valueLimit,float value);
//线程写进共享内存函数
void writeShm();

//创建触摸屏共享内存
void screenShm();

//创建plc共享内存
void plcShm();

//信号量初始化
int set_semvalue(int semid);

//信号量P操作
int semaphore_p(int semid);

//信号量V操作
int semaphore_v(int semid);

//删除信号量
void del_semvalue(int semid);

//删除信号量和共享内存
void rm_sem_shm();

#endif
