#include "ipc.h"
#include "pthread_global.h"
#include "getcandata.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/sem.h>
#include <sys/shm.h>

/** 触摸屏数据 **/
int semScreen_id;
int shmScreen_id;
unsigned char rfidClicked = 1;
void* screenVoid_p = NULL;
screenStr  screen_struct;

unsigned char rfid_screen_data[39];
unsigned char* screenShm_p;                                 //指向共享内存
#define SCREENSHMSIZE  (sizeof(screenStr))
unsigned char poll_screenData[SCREENSHMSIZE] = {0};         //取出共享内存数据

float rpm;                      //发动机转速
float coolTemp;                 //冷却液温度
float oilTemp;                  //发动机油温
float oilLevel;                 //油箱液位

/** plc数据 **/
int semPlc_id;
int shmPlc_id;
void* plcShm_p = NULL;
unsigned char plcSend[3] = {0};
unsigned char plcRecv[20] = {0};
unsigned char* plcBuff;                                   //指向共享内存
unsigned char pipePress = 0xff;                           //存储传过来的压力值
unsigned char foamRate = 0xff;                            //泡沫比例
unsigned char clean_pim = 0;
#define PLCSHMSIZE (sizeof(plcSend) + sizeof(plcRecv))
#define PLCRECVSIZE (sizeof(plcRecv))
unsigned char poll_plcData[PLCSHMSIZE] = {0};             //取出数据
unsigned char push_plcData[PLCRECVSIZE] = {0};            //写入数据
/******* 触摸屏共享区的创建 *******/
void screenShm()
{
    semScreen_id = semget((key_t)1000,1,0666|IPC_CREAT);
    shmScreen_id = shmget((key_t)2000,sizeof (screenStr),0666|IPC_CREAT);
    screenVoid_p = shmat(shmScreen_id,0,0);
    screenShm_p = (unsigned char*)screenVoid_p;
    memset(screenShm_p,1,SCREENSHMSIZE);   //将指针变量screenShm_p所指向的前SCREENSHMSIZE个字节的内存单元用一个“整数”1替换
    memset(rfid_screen_data,1,sizeof(rfid_screen_data));
    set_semvalue(semScreen_id);
}
/****** plc共享区的创建 ********/
void plcShm()
{
    semPlc_id = semget((key_t)1100,1,0666|IPC_CREAT);
    shmPlc_id = shmget((key_t)2100,PLCSHMSIZE,0666|IPC_CREAT);
    plcShm_p = shmat(shmPlc_id,0,0);  //与共享内存进行关联
    plcRecv[0] = 15;
    plcRecv[1] = 15;
    plcBuff = (unsigned char*)plcShm_p;
    //memset(plcBuff+2,0,PLCSHMSIZE);
    memcpy(plcBuff+sizeof (plcSend),plcRecv,PLCRECVSIZE); //从源plcRecv的起始地址开始拷贝PLCREVSIZE个字节到plcBuff+sizeof(plcSend)的起始位置中
    set_semvalue(semPlc_id);
}
void writeShm()
{
    /** 触摸屏共享内存操作 */
    //完成触摸屏的赋值操作
    fillScreenComplete();
    //for(int i = 0;i<39;i++){
       // printf("%d\n",screen_struct.tool[i]);
    //}
    semaphore_p(semScreen_id);
    memcpy(poll_screenData,screenShm_p,SCREENSHMSIZE);     //取出数据
    memcpy(screenShm_p,&screen_struct,SCREENSHMSIZE);      //写进数据
    semaphore_v(semScreen_id);
    rfidClicked = ((screenStr*)poll_screenData)->rfidFlag;
    /** plc共享内存操作 */
    memcpy(push_plcData,plcRecv,sizeof (plcRecv));
    semaphore_p(semPlc_id);
    memcpy(poll_plcData,plcBuff,PLCSHMSIZE);               //取出数据
    memcpy(plcBuff+sizeof(plcSend),plcRecv,PLCRECVSIZE);   //写入数据
    semaphore_v(semPlc_id);
    //获得设定的管道压力 要除以10才是实际的数据
    memcpy(plcSend,poll_plcData,sizeof(plcSend));
    clean_pim = plcSend[0];
    pipePress = plcSend[1];
    foamRate = plcSend[2];
}

/** 获得plc和触摸屏数据*/
void get_screen_plc_data()
{
    /** 触摸屏获得数据 */
    //获取工具缺失数据
    printf("this is get screen data\n");
    if(rfid_can_recv){
            for(int i = 0;i < 32; i++){
                if((k60_rifd.rfid_state_1 >> i) & 1){
                    rfid_screen_data[i] = 1;
                }
                else{
                    rfid_screen_data[i] = 0;
                }
            }
            for(int i = 0;i < 7;i++){
                if((k60_rifd.rfid_state_2 >> i) & 1) {
                    rfid_screen_data[32+i] = 1;
                }
                else{
                    rfid_screen_data[i] = 0;
                }
            }
    }
    //门状态
    for(int i = 0;i < 7;i++){
        screen_struct.door[i] = ((k60_door.doorstate >> i)& 1);
    }
    //距离按照 左 右 后
    screen_struct.distance[0] = k60_disTime.distance_left/100;
    screen_struct.distance[1] = k60_disTime.distance_right/100;
    screen_struct.distance[2] = k60_disTime.distance_late/100;
    //报警类型  1为不报警
    rpm = bbm_dataInfo.rpm;
    coolTemp = bbm_dataInfo.coolLiquidTemp;
    oilTemp = bbm_dataInfo.oilTemp;
    oilLevel = bbm_dataInfo.oilLevel;
    //底盘数据 分别为发动机转速 冷却液温度 燃油液位
    screen_struct.engine[0] = ((int)bbm_dataInfo.rpm)/100;
    screen_struct.engine[1] = ((int)bbm_dataInfo.rpm)%100;
    screen_struct.coolLiquid[0] = (int)(bbm_dataInfo.coolLiquidTemp);
    screen_struct.coolLiquid[1] = (int)(bbm_dataInfo.coolLiquidTemp*10)%10;
    screen_struct.oilLevel[0] = (int)(bbm_dataInfo.oilLevel);
    screen_struct.oilLevel[1] = (int)(bbm_dataInfo.oilLevel*10)%10;
    screen_struct.fireTemp = k60_door.fireTemp;
    screen_struct.gasRate = k60_waterPress.gasRate;
    /** plc 获得数据 */
    if(liquid_flag){
        plcRecv[0] = k60_liqudLev.mwaterLevel/10;       //cm
        plcRecv[1] = k60_liqudLev.mfoamLevel/10;
    }
    plcRecv[2] = (int)(k60_waterPress.pimRunTime*360) >> 8; //h
    plcRecv[3] = k60_disTime.waterRunTime;
    plcRecv[4] = k60_waterPress.wPressLow * 100;
    plcRecv[5] = 0 * 100;
    plcRecv[6] = k60_liqudLev.flowRate;
    plcRecv[7] = (unsigned char)(k60_liqudLev.foamRate*10);
    plcRecv[8] = bbm_dataInfo.oilTemp;
    plcRecv[9] = (bbm_dataInfo.oilTemp - plcRecv[8])*10;
    plcRecv[10] = bbm_dataInfo.rpm/100;
    plcRecv[11] = bbm_dataInfo.batteryVolatge;
    plcRecv[12] = (bbm_dataInfo.batteryVolatge - plcRecv[11])*10;
    plcRecv[13] = bbm_dataInfo.coolLiquidTemp;
    plcRecv[14] = (bbm_dataInfo.coolLiquidTemp - plcRecv[13])*10;
    plcRecv[15] = k60_disTime.RpmSpeed/100;
    plcRecv[16] = abs(k60_waterPress.mAirPress*100);
    plcRecv[17] = (int)bbm_dataInfo.rpm % 100;
    plcRecv[18] = k60_disTime.RpmSpeed % 100;
    plcRecv[19] = (int)(k60_waterPress.pimRunTime*360);
    printf("===================================get out screen plc data\n");
    printf("低压:%f   %d\n",k60_waterPress.wPressLow,(int)k60_waterPress.wPressLow);
    printf("运转时间：%f   引水时间：%d\n",k60_waterPress.pimRunTime,k60_disTime.waterRunTime);
//    for(int i=0;i<19;i++){
//        printf("第%d个数据：%d\n",i,plcRecv[i]);
//    }
}
void fillScreenComplete(){
    //每次对rfid_flag进行清零操作
    screen_struct.rfidFlag = 1;
    screen_struct.warn[0] = getWarnValue(myApp::engineSpeedStr,rpm);
    screen_struct.warn[1] = getWarnValue(myApp::coolLiquidStr,coolTemp);
    screen_struct.warn[2] = getWarnValue(myApp::engineTempStr,oilTemp);
    screen_struct.warn[3] = 1;
    screen_struct.warn[4] = 1;
    screen_struct.warn[5] = getWarnValue(myApp::fuelLevelStr,oilLevel);
    /** rfid 赋值操作  1是无 0是有*/
    memcpy(screen_struct.tool,rfid_screen_data,sizeof(rfid_screen_data));

}
int getWarnValue(warnValueLimit valueLimit,float value){
    int type = 0;
    type = valueLimit.valueMde;
    switch (type) {
    case 0x01:
        if((int)value < valueLimit.highVal){
            return 0;
        }
        break;
    case 0x02:
        if((int)value > valueLimit.lowVal){
            return 0;
        }
        break;
    case 0x03:
        if(((int)value < valueLimit.highVal) & ((int)value > valueLimit.lowVal)){
            return 0;
        }
        break;
    default:
        break;
    }
    return 1;
}
//初始化信号量
int set_semvalue(int semid){
    //初始化信号量
    union semun sem_union;
    sem_union.val = 1;
    if(semctl(semid,0,SETVAL,sem_union) == -1){
        printf("init sem error:");
        return 0;
    }
    return 1;
}

//P操作
int semaphore_p(int semid){
    struct sembuf sem_b;
    sem_b.sem_num = 0;
    sem_b.sem_op = -1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(semid,&sem_b,1) == -1){
        perror("P error:");
        return 0;
    }
    return 1;
}
//V操作
int semaphore_v(int semid){
    struct sembuf sem_b;
    sem_b.sem_num = 0;
    sem_b.sem_op = 1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(semid,&sem_b,1) == -1){
        perror("V error:");
        return 0;
    }
    return 1;
}
//删除共享内存
void del_semvalue(int semid)
{
    union semun sem_union;
    if(semctl(semid,0,IPC_RMID,sem_union) == -1){
        perror("del error:");
    }
    return ;
}

void rm_sem_shm(){
    del_semvalue(semScreen_id);
    del_semvalue(semPlc_id);
    shmdt(screenShm_p);         //进程与共享内存解除关联
    shmctl(shmScreen_id,IPC_RMID,0);  //删除共享内存
    shmdt(plcBuff);
    shmctl(shmPlc_id,IPC_RMID,0);

}
#if 0

//plc共享内存参数
#define SHMSIZE (sizeof(plcSendData) + sizeof(plcRecvData))
#define RECVSIZE (sizeof(plcRecvData))
#define SENDSIZE (sizeof(plcSendData))
#define msleep(ms) usleep((ms)*1000)
static double liquidHigh;                       //plc设定的液位高度
static double pipePressure;                     //plc设定的管道压力
static char* shmBuff;                        //指向共享内存的指针
static char sendBuff[SENDSIZE] = {0};        //用来做数据交换 接收和发送
static char recvBuff[RECVSIZE] = {0};
static int semPlc_id;
static int shmPlc_id;



/******* plc共享区的创建 ********/
void test(){
    plcShm();
    srand((unsigned)time(NULL));
    plcRecvData recv_plc;
    char data[RECVSIZE] = {0};
    while(1){
        recv_plc.waterLevel = rand()%50 + 1;
        recv_plc.frothLevel = rand()%60 + 1;
        recv_plc.oilTemp = rand()%15 + 40;
        recv_plc.rpm = rand()%200 + 1000;
        recv_plc.coolLiquidTemp = rand()%20 + 22;
        memcpy(data,(char*)&recv_plc,RECVSIZE);
        {
            writePlcShm(data);
        }
        msleep(1500);
    }
}
void plcShm()
{
    void* shm = NULL;
    semPlc_id = semget((key_t)1100,1,0666|IPC_CREAT);
    shmPlc_id = shmget((key_t)2100,SHMSIZE,0666|IPC_CREAT);
    shm = shmat(shmPlc_id,0,0);
    shmBuff = (char*)shm;
    set_semvalue(semPlc_id);
}
//写进共享内存
void writePlcShm(char *data)
{
    memcpy(recvBuff,data,RECVSIZE);
    int i = semaphore_p(semPlc_id);
    printf("SEMN %d\n",i);
    memcpy(sendBuff,shmBuff,SENDSIZE);
    memcpy(shmBuff+SENDSIZE,recvBuff,RECVSIZE);
    semaphore_v(semPlc_id);
    //保存来自plc的变量
    plcSendData* send_plc = NULL;
    send_plc = (plcSendData*)sendBuff;
    if(send_plc->setLiquidHigh !=0 && send_plc->setPipePressure !=0){
        liquidHigh = send_plc->setLiquidHigh;
        pipePressure = send_plc->setPipePressure;
        //存进myapp在发送到k60或者bbm
        //myApp::tankH = send_plc->setLiquidHigh;
    }
}
#endif
