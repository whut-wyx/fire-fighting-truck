#include "establishconnect.h"
#include "initsmartinfo.h"
#include "mydataprocess.h"
#include "plc_screen/ipc.h"
extern "C" {
#include "gps_data/getGPS_info.h"
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <QFile>
#include <QDir>

#define ip "119.96.188.175"
#define port 6060
#define MAXLINE 4096

#define TRUE 1
#define FALSE -1
#define ERROR 0

int socketfd;

pthread_t ppp0;              //拨号线程

void executeConnectNet(){

    //执行拨号函数
    pthread_create(&ppp0,NULL,ppp_4g,NULL);

}
int pppd = 1;
//如果拨号失败  定时再拨
void* ppp_4g(void* arg){
    printf("拨号函数：\n");
        while (1) {
            int isPPP0 = -1;
            isPPP0 = check_interface_fromproc((char*)"ppp0");
            if(isPPP0 == 0){
                system("sudo pppd call quectel-ppp");  //不会再往下执行
            }
            pppd = 0;
            usleep(800*1000); //800ms
        }
    return NULL;
}

int myClientServer()
{
    struct sockaddr_in servaddr;

    //初始化连接
    memset(&servaddr,0,sizeof (servaddr));
    if((socketfd = socket(AF_INET,SOCK_STREAM,0)) < 0){
        printf("create socket error:%s(error:%d)\n",strerror((errno)),errno);
        exit(0);
    }
    //建立socket连接
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    if(inet_pton(AF_INET,ip,&servaddr.sin_addr) <=0 ){
        printf("inet_pton error for %s\n",ip);
    }
    //connect默认为阻塞连接   若一次连接不成功 3s后继续尝试
    int errCounts = 0;
    while(1){
        int ret = connect(socketfd,(struct sockaddr*)&servaddr,sizeof (servaddr));
        if(ret < 0){
            printf("connect error:%s(errno:%d)\n",strerror(errno),errno);
            sleep(1); //1秒后继续尝试连接
            errCounts++;
        }
        if(ret == 0){
            break;               //跳出循环继续初始化参数
        }
        if(errCounts > 2 ){
            return -1;             //中止此函数 继续运行
        }
    }
    return 1;
    /** 首先完成必要信息的上传 包括以下
      * 登陆信息
      * 工作参数
      * 工具编码表
      */
    /**
    *创建线程，完成socket信息接收recv  创建共享内存 传云端
    */

}
//初始化工作信息
int initMyClientInfo(int socketfd)
{
    int sockfd = socketfd;
    if(!sendMyLoginReq(sockfd)){
        printf("sendMyLogin error\n");
        return FALSE;
    }
    if(!recvInitInfo(sockfd))
    {
        printf("recv myLogin error\n");
        return ERROR;
    }
    if(!sendMyParamReq(sockfd)){
        printf("sendMyParam error");
        return FALSE;
    }
    if(!recvInitInfo(sockfd))
    {
        printf("recv param error\n");
        return ERROR;
    }
    if(!sendMyToolsReq(sockfd)){
        printf("sendMyToolsReq error");
        return FALSE;
    }
    if(!recvInitInfo(sockfd))
    {
        printf("recv tools error");
        return ERROR;
    }
    return TRUE;
}
//接收服务器的初始化信息
int recvInitInfo(int socketfd)
{
    int bytes_read = 0,bytes_left = 1024,total = 0;
    unsigned char recvBuff[2048] = {0};
    char* ptr = (char*)recvBuff;
    smart_head* headp = NULL;
    unsigned short cmdCode;
    if(!recv(socketfd,ptr,bytes_left,0)){
        return 0;
    }
    headp = (smart_head*)recvBuff;
    if(!checkDataHead(headp)){
        printf("crc error\n");
    }
    cmdCode = headp->Command[0]|headp->Command[1];
    switch (cmdCode) {
    case SmartLogin:{
        smart_login_ack *loginACK = (smart_login_ack*)((char*)recvBuff+sizeof (smart_head));
        int dataLen = sizeof (smart_login_ack);
        smartLoginRetu(loginACK,dataLen);
        printf("登录 recv success\n");
        break;
    }
    case SmartParam:{
        //消防车参数阀值
        int dataLen = headp->DataLen;
        int headLen = sizeof (smart_head);
        smartParamRetu(recvBuff,dataLen,headLen);
        printf("阈值 recv success\n");
        break;
    }
    case SmartTools:{
        //消防车tools
        int dataLen = headp->DataLen;
        int headLen = sizeof (smart_head);
        smartToolsTableRetu(recvBuff,dataLen,headLen);
        printf("工具 recv success\n");
        break;
    }
    }
    return 1;
}

//登录请求
int sendMyLoginReq(int socketfd){

    int dataLen = 0;
    int myLoginCommand = 0x4000;
    int loginID = 1;
    int retcode = 0;
    unsigned char dataBUff[1024] = {0};
    //登录请求
    smart_login* myLoginReq = (smart_login*)malloc(sizeof (smart_login));
    memset(myLoginReq,0,sizeof (smart_login));  //清空堆区空间
    smartLoginReq(myLoginReq,&dataLen);         //获得数据和数据大小
    memcpy(dataBUff,(char*)myLoginReq,sizeof (smart_login));
    if(!buildSmartPacket(socketfd,myLoginCommand,loginID,retcode,dataBUff,dataLen))//生成数据包并发送
    {
        free(myLoginReq);
        myLoginReq = NULL;
        return FALSE;
    }
    free(myLoginReq);
    myLoginReq = NULL;
    return TRUE;
}
//下载工作参数请求
int sendMyParamReq(int socketfd){
    int dataLen = 0;
    int myParamCommand = 0x4001;
    int paramID = 2;
    int retCode = 0;
    unsigned char dataBuff [1024] = {0};
    //下载参数请求
    smart_GetParamReq* myParamReq = (smart_GetParamReq*)malloc(sizeof (smart_GetParamReq));
    bzero(myParamReq,sizeof(smart_GetParamReq));
    smartgetParamReq(myParamReq,&dataLen);//获取参数请求和数据大小
    memcpy(dataBuff,(char*)myParamReq,sizeof (smart_GetParamReq));
    if(!buildSmartPacket(socketfd,myParamCommand,paramID,retCode,dataBuff,dataLen)){
        free(myParamReq);
        myParamReq = NULL;
        return FALSE;
    }
    free(myParamReq);
    myParamReq = NULL;
    return TRUE;

}
//下载工具编码表请求
int sendMyToolsReq(int socketfd){
    int dataLen = 0;
    int myToolsCommand = 0x4002;
    int paramID = 3;
    int retCode = 0;
    unsigned char dataBuff [1024] = {0};
    //下载工具参数表请求
    smart_GetToolsTableReq* myToolsTable = (smart_GetToolsTableReq*)malloc(sizeof (smart_GetToolsTableReq));
    bzero(myToolsTable,sizeof(smart_GetToolsTableReq));
    smartGetToolsReq(myToolsTable,&dataLen);//获取参数请求的数据包
    memcpy(dataBuff,(char*)myToolsTable,sizeof (smart_GetToolsTableReq));
    if(!buildSmartPacket(socketfd,myToolsCommand,paramID,retCode,dataBuff,dataLen)){
        free(myToolsTable);
        myToolsTable = NULL;
        return FALSE;
    }
    free(myToolsTable);
    myToolsTable = NULL;
    return TRUE;
}

//发送数据 buff发送缓存区
int sendSmartData(int socketfd, unsigned char *buff, int len)
{
    int writelen = 0;
    int left = len;
    int offset = 0;
    while(left > 0){
        writelen = send(socketfd,(char*)buff+offset,left,0);
        if(writelen < 0){
            return ERROR;
        }
        left -= writelen;
        offset += writelen;
    }
    return TRUE;
}

//接收服务端数据
void* recvFromServ(void* arg)
{
    unsigned char recvBuff[2048] = {0};
    int recvLen = 0;
    int status = 0;
    int continueErr = 0;
    unsigned short cmdCode;
    smart_head* headP = NULL;
    while(1){
        status = recvSmartData(socketfd,(char*)recvBuff,1024,&recvLen);
        if(status == -2){ //超时
            continue;
        }
        else if(status == -1){
            printf("recv error\n");
            break;
        }
        if(recvLen == 0){
            continueErr++;
            if(continueErr > 40){
                printf("try recv data\n");
                break;
            }
            sleep(2000);
            continue;
        }
        continueErr = 0;
        {
            headP = (smart_head*)recvBuff;
            if(!checkDataHead(headP)){
                printf("crc error\n");
                continue;
            }
            cmdCode = headP->Command[0]|headP->Command[1];
            switch (cmdCode) {
            case SmartLogin:{
                smart_login_ack *loginACK = (smart_login_ack*)((char*)recvBuff+sizeof (smart_head));
                int dataLen = sizeof (smart_login_ack);
                smartLoginRetu(loginACK,dataLen);
                printf("登录 recv success\n");
                break;
                }
            case SmartParam:{
                //消防车参数阀值
                int dataLen = headP->DataLen;
                int headLen = sizeof (smart_head);
                printf("阈值 recv success\n");
                smartParamRetu(recvBuff,dataLen,headLen);
                break;
            }
            case SmartTools:{
                //消防车tools
                int dataLen = headP->DataLen;
                int headLen = sizeof (smart_head);
                smartToolsTableRetu(recvBuff,dataLen,headLen);      
                printf("工具 recv success\n");
                break;
            }
            case SmartControl:{
                printf("sercver control command:\n");
            }
                //目前还没有其他数据
            default:
                break;

            }
        }

    }
}
//接收数据 recvlen为接收数据大小
int recvSmartData(int socketfd, char *buff, int needlen, int *recvlen)
{
    int iErr = 0;
    int bytes_read = 0,bytes_left = needlen,totalr = 0;
    char *ptr = (char*)buff;
    fd_set rfds,maskfds;
    struct timeval timeout = {10,0};
    FD_ZERO(&rfds); //清空文件标识符
    FD_SET(socketfd,&rfds); //将文件标识符放入集合中
    if(bytes_left > 0){
        maskfds = rfds;
        iErr = select(socketfd+1,&maskfds,NULL,NULL,&timeout);
        if(iErr <=0 ){
           if (iErr == 0)
               return -2; //超时
           else
               return -1; //错误
        }
        if(FD_ISSET(socketfd,&maskfds))
        {
            bytes_read = recv(socketfd,ptr,bytes_left,0);
            if(bytes_read < 0){
                if(errno = EINTR) //操作信号被中断
                    bytes_read = 0;
                else
                    return -1;
            }
            bytes_left -= bytes_read;
            ptr += bytes_read;
            totalr += bytes_read;
        }
    }
    *recvlen = totalr;
    ptr = (char*)buff;
    ptr[totalr] = '\0';
    return 0;

}

//查验包头 并计算校验和 正确返回1 不正确返回-1
int checkDataHead(smart_head* headp)
{
    smart_tail* tailp = NULL;
    int dataLen = 0;
    unsigned short crcCheck = 0;
    if(!headp){ //包头无数据
        return FALSE;
    }
    if(headp->headFlag[0] != 0xE9 || headp->headFlag[1] != 0x81 || headp->headFlag[2] != 0xB0){
        return FALSE;
    }
    dataLen = headp->DataLen+sizeof (smart_head);//数据长度加上包头长度
    if(dataLen > 1024){
        return FALSE;
    }
    tailp = (smart_tail*)((char*)headp + dataLen); //此时指向包尾
    crcCheck = dataVerifyResult((char*)tailp,dataLen);
    if(crcCheck != tailp->CRC){
        return FALSE;
    }
    return TRUE;

}

//计算校验和
int dataVerifyResult(char *data, int dataLen)
{
    int i;
    unsigned short tempval = 0;
    for(i = 0; i< dataLen;i++){
        tempval = (tempval+(data[i]&0xff))&0xffff;
    }
    return tempval;
}
//参数分别为sockfd，命令码，帧num，返回值（0代表成功），data指向数据区，datalen为数据大小
int buildSmartPacket(int socketfd, int command, unsigned char framNo, short retVal, unsigned char *data, int dataLen)
{
    int sendL = 0;
    unsigned char IPSendBuf[1024];
    smart_head* headp = NULL;
    smart_tail* tailp = NULL;
    headp = (smart_head*)IPSendBuf;
    headp->headFlag[0] = 0xE9;
    headp->headFlag[1] = 0x81;
    headp->headFlag[2] = 0xB0;
    headp->Command[0] = (command>>8)&0xff;  //int 16 位 0x4000
    headp->Command[1] = command&0xff;
    headp->packetID = framNo;
    headp->retcode = retVal;
    headp->DataLen = dataLen;

    sendL = sizeof (smart_head); //包头大小
    if(dataLen)
        memcpy(IPSendBuf+sendL,data,dataLen);
    sendL += dataLen; //包头+数据 长度
    tailp = (smart_tail*)((char*)IPSendBuf+sendL);
    tailp->CRC = dataVerifyResult((char*)IPSendBuf,sendL);
    sendL += sizeof (smart_tail);

    /** 拨号重连
     * 如果设备不存在，直接写到本地
     * 如果设备存在，  在尝试一次连接，包括第一次初始化不成功及断线重连
     *
     *  */
    if(myApp::connect == 0){    //代表已判断设备是否存在且网络连接成功后的第一次连接
        sendL = sendSmartData(socketfd,IPSendBuf,sendL);
    }
    else if(myApp::connect != 0){  //代表是尝试第一次后的n次连接
        int net = -1;
        printf("判断ppp0是否存在，即将写到本地\n");
        net = check_interface_fromproc((char*)"ppp0");
        if(net == 0){
            printf("ppp0 设备不存在\n");
            writeBuffToLocal(IPSendBuf);
        }
        if (net == 1) {         //此时拨号成功，设备ppp0存在
            printf("设备存在\n");
            printf("%d  %d \n",myApp::connect,pppd);
            if((myApp::connect == 1) && (pppd == 1)){  //第一次拨号成功且未掉线,或断线后重连成功
                sendL =  sendSmartData(socketfd,IPSendBuf,sendL);
                if(sendL){
                    printf("拨号、发送成功，未掉线\n");
                }
                else {
                    printf("发送失败 云端\n");
                }
            }
            if((myApp::connect == 2) || (pppd != 1)){    //第一次初始化失败或者曾经断号，则需要在尝试一次重新连接
                printf("第一次初始化失败\n");
                int res = myClientServer();
                printf("返回值%d\n",res);
                if(res == 1){                  //二次初始化成功
                    myApp::connect = 1;
                    pppd = 1;
                    printf("初始化失败后，发送\n");
                    initGPSInfo();                     //重新启动4g模块
                    initMyClientInfo(socketfd);
                    //system("sudo ntpdate cn.pool.ntp.org");
                    system("sudo ntpdate cn.pool.ntp.org");
                    printf("重拨号成功，将要向云端发送数据\n");
                    sendL = sendSmartData(socketfd,IPSendBuf,sendL);
                    printf("重拨号后发送成功\n");
                }
                else {
                    printf("写到本地\n");
                    writeBuffToLocal(IPSendBuf);
                }
            }
        }
    }
    return sendL;
#if 0
    /***
     *
     * 判断是否拨号成功，否则写到本地
     *
     * */
    int net = -1;
    printf("判断ppp0是否存在，即将写到本地\n");
    net = check_interface_fromproc((char*)"ppp0");
    if(net == 0){
        printf("ppp0 设备不存在\n");
        writeBuffToLocal(IPSendBuf);
    }
//    else{
//        sendL =   sendSmartData(socketfd,IPSendBuf,sendL);
//    }
    /** 拨号重连
     * 如果设备不存在，直接写到本地
     * 如果设备存在，  在尝试一次连接，包括第一次初始化不成功及断线重连
     *
     *  */
    if (net == 1) {         //此时拨号成功，设备ppp0存在
        printf("设备存在\n");
        printf("%d  %d \n",myApp::connect,pppd);
        if(myApp::connect == 1 && pppd == 1){  //第一次拨号成功且未掉线
            sendL =   sendSmartData(socketfd,IPSendBuf,sendL);
            printf("拨号成功，未掉线\n");
        }
        if((myApp::connect == 2) || (pppd != 1)){    //第一次初始化失败或者曾经断号，则需要在尝试一次重新连接
            printf("第一次初始化失败\n");
            int res = myClientServer();
            printf("返回值%d\n",res);
            if(res == 1){                  //二次初始化成功
                myApp::connect = 1;
                pppd = 1;
                printf("初始化失败后，发送\n");
                sendL = sendSmartData(socketfd,IPSendBuf,sendL);
            }
            else {
                printf("写到本地\n");
                writeBuffToLocal(IPSendBuf);
            }
        }
    }
        /** 重 ****  连 ****/
    //sendL = sendSmartData(socketfd,IPSendBuf,sendL);
#endif
}

int writeBuffToLocal(unsigned char* buff){
    printf("写到本地===========/////////////////////////=======\n");
    QString current = QDateTime::currentDateTime().toString("yyyy_MM_dd_hh_mm_ss");
    QString path = QString("/home/pi/logFile/%1").arg(current);
    char* time = path.toLatin1().data();
    FILE* fp = fopen(time,"w");
    if(fp == NULL){
        perror("打开文件失败：");
        return 0;
    }
    fwrite(buff,sizeof (char),sizeof (buff)/sizeof (char),fp);
    fflush(fp);
    fclose(fp);

    //删除多余文件
    QDir dir("/home/pi/logFile/");
    QStringList nameFileters;
    nameFileters<<"2020*";
    QStringList files = dir.entryList(nameFileters,QDir::Files | QDir::Readable,QDir::Name);
    if(files.size() >= 100){
        for(int i = 0;i < files.size();i++){
            QString filrPath = "/home/pi/logFile/" + files[i];
            QFile curFile(filrPath);
            if(curFile.exists()){
                curFile.remove();
            }
        }
    }
    return 1;
}




