#ifndef GETCANDATA_H
#define GETCANDATA_H

#include "controlcan.h"
/**
*@file  getcandata.h
*@brief  解析bbm和k60数据
*/
/*
	发动机转速     消息ID：0x0CF00400
	发动机油温/发动机冷却液温度 消息ID:  0x18FEEE00
	燃油液位    消息ID：0x18FEFC17
	蓄电池电压  消息ID：0x18FEF700
	轮胎压力    消息ID: 0x18FEF40B
*/

typedef unsigned char INT8U;
typedef unsigned short INT16U;
typedef unsigned int INT32U;
#define RX_BUFF_SIZE 1000      //接收can数据最大帧数
//can数据结构体
typedef struct{
    VCI_CAN_OBJ recvBuff[RX_BUFF_SIZE];
    int recCnt;
} CAN_DATA;
/****** bbm数据结构体存储 ********/

#define ENGINE_SP           0x0CF00400    //发动机转速 r/min
#define COOL_TEMP           0x18FEEE00    //发动机冷却液温度
#define OIL_TEMP            0x18FF3BFD    //发动机油温
#define FUEL_LEVEL          0x18FEFC17    //燃油液位
#define BATTERY_VOL         0x18FEF700    //蓄电池电压
//#define TIRE_PRESSURE       0x18FEF40B    //轮胎压力

typedef struct{
    INT8U tryeID[10];
    INT16U pressValue[10];
}bbm_tryeDataInfo;

typedef struct{
    float rpm;
    float oilTemp;
    float coolLiquidTemp;
    float oilLevel;
    float batteryVolatge;
}bbm_canData;

/******* k60数据结构体存储 ********/

#define LIQUID_DISPLAY     0x18FE2000   //泡沫罐、水罐液位 消防炮流量 泡沫流量
#define DISTANCE_WORKTIME  0x18FE2001   //左、右、后侧距离 出水压力传感器 低压
#define PIPE_PRESSURE      0x18FE2002   //引水时间 水泵工作时间 中压 真空 水泵转速
#define RFID_STATE         0x18FE2005   //rfid缺失数据
#define DOOR_STATE         0x18FE2004   //门开关状态 火场周边温度 可燃气体浓度

extern int rfid_can_recv;
extern int liquid_flag;

typedef struct{
    float mfoamLevel;      //泡沫罐液位
    float mwaterLevel;     //水罐液位
    float flowRate;        //消防炮流量
    float foamRate;        //泡沫流量
}k60_liquidLevel;

typedef struct{
    int distance_left;     //左侧距离
    int distance_right;    //右侧距离
    int distance_late;     //后侧距离
    int waterRunTime;            //水泵引水时间
    unsigned int RpmSpeed;       //水泵转速
}k60_distanceTime;

typedef struct{
    float wPressLow;       //低压  mpa
    unsigned char gasRate;  //可燃气体浓度
    float mAirPress;        //真空  mpa
    float pimRunTime;  //水泵工作时间
}k60_pressure;

typedef struct{
    int doorstate;          //门状态
    unsigned char fireTemp; //火场周边温度
    unsigned char valveOpen; //阀门开度
}k60_doorState;

typedef struct{
    unsigned int rfid_state_1;
    unsigned char rfid_state_2;
} k60_rfidState;
//解析can数据  包括bbm和k60
void parse_canFrame(CAN_DATA can1Data,bbm_tryeDataInfo* bbm_trye,bbm_canData* bbm_data,k60_liquidLevel* k60_liquidLev,k60_distanceTime* k60_distance,
                    k60_pressure* k60_press,k60_doorState* k60_doorState,k60_rfidState* k60_rfid);

#endif // GETCANDATA_H
