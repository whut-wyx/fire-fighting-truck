#include "controlcan.h"
#include "getcandata.h"

#include <stdio.h>
#include <stdint.h>

#if 1

int rfid_can_recv = 0;
int liquid_flag = 0;
void parse_canFrame(CAN_DATA can1Data,bbm_tryeDataInfo* bbm_trye,bbm_canData* bbm_data,k60_liquidLevel* k60_liquidLev,k60_distanceTime* k60_distance,
                    k60_pressure* k60_press,k60_doorState* k60_doorState,k60_rfidState* k60_rfid)
{
    int i;
    //printf("this is parse_frame 刚开始的地方\n");
    for(i = 0; i < can1Data.recCnt;i++){
        if(can1Data.recvBuff[i].DataLen != 8){
            continue;
        }
        switch (can1Data.recvBuff[i].ID) {
        case COOL_TEMP: //摄氏度
            //printf("this is 冷却液温度\n");
            if(can1Data.recvBuff[i].Data[0] != 0xff){
                bbm_data->coolLiquidTemp = (float)(can1Data.recvBuff[i].Data[0])-40;
            }
            //printf("冷却液原始数据：%x\n",can1Data.recvBuff[i].Data[0]);
            //printf("冷却液温度：%f\n",bbm_data->coolLiquidTemp);
            break;
        case OIL_TEMP: //摄氏度
            //printf("this is 燃油温度\n");
            if((can1Data.recvBuff[i].Data[3] != 0xff) || (can1Data.recvBuff[i].Data[4] != 0xff)){
                bbm_data->oilTemp  = (float)((uint16_t)(can1Data.recvBuff[i].Data[3] << 8) | can1Data.recvBuff[i].Data[4])* 0.03125-273;
            }
            //printf("燃油温度原始数据：%x %x\n",can1Data.recvBuff[i].Data[3],can1Data.recvBuff->Data[4]);
            //printf("燃油温度%f\n",bbm_data->oilTemp);
            break;
        case FUEL_LEVEL:   //%  占比
            //printf("this is 燃油液位\n");
            if((can1Data.recvBuff[i].Data[1]!=0xff)){
                bbm_data->oilLevel=(float)can1Data.recvBuff[i].Data[1]*0.4;
            }
            //printf("燃油液位原始数据：%x\n",can1Data.recvBuff[i].Data[1]);
            //printf("燃油液位%f\n",bbm_data->oilLevel);
            break;
        case BATTERY_VOL: //V
            //printf("this is 蓄电池电压\n");
            if((can1Data.recvBuff[i].Data[6] != 0xff) || (can1Data.recvBuff[i].Data[7] != 0xff)){
                bbm_data->batteryVolatge=(float)((uint16_t)(can1Data.recvBuff[i].Data[7] << 8) + can1Data.recvBuff[i].Data[6])* 0.05;
            }
            //printf("蓄电池电压原始数据：%x %x\n",can1Data.recvBuff[i].Data[5],can1Data.recvBuff[i].Data[6]);
            //printf("蓄电池电压原始数据七八字节：%x %x\n",can1Data.recvBuff[i].Data[6],can1Data.recvBuff[i].Data[7]);
            //printf("蓄电池电压 %f\n",bbm_data->batteryVolatge);
            break;

        /***** k60 can_data ******/
        case LIQUID_DISPLAY:
            printf("this is 液位\n");
            if(((can1Data.recvBuff[i].Data[0] & can1Data.recvBuff[i].Data[1]) != 0xff)){
                k60_liquidLev->mwaterLevel = (float)(((uint16_t)(can1Data.recvBuff[i].Data[0] << 8) | can1Data.recvBuff[i].Data[1]));
                printf("水罐液位第一个字节:%x %x\n",can1Data.recvBuff[i].Data[0],can1Data.recvBuff->Data[1]);
                printf("获取到的水罐液位：%f\n",k60_liquidLev->mwaterLevel);
            }
            if(((can1Data.recvBuff[i].Data[2] & can1Data.recvBuff[i].Data[3]) != 0xff)){
                k60_liquidLev->mfoamLevel = (float)(((uint16_t)(can1Data.recvBuff[i].Data[2] << 8) | can1Data.recvBuff[i].Data[3]));
                printf("泡沫罐液位第一个字节：%x   %x\n",can1Data.recvBuff[i].Data[2],can1Data.recvBuff[i].Data[3]);
                printf("获取到的泡沫罐液位：%f\n",k60_liquidLev->mfoamLevel);
            }
            if(((can1Data.recvBuff[i].Data[4] & can1Data.recvBuff[i].Data[5]) != 0xff)){
                k60_liquidLev->flowRate = (float)(((uint16_t)(can1Data.recvBuff[i].Data[4] << 8) | can1Data.recvBuff[i].Data[5])*0.15298); // L/s
                printf("水流量第一个字节:%x   %x\n",can1Data.recvBuff[i].Data[4],can1Data.recvBuff[i].Data[5]);
                printf("获取到的水流量：%f\n",k60_liquidLev->flowRate);
            }
            if(((can1Data.recvBuff[i].Data[6] & can1Data.recvBuff[i].Data[7]) != 0xff)){
                k60_liquidLev->foamRate = (float)(((uint16_t)(can1Data.recvBuff[i].Data[6] << 8) | can1Data.recvBuff[i].Data[7])*0.0294*0.73);// L/s
                printf("泡沫流量第一个字节:%x  %x\n",can1Data.recvBuff[i].Data[6],can1Data.recvBuff[i].Data[7]);
                printf("获取到的泡沫流量:%f\n",k60_liquidLev->foamRate);
            }
            liquid_flag = 1;
            break;
        case DISTANCE_WORKTIME:
            printf("this is 距离\n");
            if(((can1Data.recvBuff[i].Data[0] & can1Data.recvBuff[i].Data[1]) != 0xff)){
                k60_distance->distance_late = (int)(((uint16_t)(can1Data.recvBuff[i].Data[0])) << 8 | can1Data.recvBuff[i].Data[1]);
            }
            if(((can1Data.recvBuff[i].Data[2] & can1Data.recvBuff[i].Data[3]) != 0xff)){
                k60_distance->distance_left = (int)((uint16_t)(can1Data.recvBuff[i].Data[2] << 8) | can1Data.recvBuff[i].Data[3]);
                printf("距离字节 %x %x\n",can1Data.recvBuff[i].Data[2],can1Data.recvBuff[i].Data[3]);
                printf("左侧距离：%d\n",k60_distance->distance_left);
            }
            if(((can1Data.recvBuff[i].Data[4] & can1Data.recvBuff[i].Data[5]) != 0xff)){
                k60_distance->distance_right = (int)((uint16_t)(can1Data.recvBuff[i].Data[4] << 8) | can1Data.recvBuff[i].Data[5]);
                printf("距离字节 %x %x\n",can1Data.recvBuff[i].Data[4],can1Data.recvBuff[i].Data[5]);
                printf("右侧距离：%d\n",k60_distance->distance_right);
            }
            if(can1Data.recvBuff[i].Data[6] != 0xff){
                printf("--------引水时间\n");
                k60_distance->waterRunTime = (int)can1Data.recvBuff[i].Data[6];   //50s
                printf("引水时间:%x\n",can1Data.recvBuff[i].Data[6]);
            }
            if(can1Data.recvBuff[i].Data[7] != 0xff){
                k60_distance->RpmSpeed = (unsigned int)(can1Data.recvBuff[i].Data[7]*60);// r/min
                //printf("水泵字节:%x\n",can1Data.recvBuff[i].Data[7]);
                //printf("获得的水泵转速：%d\n",k60_distance->RpmSpeed);
            }
            break;
        case PIPE_PRESSURE:
            printf("this is 压力\n");
            if(((can1Data.recvBuff[i].Data[0] & can1Data.recvBuff[i].Data[1]) != 0xff)){
                k60_press->wPressLow = (float)((uint16_t)(can1Data.recvBuff[i].Data[0] << 8) | can1Data.recvBuff[i].Data[1])/1000;  //低压   Mpa
                printf("低压收到的字节:%x  %x\n",can1Data.recvBuff[i].Data[0],can1Data.recvBuff[i].Data[1]);
                printf("获得的低压数据：%f\n",k60_press->wPressLow);
            }
            if(((can1Data.recvBuff[i].Data[2] & can1Data.recvBuff[i].Data[3]) != 0xff) && (can1Data.recvBuff[i].Data[2] != 0xff)){
                k60_press->gasRate = (float)((uint16_t)(can1Data.recvBuff[i].Data[2] << 8) | can1Data.recvBuff[i].Data[3])/1000;   //中压  Mpa
                printf("可燃气体浓度字节 %x  %x\n",can1Data.recvBuff[i].Data[2],can1Data.recvBuff[i].Data[3]);
                printf("可燃气体浓度。。。。。%d\n",k60_press->gasRate);
            }
            if(((can1Data.recvBuff[i].Data[4] & can1Data.recvBuff[i].Data[5]) != 0xff)){
                k60_press->mAirPress = (float)((uint16_t)(can1Data.recvBuff[i].Data[4] << 8) | can1Data.recvBuff[i].Data[5])/1000; //可能为负数 Mpa
                printf("真空气压:%x   %x\n",can1Data.recvBuff[i].Data[4],can1Data.recvBuff[i].Data[5]);
                printf("获得的真空气压：%f\n",k60_press->mAirPress);
            }
            if(((can1Data.recvBuff[i].Data[6] & can1Data.recvBuff[i].Data[7]) != 0xff)){
                k60_press->pimRunTime = (float)((uint16_t)(can1Data.recvBuff[i].Data[6]<<8 | can1Data.recvBuff[i].Data[7]))*10/3600.0;//小时h
                printf("水泵工作时间：%x %x\n",can1Data.recvBuff[i].Data[6],can1Data.recvBuff[i].Data[7]);
                printf("解析后的工作时间：%f\n",k60_press->pimRunTime);
            }
            break;
        case DOOR_STATE:
            printf("this is 门状态\n");
            k60_doorState->doorstate = (int)((can1Data.recvBuff[i].Data[0]) | (can1Data.recvBuff[i].Data[1] << 8));
            if(can1Data.recvBuff[i].Data[6] != 0xff){
                k60_doorState->fireTemp = (unsigned char)(can1Data.recvBuff[i].Data[6]);
                printf("可燃气体温度字节:%x\n",can1Data.recvBuff[i].Data[6]);
            }
            if(can1Data.recvBuff[i].Data[7] != 0xff){
                k60_doorState->valveOpen = (unsigned char)(can1Data.recvBuff[i].Data[7]);
            }
            break;
        case RFID_STATE:
            printf("this is rfid状态\n");
            rfid_can_recv = 1;
            k60_rfid->rfid_state_1 = (unsigned int)(can1Data.recvBuff[i].Data[3] << 24 | can1Data.recvBuff[i].Data[2] << 16 | can1Data.recvBuff[i].Data[1] << 8 | can1Data.recvBuff[i].Data[0]);
            k60_rfid->rfid_state_2 = (unsigned char)can1Data.recvBuff[i].Data[4];
            printf("++++++++rfid四个字节：%x %x %x %x %x\n",can1Data.recvBuff[i].Data[0],can1Data.recvBuff[i].Data[1],can1Data.recvBuff[i].Data[2],can1Data.recvBuff[i].Data[3],can1Data.recvBuff[i].Data[4]);
            break;
        default:
            break;
        }
    }
}
#endif
