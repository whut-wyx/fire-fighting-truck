#ifndef MYAPP_H
#define MYAPP_H

#include <QString>
#include <QList>

typedef struct _warnValueLmt{
    _warnValueLmt(){}
    _warnValueLmt(const int& _warnType,const int& _devType,const int& _valueMde,const float& _highVal,const float& _lowVal):
                  paramType(_warnType),devType(_devType),valueMde(_valueMde),highVal(_highVal),lowVal(_lowVal)
    {}
    int paramType;
    int devType;
    int valueMde;
    float highVal;
    float lowVal;

}warnValueLimit;

class myApp
{

public:
    static int connect;
    static int dataTran;
    static float tankH; //罐体高度
    static float pipePress;//管道压力
    /************* 登录请求返回 *************/
    static int year;
    static int month;
    static int date;
    static int hour;
    static int min;
    static int seconds;
    static QString random;
    static QString carSn;             //车辆编号
    static QString carNumber;         //车牌号
    static QString carType;
    static int liveUp;
    static int locked;
    static int devType;
    static int isRegister;
    static int isBind;

    /************* 工作参数返回 **************/
    static QString version;                   //版本号
    static QString deptNo;                    //使用单位编号
    static int tyreCounts;                    //轮台个数

    static  warnValueLimit engineSpeedStr;    //发动机转速  暂无
    static  warnValueLimit engineTempStr;     //发动机温度
    static  warnValueLimit coolLiquidStr;     //冷却液温度  暂无
    static  warnValueLimit PTOTempStr;        //取力器温度
    static  warnValueLimit PTOOilLevelStr;    //取力器内机油位
    static  warnValueLimit fuelLevelStr;      //油箱油位

    static warnValueLimit typeTemp;   //胎温
    static warnValueLimit typePre;     //胎压
    static warnValueLimit rpmSpeed;    //水泵转速
    static warnValueLimit rpmTime;     //水泵工作时间
    static warnValueLimit fireMontor;   //消防炮出水量
    static warnValueLimit mPressLow;  //管道出水压力  低压
    static warnValueLimit airPress;     //真空度
    static warnValueLimit mPressMid;  //管道出水压力 中压
    static warnValueLimit drawWaterTime; //引水时间
    static warnValueLimit waterLev;     //水罐液位
    static warnValueLimit foamLev;        //泡沫液位
    static warnValueLimit leftDistance;   //左侧距离
    static warnValueLimit rightDistance;  //右侧距离
    static warnValueLimit fontDistance;   //前侧距离
    static warnValueLimit bhindDsitance;   //后侧距离


    /*************工具编码表返回*************/
    static int toolsCount;                    //工具个数(总数)

    static QList<int> bindToolsCode;          //存储tools编码


public:
    static void writeLoginToConfig(const QString& random, const QString& carSn, const QString& carNum, const QString& carType, unsigned char *sysTime,
                                  const int liveUp, const int& locked, const int& devType, const int& devRegis, const int& devBind);
    static void writeSysParamToConfig(const QString& version,const QString& depNo,const int& tyreCount);

    static void writeToolsTableToConfig(const int& count);

    static void writeConfig();

    static void readConfig();
};

#endif // MYAPP_H
