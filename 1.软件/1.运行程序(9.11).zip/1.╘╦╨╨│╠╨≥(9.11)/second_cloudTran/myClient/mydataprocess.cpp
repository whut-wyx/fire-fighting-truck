#include "mydataprocess.h"
#include "pthread_global.h"
extern "C"{
#include "gps_data/getGPS_info.h"
}

#include <stdio.h>
#include <string.h>
#include <QDate>
#include <QTime>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>


#if 1
smart_ReportDatainfo  reportInfo;
smart_Datainfo  dataInfo;
smart_SubStatusinfo subStatusInfo;
smart_Carinfo carInfo;
//smart_Toolinfo* toolInfo = NULL;
smart_BoxDoorinfo boxDoorInfo;
smart_Rangeinfo rangeInfo;
smart_LiquidDevinfo liquidInfo;

unsigned long indic;
unsigned long lati;


#define PROCBUFSIZ                  1024
#define _PATH_PROC_NET_DEV        "/proc/net/dev"

void generateDataBuff(unsigned char *data, int *dataLen,QList<int> updateNum){
    unsigned char dataBuff[1024] = {0};
    int addr = 0;
    for(int i=0;i < updateNum.size();i++){    // 1 8 16 32 4
        int num = updateNum.at(i);
        switch (num) {
        case SUBSTATAUS: // 1
            //printf("switch 状态子系统\n");
            dataInfo.DevType = 0x01;
            dataInfo.DataType = 11;
            dataInfo.DataLen = sizeof(smart_SubStatusinfo);
            memcpy(dataBuff+addr,&dataInfo,sizeof (smart_Datainfo));
            addr += sizeof (smart_Datainfo);
            memcpy(dataBuff+addr,&subStatusInfo,sizeof (smart_SubStatusinfo));
            addr += sizeof (smart_SubStatusinfo);
            break;
        case CARINFO: // 2
//            for(int j =0;j<8;j++){
                //函数赋值
//            }
            dataInfo.DevType = 0x01;
            dataInfo.DataType = 12;
            dataInfo.DataLen = sizeof(smart_Carinfo);
            memcpy(dataBuff+addr,&dataInfo,sizeof (smart_Datainfo));
            addr += sizeof(smart_Datainfo);
            memcpy(dataBuff+addr,&carInfo,sizeof (smart_Carinfo));
            addr += sizeof(smart_Carinfo);
            break;
        case TOOLINFO:{ // 4
            //printf("switch 工具缺失\n");
            smart_Toolinfo* tools_P = NULL;
            for(int j = 0 ;j < tool_missCount;j++){
                tools_P = (smart_Toolinfo*)(toolBuff + i*sizeof (smart_Toolinfo));
                dataInfo.DevType = 0x01;
                dataInfo.DataType = 13;
                dataInfo.DataLen = sizeof(smart_Toolinfo);
                memcpy(dataBuff+addr,&dataInfo,sizeof(smart_Datainfo));
                addr += sizeof (smart_Datainfo);
                memcpy(dataBuff+addr,tools_P,sizeof(smart_Toolinfo));
                addr += sizeof(smart_Toolinfo);
            }
        }
            break;
        case BOXDOORINFO: // 8
            //printf("switch 门状态\n");
            dataInfo.DevType = 0x01;
            dataInfo.DataType = 14;
            dataInfo.DataLen = sizeof(smart_BoxDoorinfo);
            memcpy(dataBuff+addr,&dataInfo,sizeof(smart_Datainfo));
            addr += sizeof(smart_Datainfo);
            memcpy(dataBuff+addr,&boxDoorInfo,sizeof(smart_BoxDoorinfo));
            addr += sizeof(smart_BoxDoorinfo);
            break;
        case RANGEINFO: // 16
            //printf("switch 距离\n");
            dataInfo.DevType = 0x01;
            dataInfo.DataType = 15;
            dataInfo.DataLen = sizeof(smart_Rangeinfo);
            memcpy(dataBuff+addr,&dataInfo,sizeof(smart_Datainfo));
            addr += sizeof(smart_Datainfo);
            memcpy(dataBuff+addr,&rangeInfo,sizeof(smart_Rangeinfo));
            addr += sizeof(smart_Rangeinfo);
            break;
        case LIQUIDINFO:// 32
            //printf("switch 液位子系统\n");
            dataInfo.DevType = 0x02;
            dataInfo.DataType = 21;
            dataInfo.DataLen = sizeof (smart_LiquidDevinfo);
            memcpy(dataBuff+addr,&dataInfo,sizeof (smart_Datainfo));
            addr += sizeof (smart_Datainfo);
            memcpy(dataBuff+addr,&liquidInfo,sizeof (smart_LiquidDevinfo));
            addr += sizeof(smart_LiquidDevinfo);
            break;
        default: break;
        }
    }
    strcpy((char*)&reportInfo.DeviceNo,"ZD000028");
    strcpy((char*)&reportInfo.CarNum,myApp::carNumber.toUtf8().data());
    strcpy((char*)&reportInfo.DriveID,"123456789012345");
    QDate date(QDate::currentDate());
    reportInfo.mColDataTime[0] = date.year();
    reportInfo.mColDataTime[1] = date.day();
    QTime time(QTime::currentTime());
    reportInfo.mColDataTime[2] = time.hour();
    reportInfo.mColDataTime[3] = time.minute();
    //获取当前GPS位置
    getGPSInfo(&indic,&lati);
    reportInfo.X[0] = indic / 100000;
    reportInfo.X[1] = indic % 100000;
    reportInfo.X[2] = (indic % 100000) >> 8;
    reportInfo.X[3] = (indic % 100000) >> 16;
    reportInfo.Y[0] = lati / 100000;
    reportInfo.Y[1] = lati % 100000;
    reportInfo.Y[2] = (lati % 100000) >> 8;
    reportInfo.Y[3] = (lati % 100000) >> 16;
    //memset(reportInfo.X,0,4);
    //memset(reportInfo.Y,0,4);
    reportInfo.WarnMsgVal = 0;
    printf("----------------------------GPS位置：%ld   %ld\n",indic,lati);
    getWarnVal(reportInfo.WarnMsgVal);

    reportInfo.speed = 0xff;         //无法获得速度
    reportInfo.bMainDev = 1;
    reportInfo.bLiquidDev = 1;
    reportInfo.bOilCtlDev = 1;
    reportInfo.bAutoStart = 1;
    reportInfo.DataLen = addr;
    *dataLen = addr + sizeof (smart_ReportDatainfo);
    memcpy(data,(char*)&reportInfo,sizeof (smart_ReportDatainfo));
    memcpy(data+sizeof (smart_ReportDatainfo),dataBuff,addr);

}

char * interface_name_cut (char *buf, char **name)
{
  char *stat;
  /* Skip white space.  Line will include header spaces. */
  while (*buf == ' ')
    buf++;
  *name = buf;
  /* Cut interface name. */
  stat = strrchr (buf, ':');
  *stat++ = '\0';
  return stat;
}

int check_interface_fromproc(char *inter)
{
  FILE *fp;
  char buf[PROCBUFSIZ];
  struct interface *ifp;
  char *name;

  /* Open /proc/net/dev. */
  fp = fopen (_PATH_PROC_NET_DEV, "r");
  if (fp == NULL)
    {
        printf("open proc file error\n");
      return -1;
    }

  /* Drop header lines. */
  fgets (buf, PROCBUFSIZ, fp);
  fgets (buf, PROCBUFSIZ, fp);

  /* Only allocate interface structure.  Other jobs will be done in
     if_ioctl.c. */
  while (fgets (buf, PROCBUFSIZ, fp) != NULL)
    {
      interface_name_cut (buf, &name);
      if(strcmp(inter,name)==0)
          return 1;
    }
  fclose(fp);
  return 0;
}

void LogBuffer(unsigned char * buf,int len)
{
    unsigned char * ptrc;
    char tempBuf[8192];
    int i,templen=0;

    memset(tempBuf,0,sizeof(tempBuf));
    ptrc =(unsigned char *) buf;
    templen+=sprintf(tempBuf+templen,"%d len data is:\n",len);
    templen+=sprintf(tempBuf+templen,"--+-----------------------------------------------\n" );
    templen+=sprintf(tempBuf+templen,"  |00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n" );
    templen+=sprintf(tempBuf+templen,"--+-----------------------------------------------" );
    for ( i=0; i<len; i++ )
    {
        if ((i % 16) == 0)
        {
            templen+=sprintf(tempBuf+templen,"\n");
            templen+=sprintf(tempBuf+templen,"%1d0|", (i>>4) );
        }
        templen+=sprintf(tempBuf+templen,"%2X ", *ptrc++ );
    }
    templen+=sprintf(tempBuf+templen,"\n");
    templen+=sprintf(tempBuf+templen,"--+-----------------------------------------------\n" );
    printf("%s\n",tempBuf);
    return ;

}

void getWarnVal(unsigned int& warnVal){
    if(!warnMsgVal(myApp::engineSpeedStr,subStatusInfo.rpm)){
        warnVal |= 0x01;
    }
    if(!warnMsgVal(myApp::coolLiquidStr,subStatusInfo.CoolLiquidTemp)){
        warnVal |= 0x02;
    }
    if(!warnMsgVal(myApp::engineTempStr,subStatusInfo.OilTemp)){
        warnVal |= 0x04;
    }
    if(!warnMsgVal(myApp::fuelLevelStr,subStatusInfo.OilLevel)){
        warnVal |= 0x08;
    }

    if((!warnMsgVal(myApp::leftDistance,rangeInfo.mLeft)) ||
            (!warnMsgVal(myApp::rightDistance,rangeInfo.mRight)) ||
            (!warnMsgVal(myApp::bhindDsitance,rangeInfo.mBehind))){
        warnVal |= 0x100;
    }
    if(!warnMsgVal(myApp::rpmSpeed,liquidInfo.RpmSpeed)){
        warnVal |= 0x800;
    }
    if(!warnMsgVal(myApp::fireMontor,liquidInfo.FlowRate)){    //消防炮出水流量
        warnVal |= 0x1000;
    }
    if(!warnMsgVal(myApp::mPressLow,liquidInfo.wPressLow)){
        warnVal |= 0x2000;
    }
    if(!warnMsgVal(myApp::airPress,liquidInfo.mAirPress)){
        warnVal |= 0x4000;
    }
    if(!warnMsgVal(myApp::foamLev,liquidInfo.mfoamLevel)){
        warnVal |= 0x8000;
    }
    if(!warnMsgVal(myApp::waterLev,liquidInfo.mWaterLevel)){
        warnVal |= 0x10000;
    }
    if(!warnMsgVal(myApp::mPressMid,liquidInfo.wPressMid)){
        warnVal |= 0x40000;
    }
    if(!warnMsgVal(myApp::rpmTime,liquidInfo.mpimpRuntime)){
        warnVal |= 0x80000;
    }
    if(!warnMsgVal(myApp::drawWaterTime,liquidInfo.mGetWatertime)){
        warnVal |= 0x100000;
    }

}

int warnMsgVal(warnValueLimit valueLimit,float value){
    int type = 0;
    type = valueLimit.valueMde;
    switch (type) {
    case 0x01:
        if(value < valueLimit.highVal){
            return 1;
        }
        break;
    case 0x02:
        if(value > valueLimit.lowVal){
            return 1;
        }
        break;
    case 0x03:
        if((value < valueLimit.highVal) & (value > valueLimit.lowVal)){
            return 1;
        }
        break;
    default:
        break;
    }
    return 0;
}
#endif


