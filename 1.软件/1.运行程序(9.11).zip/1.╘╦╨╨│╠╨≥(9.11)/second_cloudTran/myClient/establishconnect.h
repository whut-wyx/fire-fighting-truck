#ifndef ESTABLISHCONNECT_H
#define ESTABLISHCONNECT_H

/**
*@file establishconnect.h
*@brief 完成收发通信
*/

#include <pthread.h>

typedef unsigned char INT8U;
typedef unsigned short INT16U;
typedef unsigned int INT32U;

//全局变量声明
extern int socketfd;
extern int pppd;
extern pthread_t ppp0;

enum smartOrignData{
    SmartLogin = 64,  //命令码为0x4000
    SmartParam = 65,  //命令码为0x4001
    SmartTools = 66,  //命令码为0x4002
    SmartControl = 80 //服务器远程控制指令
};

//包头
typedef struct _smart_head
{
    INT8U headFlag[3];   //头部标识 固定为0xE981B0
    INT8U Command[2];    //命令码
    INT8U packetID;      //序列号，递增  最大255？
    INT16U retcode;      //返回值，0表示成功，-1为失败

    INT16U DataLen;      //本次数据包长度

}smart_head;

//包尾
typedef struct _smart_tail
{
    INT16U CRC;   //校验和
}smart_tail;
//执行拨号函数 完成网络连接
void executeConnectNet();

void* ppp_4g(void* arg);

int myClientServer();
//初始化数据，包括设备登录、下载工作参数和工具表
int initMyClientInfo(int socketfd);
int sendMyLoginReq(int socketfd);                            //登录请求
int sendMyParamReq(int socketfd);                            //下载工作参数请求
int sendMyToolsReq(int socketfd);                            //下载工具编码表请求
//初始化信息，接收服务端
int recvInitInfo(int socketfd);
/** 三个线程 **/
//接收来自服务器的信息
void* recvFromServ(void* arg);

//CRC校验
int dataVerifyResult(char* data,int len);
//发送数据
int sendSmartData(int socketfd,unsigned char* buff,int len);
//接受数据
int recvSmartData(int socketfd,char* buff,int needlen,int* recvlen);

//截取数据包的正确大小 （应该不需要）
//int resizeDataLen(char* buff,char* myBuff,int len);

//查验包头
int checkDataHead(smart_head* headp);

//生成数据包
int buildSmartPacket(int socketfd,int command,unsigned char framNo,short retVal,unsigned char* data,int dataLen);

//将数据buff写到本地
int writeBuffToLocal(unsigned char* buff);

#endif // ESTABLISHCONNECT_H
