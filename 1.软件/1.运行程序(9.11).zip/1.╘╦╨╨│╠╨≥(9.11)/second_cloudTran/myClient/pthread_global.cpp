#include "myapp.h"
#include "controlcan.h"
#include "mydataprocess.h"
#include "plc_screen/ipc.h"
#include "pthread_global.h"
#include "establishconnect.h"

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <QList>
#include <fcntl.h>

/** 完成can卡的必要设置 初始化 接收can数据 */
#define MAX_CAHNNELS 4
#define RX_WAIT_TIME 100   //ms 接收超时时间
//#define RX_BUFF_SIZE 1000  //接收最大帧数
#define msleep(ms) usleep((ms)*1000)

unsigned gDevType = 0;
unsigned gDevIdx = 0;
unsigned gChMask = 0;
unsigned gBaud = 0;
int dataFlag = 0;

/********* 全局变量 一些结构体********/
/** bbm全局变量*/
bbm_tryeDataInfo bbm_tryePressure;       //胎压
bbm_canData bbm_dataInfo;                //发动机转速、油温、冷却液温度 燃油液位 蓄电池电压

/** k60全局变量*/
k60_liquidLevel k60_liqudLev;            //泡沫罐、水罐液位 消防炮流量 泡沫流量
k60_distanceTime k60_disTime;            //左、右、后侧距离 水泵引水时间 水泵转速
k60_pressure k60_waterPress;             //低压 中压 真空 水泵工作时间
k60_doorState k60_door;                  //门开关状态 火场周边温度 可燃气体浓度
k60_rfidState k60_rifd;                  //rfid工具缺失状态

unsigned char toolBuff[160] = {0};             //存储工具缺失结构体数据
int tool_missCount = 0;                        //存储工具缺失数量
static QList<int> updateNum;

/** can数据读取 需在3399运行 */
# if 1
//can数据结构体变量
CAN_DATA can1Data;
CAN_DATA can2Data;
RX_PARSE_CTX ctx_can1;
RX_PARSE_CTX ctx_can2;
// can数据发送 rifd扫描
VCI_CAN_OBJ rfidFrame;
VCI_CAN_OBJ pipePreFrame;
VCI_CAN_OBJ cleanPimFrame;
unsigned char pipePress_temp = 0xff;          //用来存储压力 当压力值不变的时候不传送can数据帧
unsigned char foamRateTemp = 0xff;
unsigned char cleanPimTemp = 0;
/** 用来读取can数据 发送云端数据 写进共享内存 */

pthread_t can_pth,cloud_pth,shm_pth,recv_pth;
pthread_rwlock_t rwlock;

/** 开始初始化can卡 包括所有设置 */
int initCanCard()
{
    //设置通道
    ctx_can1.channel = 0;
    ctx_can1.stop = 0;
    ctx_can1.error = 0;

    ctx_can2.channel = 1;
    ctx_can2.stop = 0;
    ctx_can2.error = 0;

    gDevType = 4;     //设备类型 4-usbcan-ii
    gDevIdx = 0;      //设备索引号 Card0
    gChMask = 3;      //通道掩码  3 = CAN1 + CAN2
    gBaud = 0x1c01;   //波特率

    if(!VCI_OpenDevice(gDevType,gDevIdx,0)){
        printf("VCI_OpenDevice failed\n");
        return 0;
    }
    printf("VCI_OPenDevice succeeded\n");

    if(!startCanCard()){
        printf("start can failed\n");
        return 0;
    }
    return 1;
}

/** 初始化启动can卡 包括设置屏蔽码 滤波 */
int startCanCard()
{
    //VCI_INIT_CONFIG结构体将在 VCI_InitCAN 函数中被填充，即初始化之前，要先填好这个结构体变量。
    VCI_INIT_CONFIG config[2];        //VCI_INIT_CONFIG 结构体定义了初始化 CAN 的配置
    config[0].AccCode = 0xc7f10000;            //验收码
    config[0].AccMask = 0x0006ffff;   //屏蔽码，0xffffffff为全部接收
    config[0].Filter = 1;             //滤波方式 =1表示单滤波 =0表示双滤波
    config[0].Mode = 0;               //模式 =0 表示正常模式（相当于正常结点） =1 表示只听模式
    config[0].Timing0 = gBaud & 0xff; //波特率设置
    config[0].Timing1 = gBaud >> 8;

    config[1].AccCode = 0x67802000;            //验收码
    config[1].AccMask = 0x00000007;   //屏蔽码，0xffffffff为全部接收
    config[1].Filter = 1;             //滤波方式 =1表示单滤波 =0表示双滤波
    config[1].Mode = 0;               //模式 =0 表示正常模式（相当于正常结点） =1 表示只听模式
    config[1].Timing0 = gBaud & 0xff; //波特率设置
    config[1].Timing1 = gBaud >> 8;

    int i;
    //初始化can0 can1通道
    for(i = 0;i < MAX_CAHNNELS; i++){                  //通道掩码的使用bit0-CAN1, bit1-CAN2, bit2-CAN3, bit3-CAN4, 3=CAN1+CAN2, 7=CAN1+CAN2+CAN3
        if((gChMask & (1 << i)) == 0)
            continue;
        if(!VCI_InitCAN(gDevType,gDevIdx,i,&config[i])){  //用以初始化指定的 CAN 通道。有多个 CAN 通道时，需要多次调用
            printf("VCI_InitCAN(%d) filed\n",i);
            return 0;
        }
        printf("VCI_InitCAN(%d) succeeded\n",i);
        if(!VCI_StartCAN(gDevType,gDevIdx,i)){         //用以启动 CAN 卡的某一个 CAN 通道。有多个 CAN 通道时，需要多次调用
            printf("VCI_StartCAN(%d) failed\n",i);
            return 0;
        }
        printf("VCI_SatrtCAN(%d) succeed\n",i);
    }
    return 1;
}

void createPthread()
{
    printf("创建线程\n");
    pthread_rwlock_init(&rwlock,NULL);
    printf("初始化读写锁\n");
    pthread_create(&can_pth,NULL,getCANData,NULL);//拿到can的原始数据
    pthread_create(&cloud_pth,NULL,getReportData,NULL);//上传云端
    pthread_create(&shm_pth,NULL,getShmData,NULL);//写进共享内存
    //pthread_create(&recv_pth,NULL,recvFromServ,NULL);
}

void* getCANData(void* arg)
{

    int res1,res2;
    //float rpm;

    while(1){
        res1 = VCI_GetReceiveNum(gDevType,gDevIdx,ctx_can1.channel);    //获取指定can数据通道缓存
        res2 = VCI_GetReceiveNum(gDevType,gDevIdx,ctx_can2.channel);
        //printf("the value of res1 is %d\n",res1);
        //printf("the value of res2 is %d\n",res2);
        if( res1  && (0 == pthread_rwlock_wrlock(&rwlock)) ){
           // printf("can 读获得锁\n");
            //接收can1数据并解析
            can1Data.recCnt = VCI_Receive(gDevType,gDevIdx,ctx_can1.channel,can1Data.recvBuff,RX_BUFF_SIZE,RX_WAIT_TIME);
            parse_canFrame(can1Data,&bbm_tryePressure,&bbm_dataInfo,&k60_liqudLev,&k60_disTime,&k60_waterPress,&k60_door,&k60_rifd);
            memset(can1Data.recvBuff,0,can1Data.recCnt*sizeof (VCI_CAN_OBJ));
            can1Data.recCnt = 0;
            //接收can2数据解析     只解析一次
            if(res2 != 0){

                can2Data.recCnt = VCI_Receive(gDevType,gDevIdx,ctx_can2.channel,can2Data.recvBuff,RX_BUFF_SIZE,RX_WAIT_TIME);
                for(int i = 0;i < can2Data.recCnt; i++){
                    //printf("can2通道 发动机转速\n");
                    if(can2Data.recvBuff[i].ID == 0x0CF00400){
                        if((can2Data.recvBuff[i].Data[3] != 0xff) || can2Data.recvBuff[i].Data[4] != 0xff){
                            bbm_dataInfo.rpm = ((float)(((uint16_t) (can2Data.recvBuff[i].Data[4]))<<8 |  can2Data.recvBuff[i].Data[3] )) *0.125;
                            //printf("发动机原始数据 %x %x\n",can2Data.recvBuff[i].Data[3],can2Data.recvBuff[i].Data[4]);
                           // printf("发动机转速 %f \n",bbm_dataInfo.rpm);
                            break;
                        }
                    }
                }
            }
            memset(can2Data.recvBuff,0,can2Data.recCnt*sizeof (VCI_CAN_OBJ));
            can2Data.recCnt = 0;
            pthread_rwlock_unlock(&rwlock);
            /* ========================================== */
            /**
                     * 发送can数据帧
                     * 包括rfid 管道压力 可能还有发动机控制
                     * 1 - rfid 4 - pipe
                     * */
            if((!rfidClicked)||(foamRate != foamRateTemp)){
                foamRateTemp = foamRate;
                printf("%d %d %d",rfidClicked,foamRate,foamRateTemp);
                sendCanFrame(1);
            }
            if(pipePress_temp != pipePress){  //压力值变化且不为0才会发送can数据帧
                pipePress_temp = pipePress;
                if((pipePress_temp == 10) || (pipePress_temp == 11) || (pipePress_temp == 12) || (pipePress_temp == 13) || (pipePress_temp == 14) || (pipePress_temp == 0)){
                    sendCanFrame(4);
                }
            }
            if(clean_pim != cleanPimTemp){
                cleanPimTemp = clean_pim;
                sendCanFrame(2);
            }
            //写数据到本地
            writeFile(k60_waterPress.mAirPress,k60_liqudLev.flowRate,k60_liqudLev.foamRate,k60_disTime.RpmSpeed,k60_door.valveOpen);
            dataFlag = 1;
        }
        //若未获得锁 则等待一段时间
        else {
            msleep(100);
        }
    }
    //测试用
    return  NULL;
}

void* getReportData(void* arg)
{
    unsigned char reportBuff[1024] = {0};
    int dataLen = 0;
    int myDataCommand = 0x4005;
    int paramID = 4;
    int retCode = 0;
    while (1) {
        if(dataFlag) {
            updateNum << 1 <<8 << 16 << 32;          //状态子系统 门状态 距离 液位子系统
            pthread_rwlock_rdlock(&rwlock);
            printf("===================================----云 端 获 得 锁----\n");
            buildReportStr();
            pthread_rwlock_unlock(&rwlock);
            if(!tool_missCount){
                updateNum <<4 ;              //如果tool缺失数据不为0，则添加toolInfo结构体
            }
            generateDataBuff(reportBuff,&dataLen,updateNum);
            updateNum.clear();
            buildSmartPacket(socketfd,myDataCommand,paramID,retCode,reportBuff,dataLen);
            msleep(5*1000);
        }
        else {
            msleep(2000);
            //msleep(myApp::dataTran*1000);
        }
    }
    return NULL;
}
void *getShmData(void *arg)
{
    while (1) {
        if(dataFlag){
            pthread_rwlock_rdlock(&rwlock);
            //获得共享内存所需数据
            printf("++++共 享 内 存 获 得 锁+++++\n");
            get_screen_plc_data();
            pthread_rwlock_unlock(&rwlock);
            //数据写到共享内存
            writeShm();
            msleep(2000);
        }
        //如果没有数据 则等待1.5s再读
        else {
            msleep(1500);
        }
    }
    return NULL;
}
//生成数据上报结构体
void buildReportStr()
{
    //状态子系统基础数据
    subStatusInfo.rpm = bbm_dataInfo.rpm;   // r/min
    subStatusInfo.mTyreCount = 0;           //目前没有数据
    subStatusInfo.CoolLiquidTemp = bbm_dataInfo.coolLiquidTemp;
    subStatusInfo.OilTemp = bbm_dataInfo.oilTemp;
    subStatusInfo.OilLevel = bbm_dataInfo.oilLevel; //百分号
    subStatusInfo.PowerTakeTemp = 0;
    subStatusInfo.PowerOilLevel = 0;
    subStatusInfo.PltWarnVale = 0;
    subStatusInfo.ToolsDetect = 0;
    //胎温胎压

    //工具缺失
    if(rfid_can_recv){                 //说明接收了rfid的can数据
        buildToolsLack();              //获取上传和写入共享内存的工具信息
    }
    //箱门开关
    boxDoorInfo.BoxDoorCount = 7;
    boxDoorInfo.bOPend = k60_door.doorstate;

    //周边检测距离
    rangeInfo.mFront = 0xff;
    rangeInfo.mLeft = k60_disTime.distance_left/100;   //分米
    rangeInfo.mRight = k60_disTime.distance_right/100;
    rangeInfo.mBehind = k60_disTime.distance_late/100;

    //罐内液位检测子系统
    liquidInfo.RpmSpeed = k60_disTime.RpmSpeed;    //r/min
    liquidInfo.FlowRate = k60_liqudLev.flowRate; // L/s
    liquidInfo.wPressLow = k60_waterPress.wPressLow;  //mpa
    liquidInfo.wPressMid = 0;  //中压一直没有数据
    liquidInfo.mAirPress = 0-k60_waterPress.mAirPress;
    liquidInfo.mfoamLevel = k60_liqudLev.mfoamLevel/1000;  //m
    liquidInfo.mWaterLevel = k60_liqudLev.mwaterLevel/1000;
    liquidInfo.mpimpRuntime = k60_waterPress.pimRunTime;  //h
    liquidInfo.mGetWatertime = k60_disTime.waterRunTime; //s
}

void sendCanFrame(int canid)
{
    int ID = canid;
    switch (ID) {
    case RFID_ID:
        memset(&rfidFrame,0,sizeof(VCI_CAN_OBJ));
        rfidFrame.ID = 0x18B4EEEE;
        rfidFrame.SendType = 1;
        rfidFrame.RemoteFlag = 0;
        rfidFrame.ExternFlag = 1;
        rfidFrame.DataLen = 8;
        if(!rfidClicked){
            rfidFrame.Data[0] = 0xEE;
            rfidFrame.Data[1] = 0xEE;
            rfidFrame.Data[2] = 0xEE;
            rfidFrame.Data[3] = 0xEE;
            rfidFrame.Data[4] = 0xEE;
            rfidFrame.Data[5] = 0xEE;
            rfidFrame.Data[6] = 0xEE;
            rfidFrame.Data[7] = 0x00;
            printf("进入rfid帧数据发送\n");
            VCI_Transmit(gDevType,gDevIdx,0,&rfidFrame,1);//1代表只发送一条
            rfidClicked = 1;
            break;
        }
        if(foamRate == 1){   //关闭
            rfidFrame.Data[0] = 0xBB;
            rfidFrame.Data[1] = 0xEE;
            rfidFrame.Data[2] = 0xEE;
            rfidFrame.Data[3] = 0xEE;
            rfidFrame.Data[4] = 0xEE;
            rfidFrame.Data[5] = 0xEE;
            rfidFrame.Data[6] = 0xEE;
            rfidFrame.Data[7] = 0x00;
            VCI_Transmit(gDevType,gDevIdx,0,&rfidFrame,1);
            //foamRate = 0xff;
            break;
        }
        if((foamRate != 0xff) && (foamRate != 0)){
            rfidFrame.Data[0] = 0xAA;
            rfidFrame.Data[1] = foamRate;
            rfidFrame.Data[2] = 0xEE;
            rfidFrame.Data[3] = 0xEE;
            rfidFrame.Data[4] = 0xEE;
            rfidFrame.Data[5] = 0xEE;
            rfidFrame.Data[6] = 0xEE;
            rfidFrame.Data[7] = 0x00;
            VCI_Transmit(gDevType,gDevIdx,0,&rfidFrame,1);
            //foamRate = 0xff;
            break;
        }
        break;
    case CLEAN_PIM:
        memset(&cleanPimFrame,0,sizeof (VCI_CAN_OBJ));
        cleanPimFrame.ID = 0x17B4EEEE;
        pipePreFrame.SendType = 1;
        pipePreFrame.RemoteFlag = 0;
        pipePreFrame.ExternFlag = 1;
        pipePreFrame.DataLen = 8;
        pipePreFrame.Data[0] = 0xCC;
        pipePreFrame.Data[1] = 0x03;
        pipePreFrame.Data[2] = 0xFF;
        pipePreFrame.Data[3] = 0xFF;
        pipePreFrame.Data[4] = 0xFF;
        pipePreFrame.Data[5] = 0xFF;
        pipePreFrame.Data[6] = 0xFF;
        pipePreFrame.Data[7] = 0xFF;
        VCI_Transmit(gDevType,gDevIdx,0,&cleanPimFrame,1);
        break;
    case PIPE_ID:
        memset(&pipePreFrame,0,sizeof (VCI_CAN_OBJ));
        pipePreFrame.ID = 0x17B4EEEE;
        pipePreFrame.SendType = 1;
        pipePreFrame.RemoteFlag = 0;
        pipePreFrame.ExternFlag = 1;
        pipePreFrame.DataLen = 8;
        if(pipePress_temp != 0){
            pipePreFrame.Data[0] = 0xEE;
            pipePreFrame.Data[1] = 0x03;
            pipePreFrame.Data[2] = pipePress_temp;
        }
        else {
            pipePreFrame.Data[0] = 0xDD;
            pipePreFrame.Data[1] = 0x02;
            pipePreFrame.Data[2] = 0xff;
        }
        pipePreFrame.Data[3] = 0xFF;
        pipePreFrame.Data[4] = 0xFF;
        pipePreFrame.Data[5] = 0xFF;
        pipePreFrame.Data[6] = 0xFF;
        pipePreFrame.Data[7] = 0xFF;
        VCI_Transmit(gDevType,gDevIdx,0,&pipePreFrame,1);
        break;
    }
}

//1 - 缺失 0 - 有

void buildToolsLack()
{    
    tool_missCount = 0;
    int toolCode = 0;
    char toData[2]={0};
    smart_Toolinfo* toolInfo = (smart_Toolinfo*)malloc(sizeof(smart_Toolinfo));
    bzero(toolInfo,sizeof(smart_Toolinfo));
    for(int i = 0;i < 32; i++){
        if((k60_rifd.rfid_state_1 >> i) & 1){
            toolCode = 10 + i;
            itoa(toolCode,toData);
            strcpy((char*)toolInfo,toData); //将后者指向字符串复制给前者
            memcpy(toolBuff + tool_missCount*sizeof(smart_Toolinfo),toolInfo,sizeof(smart_Toolinfo));
            tool_missCount++;
        }
    }
    for(int i = 0;i < 7;i++){
        if((k60_rifd.rfid_state_2 >> i) & 1){
            toolCode = 42 + i;
            itoa(toolCode,toData);
            strcpy((char*)toolInfo,toData);
            memcpy(toolBuff + tool_missCount*sizeof(smart_Toolinfo),toolInfo,sizeof(smart_Toolinfo));
            tool_missCount++;
        }
    }
    printf("第一个参数：%x 第二个参数：%x\n",k60_rifd.rfid_state_1,k60_rifd.rfid_state_2);
    printf("缺失的器材数：%d \n",tool_missCount);
    free(toolInfo);
}

void itoa(int i, char *string)
{
    int power,j;
        j=i;
        for(power=1;j>=10;j/=10)
            power*=10;
        for(;power>0;power/=10)
        {
            *string++='0'+i/power;
            i%=power;
        }
        *string='\0';
}
void writeFile(float airPress,float flowRate,float foamRate,float pimSpeed,float valve){
    FILE* fd = NULL;
    char buffer[41] = {0};
    char t = '\n';
    fd = fopen("./data.txt","at+");
    if(fd == NULL){
        return ;
    }
    gcvt(airPress,3,buffer); //gcvt函数将浮点型数转换成字符串（包括小数点和正负号），取四舍五入，3表示三位有效数字
    gcvt(flowRate,3,buffer+8);
    gcvt(foamRate,3,buffer+16);
    gcvt(pimSpeed,3,buffer+24);
    gcvt(valve,3,buffer+32);
    memcpy(buffer+40,&t,1);
    fwrite(buffer,1,sizeof (buffer),fd);
    fclose(fd);
}
#endif
