#include "myapp.h"

#include <stdio.h>
#include <QSettings>

int myApp::dataTran = 2;
int myApp::connect;
float myApp::tankH;
float myApp::pipePress;
int myApp::year;
int myApp::month;
int myApp::date;
int myApp::hour;
int myApp::min;
int myApp::seconds;
QString myApp::random;
QString myApp::carSn;
QString myApp::carNumber;
QString myApp::carType;
int myApp::liveUp;
int myApp::locked;
int myApp::devType;
int myApp::isRegister;
int myApp::isBind;

QString myApp::version;
QString myApp::deptNo;
int myApp::tyreCounts;
int myApp::toolsCount;
QList<int> myApp::bindToolsCode;

warnValueLimit myApp::engineSpeedStr;
warnValueLimit myApp::engineTempStr;
warnValueLimit myApp::coolLiquidStr;
warnValueLimit myApp::PTOTempStr;
warnValueLimit myApp::PTOOilLevelStr;
warnValueLimit myApp::fuelLevelStr;

warnValueLimit myApp::typeTemp;
warnValueLimit myApp::typePre;
warnValueLimit myApp::rpmSpeed;
warnValueLimit myApp::rpmTime;
warnValueLimit myApp::fireMontor;
warnValueLimit myApp::mPressLow;
warnValueLimit myApp::airPress;
warnValueLimit myApp::mPressMid;
warnValueLimit myApp::drawWaterTime;
warnValueLimit myApp::waterLev;
warnValueLimit myApp::foamLev;
warnValueLimit myApp::leftDistance;
warnValueLimit myApp::rightDistance;
warnValueLimit myApp::fontDistance;
warnValueLimit myApp::bhindDsitance;

void myApp::writeLoginToConfig(const QString& random, const QString& carSn, const QString& carNum, const QString& carType, unsigned char *sysTime,
                               const int liveUp, const int& locked, const int& devType, const int& devRegis, const int& devBind)
{
    year = (int)sysTime[0]+1900;
    month = (int)sysTime[1];
    date = (int)sysTime[2];
    hour = (int)sysTime[3];
    min = (int)sysTime[4];
    seconds = (int)sysTime[5];
    QString str = QString("sudo date -s %1:%2:%3:%4:%5:%6").arg(year).arg(month).arg(date).arg(hour).arg(min).arg(seconds);
    char* command = str.toLatin1().data();
    system(command);
    myApp::random = random;
    myApp::carSn = carSn;
    myApp::carNumber = carNum;
    myApp::carType = carType;
    myApp::liveUp = liveUp;
    myApp::locked = locked;
    myApp::devType = devType;
    myApp::isRegister = devRegis;
    myApp::isBind = devBind;
}

void myApp::writeSysParamToConfig(const QString &version, const QString &depNo, const int &tyreCount)
{
    myApp::version = version;
    myApp::deptNo = depNo;
    myApp::tyreCounts = tyreCount;
}

void myApp::writeToolsTableToConfig(const int &count)
{
    toolsCount = count;
}

void myApp::writeConfig()
{
    QSettings* configWrite = new QSettings("/home/pi/logFile/param.conf",QSettings::NativeFormat);

    //向config文件写入
    //车牌号写入
    QString carNumber = myApp::carNumber;
    configWrite->setValue("/CAR/car_number",carNumber);

    //发动机转速阀值写入
    configWrite->setValue("/ENGINE_SPEED/valueMde",myApp::engineSpeedStr.valueMde);
    configWrite->setValue("/ENGINE_SPEED/highLev",myApp::engineSpeedStr.highVal);
    configWrite->setValue("/ENGINE_SPEED/lowLev",myApp::engineSpeedStr.lowVal);

    //发动机温度阀值写入
    configWrite->setValue("/ENGINE_TEMP/valueMde",myApp::engineTempStr.valueMde);
    configWrite->setValue("/ENGINE_TEMP/highLev",myApp::engineTempStr.highVal);
    configWrite->setValue("/ENGINE_TEMP/lowLev",myApp::engineTempStr.lowVal);

    //冷却液温度阀值写入
    configWrite->setValue("/COOLLIQUID/valueMde",myApp::coolLiquidStr.valueMde);
    configWrite->setValue("/COOLLIQUID/highLev",myApp::coolLiquidStr.highVal);
    configWrite->setValue("/COOLLIQUID/lowLev",myApp::coolLiquidStr.lowVal);

    //油箱油位阀值写入
    configWrite->setValue("/FUEL_LEVEL/valueMde",myApp::fuelLevelStr.valueMde);
    configWrite->setValue("/FUEL_LEVEL/highLev",myApp::fuelLevelStr.highVal);
    configWrite->setValue("/FUEL_LEVEL/lowLev",myApp::fuelLevelStr.lowVal);

    delete configWrite;
}

void myApp::readConfig()
{
    QSettings* configIniRead = new QSettings("/home/pi/logFile/param.conf", QSettings::NativeFormat);

    //将读取到的ini文件保存在QString中，先取值，然后通过toString()函数转换成QString类型
    bool ok;
    //车牌号读取
    myApp::carNumber = configIniRead->value("/CAR/car_number").toString();

    //发动机转速阀值读取
    myApp::engineSpeedStr.valueMde = configIniRead->value("/ENGINE_SPEED/valueMde").toInt(&ok);
    myApp::engineSpeedStr.highVal = configIniRead->value("/ENGINE_SPEED/highLev").toFloat(&ok);
    myApp::engineSpeedStr.lowVal = configIniRead->value("/ENGINE_SPEED/lowLev").toFloat(&ok);

    //发动机温度阀值读取
    myApp::engineTempStr.valueMde = configIniRead->value("/ENGINE_TEMP/valueMde").toInt(&ok);
    myApp::engineTempStr.highVal = configIniRead->value("/ENGINE_TEMP/highLev").toFloat(&ok);
    myApp::engineTempStr.lowVal = configIniRead->value("/ENGINE_TEMP/lowLev").toFloat(&ok);

    //冷却液温度阀值读取
    myApp::coolLiquidStr.valueMde = configIniRead->value("/COOLLIQUID/valueMde").toInt(&ok);
    myApp::coolLiquidStr.highVal = configIniRead->value("/COOLLIQUID/highLev").toFloat(&ok);
    myApp::coolLiquidStr.lowVal = configIniRead->value("/COOLLIQUID/lowLev").toFloat(&ok);

    //油箱油位阀值读取
    myApp::fuelLevelStr.valueMde = configIniRead->value("/FUEL_LEVEL/valueMde").toInt(&ok);
    myApp::fuelLevelStr.highVal = configIniRead->value("/FUEL_LEVEL/highLev").toFloat(&ok);
    myApp::fuelLevelStr.lowVal = configIniRead->value("/FUEL_LEVEL/lowLev").toFloat(&ok);

    delete configIniRead;
}

