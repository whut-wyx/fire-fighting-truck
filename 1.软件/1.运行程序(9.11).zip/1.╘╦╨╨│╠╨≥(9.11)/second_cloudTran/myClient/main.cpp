#include <QCoreApplication>
#include <unistd.h>

#include "establishconnect.h"
#include "pthread_global.h"
#include "plc_screen/ipc.h"
#include "mydataprocess.h"
extern "C" {
#include "gps_data/getGPS_info.h"
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    executeConnectNet();                 //执行拨号线程
    int errCounts = 0;
    myApp::connect = 0;
    myApp::readConfig();               //不管怎样还是执行一次读取配置
    while (1) {
        int res = -1;
        res = check_interface_fromproc((char*)"ppp0");
        if(res == 1){
            if(myClientServer() == 1){   //完成网络连接
                initMyClientInfo(socketfd);
                myApp::connect = 1;      //连接成功
                //system("sudo ntpdate cn.pool.ntp.org");
                system("sudo ntpdate cn.pool.ntp.org");//更新时间
                break;
            }else {
                errCounts++;
            }
        }
        else {
            errCounts++;
            usleep(200*1000);
        }
        if(errCounts > 15){         //如果超过10次，拨号未成功，则读取配置文件参数
            myApp::connect = 2;
            break;
        }
    }
    initGPSInfo();                     //初始化启动4g模块
    initCanCard();                    //初始化CAN卡
    screenShm();                      //创建共享内存区
    plcShm();
    createPthread();                  //创建线程

    //回收发动机线程
    pthread_join(can_pth,NULL);
    pthread_join(cloud_pth,NULL);
    pthread_join(shm_pth,NULL);
    pthread_join(recv_pth,NULL);
    pthread_join(ppp0,NULL);
    printf("main 函数\n");
    pthread_rwlock_destroy(&rwlock);
    rm_sem_shm();
    return a.exec();
}
