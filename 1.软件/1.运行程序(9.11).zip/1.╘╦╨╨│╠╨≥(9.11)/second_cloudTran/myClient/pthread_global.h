#ifndef PTHREAD_GLOBAL_H
#define PTHREAD_GLOBAL_H

#include <pthread.h>
#include "getcandata.h"

enum sendCANFrame{
    RFID_ID = 1,
    CLEAN_PIM = 2,
    PIPE_ID = 4
};

typedef struct{
    unsigned channel;
    unsigned stop;
    unsigned error;
} RX_PARSE_CTX;

typedef struct{
    unsigned channel;         // channel index, 0~3
    unsigned stop;            // stop RX-thread
    unsigned error;           // error(s) detected
} RX_CTX;

//开始初始化can卡 5包括波特率设置 屏蔽码
int initCanCard();

//初始化启动can卡
int startCanCard();

//创建线程 初始化读写锁
void createPthread();

//全局变量声明
extern pthread_t can_pth;
extern pthread_t cloud_pth;
extern pthread_t shm_pth;
extern pthread_t recv_pth;
extern pthread_rwlock_t rwlock;

extern unsigned char toolBuff[160];
extern int tool_missCount;

extern bbm_tryeDataInfo bbm_tryePressure;
extern bbm_canData bbm_dataInfo;

extern k60_liquidLevel k60_liqudLev;
extern k60_distanceTime k60_disTime;
extern k60_pressure k60_waterPress;
extern k60_doorState k60_door;
extern k60_rfidState k60_rifd;
/** can数据读取*/
void* getCANData(void* arg);                               //线程开始函数

/** 数据上报*/
void* getReportData(void* arg);                            //线程开始函数
void buildReportStr();                                     //生成数据上报结构体
void buildToolsLack();                                     //生成缺失工具编码
void itoa(int i,char* string);
/** 取数据到共享内存*/
void* getShmData(void* arg);                               //线程开始函数
//真空  水流量 泡沫比例 水泵转速 阀门开度
void writeFile(float airPress,float flowRate,float foamRate,float pimSpeed,float valve);
/** 发送一些数据帧 包括发动机转速控制 rfid读取*/
void sendCanFrame(int canid);

//线程获取can数据
void recv_parseCan();


#endif // PTHREAD_GLOBAL_H
