#include "keyboarddialog.h"
#include "ui_keyboarddialog.h"

KeyBoardDialog::KeyBoardDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::KeyBoardDialog)
{
    ui->setupUi(this);
    lineEdit = ui->lineEdit;
}

KeyBoardDialog::~KeyBoardDialog()
{
    delete ui;
}

void KeyBoardDialog::on_Backspace_clicked()
{
    int idx = lineEdit->cursorPosition();
        if(idx == 0)
        {
            lineEdit->setCursorPosition(idx);
            lineEdit->setFocus();
            return;
        }
        strContent.remove(idx-1,1);
        lineEdit->setText(strContent);
        lineEdit->setCursorPosition(idx-1);
        lineEdit->setFocus();
}

void KeyBoardDialog::on_OK_clicked()
{
    QString tempNum = this->lineEdit->text();
    emit outputNumToTable(tempNum);
    this->lineEdit->clear();
    this->close();
}

void KeyBoardDialog::on_num1_clicked()
{
    int idx = lineEdit->cursorPosition();
    if(strContent.left(idx) == "0")
    {
        lineEdit->setCursorPosition(idx);
        lineEdit->setFocus();
        return;
    }

    strContent.insert(idx, '1');
    lineEdit->setText(strContent);
    lineEdit->setCursorPosition(idx+1);
    lineEdit->setFocus();
}

void KeyBoardDialog::on_num2_clicked()
{
    int idx = lineEdit->cursorPosition();
       if(strContent.left(idx) == "0")
       {
           lineEdit->setCursorPosition(idx);
           lineEdit->setFocus();
           return;
       }
       strContent.insert(idx, '2');
       lineEdit->setText(strContent);
       lineEdit->setCursorPosition(idx+1);
       lineEdit->setFocus();
}

void KeyBoardDialog::on_num3_clicked()
{
    int idx = lineEdit->cursorPosition();
     if(strContent.left(idx) == "0")
     {
         lineEdit->setCursorPosition(idx);
         lineEdit->setFocus();
         return;
     }
     strContent.insert(idx, '3');
     lineEdit->setText(strContent);
     lineEdit->setCursorPosition(idx+1);
     lineEdit->setFocus();
}

void KeyBoardDialog::on_num4_clicked()
{
    int idx = lineEdit->cursorPosition();
        if(strContent.left(idx) == "0")
        {
            lineEdit->setCursorPosition(idx);
            lineEdit->setFocus();
            return;
        }
        strContent.insert(idx, '4');
        lineEdit->setText(strContent);
        lineEdit->setCursorPosition(idx+1);
        lineEdit->setFocus();
}

void KeyBoardDialog::on_num5_clicked()
{
    int idx = lineEdit->cursorPosition();
        if(strContent.left(idx) == "0")
        {
            lineEdit->setCursorPosition(idx);
            lineEdit->setFocus();
            return;
        }
        strContent.insert(idx, '5');
        lineEdit->setText(strContent);
        lineEdit->setCursorPosition(idx+1);
        lineEdit->setFocus();
}

void KeyBoardDialog::on_num6_clicked()
{
    int idx = lineEdit->cursorPosition();
       if(strContent.left(idx) == "0")
       {
           lineEdit->setCursorPosition(idx);
           lineEdit->setFocus();
           return;
       }
       strContent.insert(idx, '6');
       lineEdit->setText(strContent);
       lineEdit->setCursorPosition(idx+1);
       lineEdit->setFocus();
}

void KeyBoardDialog::on_num7_clicked()
{
    int idx = lineEdit->cursorPosition();
        if(strContent.left(idx) == "0")
        {
            lineEdit->setCursorPosition(idx);
            lineEdit->setFocus();
            return;
        }
        strContent.insert(idx, '7');
        lineEdit->setText(strContent);
        lineEdit->setCursorPosition(idx+1);
        lineEdit->setFocus();
}

void KeyBoardDialog::on_num8_clicked()
{
    int idx = lineEdit->cursorPosition();
      if(strContent.left(idx) == "0")
      {
          lineEdit->setCursorPosition(idx);
          lineEdit->setFocus();
          return;
      }
      strContent.insert(idx, '8');
      lineEdit->setText(strContent);
      lineEdit->setCursorPosition(idx+1);
      lineEdit->setFocus();
}

void KeyBoardDialog::on_num9_clicked()
{
    int idx = lineEdit->cursorPosition();
      if(strContent.left(idx) == "0")
      {
          lineEdit->setCursorPosition(idx);
          lineEdit->setFocus();
          return;
      }
      strContent.insert(idx, '9');
      lineEdit->setText(strContent);
      lineEdit->setCursorPosition(idx+1);
      lineEdit->setFocus();
}

void KeyBoardDialog::on_num0_clicked()
{
    int idx = lineEdit->cursorPosition();
      if(strContent.left(idx) == "0" || (idx==0 &&strContent!=""))
      {
          lineEdit->setCursorPosition(idx);
          lineEdit->setFocus();
          return;
      }
      strContent.insert(idx, '0');
      lineEdit->setText(strContent);
      lineEdit->setCursorPosition(idx+1);
      lineEdit->setFocus();
}

void KeyBoardDialog::on_pointer_clicked()
{
    int idx = lineEdit->cursorPosition();

    if(idx==0 || strContent.contains('.'))
    {
        lineEdit->setCursorPosition(idx);
        lineEdit->setFocus();
        return;
    }

    strContent.insert(idx, '.');
    lineEdit->setText(strContent);
    lineEdit->setCursorPosition(idx+1);
    lineEdit->setFocus();
}

void KeyBoardDialog::on_pushButton_clicked()
{
    this->hide();
}
