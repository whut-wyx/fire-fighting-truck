#include "setdistancedialog.h"
#include "ui_setdistancedialog.h"
#include "mainwidget.h"
#include <QDebug>

float leftinfo,rightinfo,behindinfo;
extern void on_on_clicked();

SetDistanceDialog::SetDistanceDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SetDistanceDialog),keyboard(new KeyBoardDialog())
{
    ui->setupUi(this);
   //得到默认的测距开启条件
   getSetDistance();
   ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
   ui->tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);


}

SetDistanceDialog::~SetDistanceDialog()
{
    delete ui;
}

void SetDistanceDialog::getSetDistance()
{
    QString str= ui->tableWidget->item(0,1)->text();
    QString str1= ui->tableWidget->item(1,1)->text();
    QString str2= ui->tableWidget->item(2,1)->text();

    left = str.toFloat();
    right = str1.toFloat();
    behind = str2.toFloat();
    leftinfo = left;
    rightinfo = right;
    behindinfo = behind;


}

//ok
void SetDistanceDialog::on_OKbutton_clicked()
{

   getSetDistance();
   leftinfo = left;
   rightinfo = right;
   behindinfo = behind;


   this->close();
}
//cancel
void SetDistanceDialog::on_cancelbutton_clicked()
{
     this->close();
}
//双击table触发小键盘
void SetDistanceDialog::on_tableWidget_cellDoubleClicked(int row, int column)
{
   myRow = row;
   myColumn = column;
   KeyBoardDialog keydialog;
   connect(&keydialog,&KeyBoardDialog::outputNumToTable,[=](QString strNum){
       ui->tableWidget->setItem(myRow,myColumn,new QTableWidgetItem(strNum));
   });
   keydialog.exec();
}


