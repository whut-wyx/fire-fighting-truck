#ifndef RFIDWIDGET_H
#define RFIDWIDGET_H

#include <QWidget>

namespace Ui {
class RFIDWidget;
}

class RFIDWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RFIDWidget(QWidget *parent = nullptr);
    ~RFIDWidget();
private slots:
    void warnledflash(int warnType,int value);

    void on_getRfidData_clicked();
public slots:
    //获取rfid工具信息
    void getRfidData(unsigned char*rfidData);

private:
    Ui::RFIDWidget *ui;
    int rfid;
    int flag;
signals:
   void rfidFlag(int rfidValue,int flag);
};

#endif // RFIDWIDGET_H
