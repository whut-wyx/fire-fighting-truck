#include "rfidwidget.h"
#include "ui_rfidwidget.h"





RFIDWidget::RFIDWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RFIDWidget)
{
    ui->setupUi(this);
    ui->label_2->setPixmap(QPixmap("://image/warnstatic.jpg"));
    ui->label_3->setPixmap(QPixmap("://image/green.jpg"));

    rfid = 1;
    flag = 0;
}

RFIDWidget::~RFIDWidget()
{
    delete ui;
}

//获取rfid的数据按钮
void RFIDWidget::on_getRfidData_clicked()
{
       rfid = 0;
       flag = 1;
       emit rfidFlag(rfid,flag);
}


void RFIDWidget::warnledflash(int warnType,int value)
{
       int type = warnType;
       switch(type){
       case 0:  //吸水管
           if(value){
               ui->SucPipeLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
               ui->SucPipetext->setText("无");

           }
           else {
               ui->SucPipeLabel->setPixmap(QPixmap("://image/green.jpg"));
               ui->SucPipetext->setText("有");
           }
           break;
       case 1://滤水器
           if(value){
               ui->water_filterLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
               ui->water_filtertext->setText("无");

           }
           else {
               ui->water_filterLabel->setPixmap(QPixmap("://image/green.jpg"));
               ui->water_filtertext->setText("有");

           }
           break;

       case 2://分水器
           if(value){
               ui->waterKKOLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
               ui->waterKKOtext->setText("无");

           }
           else {
               ui->waterKKOLabel->setPixmap(QPixmap("://image/green.jpg"));
               ui->waterKKOtext->setText("有");
           }
           break;
       case 3://集水器
           if(value){
               ui->collectorLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
               ui->collectortext->setText("无");
           }
           else {
               ui->collectorLabel->setPixmap(QPixmap("://image/green.jpg"));
               ui->collectortext->setText("有");
           }
           break;
       case 4://水带13-65-20
           if(value){
               ui->Hose20_1->setText("无/");
           }
           else {
               ui->Hose20_1->setText("有/");
           }
           break;
       case 5:
           if(value){
               ui->Hose20_2->setText("无/");
           }
           else {
               ui->Hose20_2->setText("有/");
           }
           break;
       case 6:
           if(value){
               ui->Hose20_3->setText("无/");
           }
           else {
               ui->Hose20_3->setText("有/");
           }
           break;
       case 7:
           if(value){
               ui->Hose20_4->setText("无/");
           }
           else {
               ui->Hose20_4->setText("有/");
           }
           break;
       case 8:
           if(value){
               ui->Hose20_5->setText("无/");
           }
           else {
               ui->Hose20_5->setText("有/");
           }
           break;
       case 9:
           if(value){
               ui->Hose20_6->setText("无");
           }
           else {
               ui->Hose20_6->setText("有");
           }
           break;
       case 10:
           if(value){
               //水带13-80-20
               ui->Hose_80text->setText("无/");
           }
           else {
               ui->Hose_80text->setText("有/");
           }
           break;
       case 11:
           if(value){
               ui->Hose_80text_2->setText("无/");
           }
           else {
               ui->Hose_80text_2->setText("有/");
           }
           break;
       case 12:
           if(value){
               ui->Hose_80text_3->setText("无/");
           }
           else {
               ui->Hose_80text_3->setText("有/");
           }
           break;
       case 13:
           if(value){
               ui->Hose_80text_4->setText("无");
           }
           else {
               ui->Hose_80text_4->setText("有");
           }
           break;
       case 14:
           if(value){
               //水带13-65-5
               ui->Hose5text->setText("无");
               ui->Hose5Label->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->Hose5text->setText("有");
               ui->Hose5Label->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 15:
           if(value){
               //异径接口
               ui->adaptertext->setText("无");
               ui->adapterLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->adaptertext->setText("有");
               ui->adapterLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 16:
           if(value){
               //水带包布
               ui->HoseBandage_1text->setText("无/");
           }
           else {
               ui->HoseBandage_1text->setText("有/");
           }
           break;
       case 17:
           if(value){
               ui->HoseBandage_2text->setText("无/");
           }
           else {
               ui->HoseBandage_2text->setText("有/");
           }
           break;
       case 18:
           if(value){
               ui->HoseBandage_3text->setText("无/");
           }
           else {
               ui->HoseBandage_3text->setText("有/");
           }
           break;

       case 19:
           if(value){
               ui->HoseBandage_4text->setText("无");
           }
           else {
               ui->HoseBandage_4text->setText("有");
           }
           break;

       case 20:
           if(value){
               //护带桥
               ui->BeltBDG_1text->setText("无/");
           }
           else {
               ui->BeltBDG_1text->setText("有/");
           }
           break;

       case 21:
           if(value){
               ui->BeltBDG_2text->setText("无");
           }
           else {
               ui->BeltBDG_2text->setText("有");
           }
           break;

       case 22:
           if(value){
               //水带挂钩
               ui->HoseStrap_1text->setText("无/");
           }
           else {
               ui->HoseStrap_1text->setText("有/");
           }
           break;

       case 23:
           if(value){
               ui->HoseStrap_2text->setText("无/");
           }
           else {
               ui->HoseStrap_2text->setText("有/");
           }
           break;

       case 24:
           if(value){
               ui->HoseStrap_3text->setText("无/");
           }
           else {
               ui->HoseStrap_3text->setText("有/");
           }
           break;
       case 25:
           if(value){
               ui->HoseStrap_4text->setText("无");
           }
           else {
               ui->HoseStrap_4text->setText("有");
           }
           break;
       case 26:
           if(value){
               //地上消火栓扳手
               ui->FireHWtext->setText("无");
               ui->FireHWLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->FireHWtext->setText("有");
               ui->FireHWLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 27:
           if(value){
               //地下消防栓扳手
               ui->UFHWtext->setText("无");
               ui->UFHWLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->UFHWtext->setText("有");
               ui->UFHWLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 28:
           if(value){
               //吸水管扳手
               ui->sucWrenchtext_1->setText("无/");
           }
           else {
               ui->sucWrenchtext_1->setText("有/");
           }
           break;
       case 29:
           if(value){
               ui->sucWrenchtext_2->setText("无");
           }
           else {
               ui->sucWrenchtext_2->setText("有");
           }
           break;
       case 30:
           if(value){
               //直流水枪
               ui->waterstreamBtext->setText("无");
               ui->waterstreamBLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->waterstreamBtext->setText("有");
               ui->waterstreamBLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 31:
           if(value){
               //直流开花水枪
               ui->DCFWguntext->setText("无");
               ui->DCFWgunLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->DCFWguntext->setText("有");
               ui->DCFWgunLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 32:
           if(value){
               //灭火器
               ui->FireEXittext->setText("无");
               ui->FireEXitLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->FireEXittext->setText("有");
               ui->FireEXitLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 33:
           if(value){
               //铁锹
               ui->Spadetext->setText("无");
               ui->SpadeLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->Spadetext->setText("有");
               ui->SpadeLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 34:
           if(value){
               //铁铤
               ui->crowbartext->setText("无");
               ui->crowbarLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->crowbartext->setText("有");
               ui->crowbarLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 35:
           if(value){
               //消防腰斧
               ui->FFWaxetext->setText("无");
               ui->FFWaxeLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->FFWaxetext->setText("有");
               ui->FFWaxeLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 36:
           if(value){
               //消防平斧
               ui->FireAxetext->setText("无");
               ui->FireAxeLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->FireAxetext->setText("有");
               ui->FireAxeLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 37:
           if(value){
               //丁字镐
               ui->NIHEItext->setText("无");
               ui->NIHEILabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->NIHEItext->setText("有");
               ui->NIHEILabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 38:
           if(value){
               //橡皮锤
               ui->Rubmallettext->setText("无");
               ui->RubmalletLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->Rubmallettext->setText("有");
               ui->RubmalletLabel->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case 39:
           if(value){
               //器材2 默认为缺失
               ui->equipment2text->setText("无");
               ui->equipment2Label->setPixmap(QPixmap("://image/warnstatic.jpg"));
           }
           else {
               ui->equipment2text->setText("有");
               ui->equipment2Label->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       default:break;
       }

}
void RFIDWidget::getRfidData(unsigned char *rfidData)
{
    unsigned char dataBuff[40];
    memset(dataBuff,1,40);
    memcpy(dataBuff,rfidData,39);            //指定的39个工具信息
    dataBuff[39] = 1;                        //器材2默认为缺失
//   for (int i = 0;i<40;i++) {
//      printf("the rfid 第%d个 is %d\n",i,dataBuff[i]);
//  }
    int temp = 1;
    for (int i = 0;i<(int)sizeof (dataBuff);i++) {
        temp = (int)dataBuff[i];
        warnledflash(i,temp);
    }
   //  printf("the size of databuff %d\n",sizeof (dataBuff));
    //水带13-65-20
       if(dataBuff[4] | dataBuff[5] | dataBuff[6] | dataBuff[7] | dataBuff[8] | dataBuff[9]){
           ui->Hose20Label->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else {
           ui->Hose20Label->setPixmap(QPixmap("://image/green.jpg"));
       }
       //水带13-80-20
       if(dataBuff[10] | dataBuff[11] | dataBuff[12] | dataBuff[13]){
           ui->Hose_80Label->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else {
           ui->Hose_80Label->setPixmap(QPixmap("://image/green.jpg"));
       }
       //水带包布
       if(dataBuff[16] | dataBuff[17] | dataBuff[18] | dataBuff[19]){
           ui->HoseBandageLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else {
           ui->HoseBandageLabel->setPixmap(QPixmap("://image/green.jpg"));
       }
       //护带桥
       if(dataBuff[20] | dataBuff[21]){
           ui->BeltBDGLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else{
           ui->BeltBDGLabel->setPixmap(QPixmap("://image/green.jpg"));
       }
       //水带挂钩
       if(dataBuff[22] | dataBuff[23] | dataBuff[24] | dataBuff[25]){
           ui->HoseStrapLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else{
           ui->HoseStrapLabel->setPixmap(QPixmap("://image/green.jpg"));
       }
       //吸水管扳手
       if(dataBuff[28] | dataBuff[29]){
           ui->sucWrenchLabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
       }
       else {
           ui->sucWrenchLabel->setPixmap(QPixmap("://image/green.jpg"));
       }

}


