#include "bbmwidget.h"
#include "ui_bbmwidget.h"
#include <QMovie>

BBMWidget::BBMWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BBMWidget)
{
    ui->setupUi(this);
    ui->label_2->setPixmap(QPixmap("://image/warnstatic.jpg"));
    ui->label_3->setPixmap(QPixmap("://image/green.jpg"));

}

BBMWidget::~BBMWidget()
{
    delete ui;
}


//BBM警报闪烁
void BBMWidget::warnflash(int warnType,int value)
{
    int warn = warnType;
    switch(warn){
     case 0:      //发动机转速
        if(value){
            ui->motorSpeedlabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
         }
        else{

            ui->motorSpeedlabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
     case 1:  //冷却液温度
        if(value){

            ui->coolantTemlabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
        }
        else{

            ui->coolantTemlabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
     case 2: //发动机温度
        if(value){
            ui->motorTemlabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
        }
        else {
            ui->motorTemlabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
     case 3: //取力器温度
        if(value){

            ui->PTOtemlabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
        }
        else {

            ui->PTOtemlabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
    case 4://取力器内机油位
        if(value){

            ui->PTOleverlabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
        }
        else {

            ui->PTOleverlabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
    case 5://油箱油位
        if(value){

            ui->oilLevellabel->setPixmap(QPixmap("://image/warnstatic.jpg"));
        }
        else {

            ui->oilLevellabel->setPixmap(QPixmap("://image/green.jpg"));
        }
        break;
    default:break;
    }

}
void BBMWidget::BBMdata(unsigned char* warn,unsigned char* engine,unsigned char* cool,unsigned char* oilLev)
{
  int temp = 1;
  for(int i = 0;i<(int)sizeof (warn);i++){
      temp = (int)*(warn+i);
      warnflash(i,temp);
  }

  ui->motorEngine->setText(QString("%1").arg(engine[0]*100 + engine[1]));
  ui->coolLiquid->setText(QString("%1.%2").arg(cool[0]).arg(cool[1]));
  ui->oilLevel->setText(QString("%1.%2").arg(oilLev[0]).arg(oilLev[1]));
  if((QString("%1").arg(engine[0]*100 + engine[1])).toFloat() == 0){
      ui->motorEngine->setText("");
  }
  if((QString("%1.%2").arg(cool[0]).arg(cool[1])).toFloat() == 0){
      ui->coolLiquid->setText("");
  }
  if((QString("%1.%2").arg(oilLev[0]).arg(oilLev[1])).toFloat() == 0){
      ui->oilLevel->setText("");
  }
}



