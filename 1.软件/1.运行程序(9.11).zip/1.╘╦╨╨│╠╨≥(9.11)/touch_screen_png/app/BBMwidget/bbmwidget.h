#ifndef BBMWIDGET_H
#define BBMWIDGET_H

#include <QWidget>

namespace Ui {
class BBMWidget;
}

class BBMWidget : public QWidget
{
    Q_OBJECT

public:
    explicit BBMWidget(QWidget *parent = nullptr);
    ~BBMWidget();

private slots:
  void warnflash(int warnType,int value);
public slots:
    void BBMdata(unsigned char* warn,unsigned char* engine,unsigned char* cool,unsigned char* oilLev);


private:
    Ui::BBMWidget *ui;
};

#endif // BBMWIDGET_H
