#ifndef SIGNALS_H
#define SIGNALS_H

#include <QPixmap>
#include <QColor>


class Signals : public QPixmap
{
public:
    explicit Signals();
    QPixmap GetPixmap(const int ping);
private:
    QColor GetColor();
    int GetLineNum(const int ping);
    QPixmap GetSignalPixmap(const QColor &color,const int lineNum);

};

#endif // SIGNALS_H
