﻿#include "keyboard.h"
#include "ui_keyboard.h"
#include "my_lineedit.h"

#include <QFile>
#include <QDebug>
#include <QPen>
#include <QPainter>
#include <QMouseEvent>
#include <QLineEdit>
#include <QTextEdit>

/********** key_board explain ********
 * 主要有两种模式  HANZI和LETTER  中文、英文模式
 * 在HANZI模式下，CAP按钮不能生效，也可按ENTER键直接输入小写字母
 * 在LETTER模式下，CAP按钮才生效，此时可输入大、小写英文和数字
 * ******/
extern My_lineEdit* gpskEdit;
Keyboard::Keyboard(QWidget *parent,bool num) :
    QMainWindow(parent),
    ui(new Ui::Keyboard)
{
    int indx;
    QFont font( "Microsoft YaHei",14,QFont::Bold);
    font.setFamily("Microsoft YaHei");
    font.setBold(true);
    ui->setupUi(this);

    //用来切换窗口 汉字 字母 数字
    Flag_InputMode = LETTER;   //输入格式变量
    Flag_Mid_Mode = LETTER;    //输入格式中转变量

    m_MouseDown = false;       //鼠标事件初始化

    m_Page   = 0;
    m_Page_A = 0;              //初始化总页数和当前页码

    //7个字节数组 用处？
    k_letter[0]=0;
    k_letter[1]=0;
    k_letter[2]=0;
    k_letter[3]=0;
    k_letter[4]=0;
    k_letter[5]=0;
    k_letter[6]=0;
    k_letter_index=0;

    //汉字1-10
    m_Display[0] = ui->hz_1;
    m_Display[1] = ui->hz_2;
    m_Display[2] = ui->hz_3;
    m_Display[3] = ui->hz_4;
    m_Display[4] = ui->hz_5;
    m_Display[5] = ui->hz_6;
    m_Display[6] = ui->hz_7;
    m_Display[7] = ui->hz_8;
    m_Display[8] = ui->hz_9;
    m_Display[9] = ui->hz_10;//汉字1-10的定义，将其统一放在一个数组中，方便后续代码

    for(indx=0;indx<10;indx++)
    {
        m_Display[indx]->setFont(font);
        //m_Display[indx]->setStyleSheet(";color:white;font-size:18px;font-weight:bold;border:1px solid gray;");
    }
    //26个字母
    m_letter_a_z[0]=ui->pushButton_a;
    m_letter_a_z[1]=ui->pushButton_b;
    m_letter_a_z[2]=ui->pushButton_c;
    m_letter_a_z[3]=ui->pushButton_d;
    m_letter_a_z[4]=ui->pushButton_e;
    m_letter_a_z[5]=ui->pushButton_f;
    m_letter_a_z[6]=ui->pushButton_g;
    m_letter_a_z[7]=ui->pushButton_h;
    m_letter_a_z[8]=ui->pushButton_i;
    m_letter_a_z[9]=ui->pushButton_j;
    m_letter_a_z[10]=ui->pushButton_k;
    m_letter_a_z[11]=ui->pushButton_l;
    m_letter_a_z[12]=ui->pushButton_m;
    m_letter_a_z[13]=ui->pushButton_n;
    m_letter_a_z[14]=ui->pushButton_o;
    m_letter_a_z[15]=ui->pushButton_p;
    m_letter_a_z[16]=ui->pushButton_q;
    m_letter_a_z[17]=ui->pushButton_r;
    m_letter_a_z[18]=ui->pushButton_s;
    m_letter_a_z[19]=ui->pushButton_t;
    m_letter_a_z[20]=ui->pushButton_u;
    m_letter_a_z[21]=ui->pushButton_v;
    m_letter_a_z[22]=ui->pushButton_w;
    m_letter_a_z[23]=ui->pushButton_x;
    m_letter_a_z[24]=ui->pushButton_y;
    m_letter_a_z[25]=ui->pushButton_z;

    for(indx=0;indx<26;indx++)
   {
       m_letter_a_z[indx]->setFont(font);
       //m_letter_a_z[indx]->setStyleSheet("color:white;font-size:22px;font-weight:bold;border:0px solid gray;");
   }

    //设置宽度和位置
    this->setGeometry(550,500,980,530);
    this->setStyleSheet("background-color:rgb(0,0,0);color:white;font-size:28px;font-weight:bold;");

    setWindowFlags(Qt::Tool|Qt::WindowStaysOnTopHint|Qt::FramelessWindowHint|Qt::WindowDoesNotAcceptFocus);/*窗口风格设置，这里是去除标题栏即蓝色部分 Tool属性不允许新窗口抢占焦点*/

    //0-数字  1-汉字
    if(num){
        //若进入  则会显示数字键盘
        Flag_InputMode = NUMBER;   //输入格式变量
        Flag_Mid_Mode  = NUMBER;   //输入格式中转变量
        KeyBoardStartMode(NUMBER);
        ui->pushButton_en_ch->setEnabled(false);
        ui->pushButton_cap->setEnabled(false);
    }
    else{
        //显示拼音键盘
        Flag_InputMode = HANZI;   //输入格式变量
        Flag_Mid_Mode  = HANZI;   //输入格式中转变量
        KeyBoardStartMode(HANZI);  //HANZI
        ui->pushButton_en_ch->setEnabled(true);
    }
    QString srf;
    QFile file(FILE_ZI_KU);
    if(file.open(QFile::ReadOnly)){
        qDebug()<<"success";
        while(true){
            char buf[1024] = {0};
            qint64 Len = file.readLine(buf,sizeof(buf));  //读取文件一行
            if(Len<=0) break;
            srf += QString(buf);
        }
    }
    else{
        qDebug()<<"failed";
    }
    m_srf = srf.split("\r\n");   //用QString的split函数将字库文件划分成一段一段，每个拼音对应一段字库
    InitKeyBoard();     //空实现
}

Keyboard::~Keyboard()
{
    delete ui;
}

void Keyboard::InitKeyBoard(){

}
//获得窗体大小 并
void Keyboard::paintEvent(QPaintEvent*){
    QPainter dc(this);
    QRect r = QRect(0,0,this->width(),this->height());
}
/** 通过拼音找汉字
 * QString pinyin  输入的拼音
 * QString &Chinese  拼音对应的汉字
**/

bool Keyboard::FindChinese(QString PinYin, QString &Chinese){

    QStringList lst;
    QString Line;
    for(int i=0; i<m_srf.count(); i++)//m_srf.count()QStringList有多少段
    {
        Line = m_srf.at(i);
        if (Line.isEmpty() || PinYin.isEmpty()) continue;

        lst = Line.split(",");
        if (QString::compare(lst.at(0), PinYin, Qt::CaseInsensitive) == 0)
        {
            Chinese = lst.at(1);
            return true;
        }
    }
    return false;
}
//将所取得的字符对应的汉字按字放在汉字显示框中。HzList指返回来的所有汉字
void Keyboard::hanzi_zk_set(){
    QString HzList;
    QString Temp;

    for (int i=0; i<10; i++)
    {
        //m_Display指的是汉字显示框  清空操作
        m_Display[i]->setEnabled(false);
        m_Display[i]->setText("");
    }
    //若没有对应汉字
    if (!FindChinese(m_CurPY, HzList))
    {
        m_Page_A=0;
        ui->pushButton_next->setEnabled(false);
        ui->pushButton_pre->setEnabled(false);
        return;
    }

    m_Page_A=(HzList.length()-1)/10;   //获得总页数
    //此处两个if-else的作用是当翻页button没有功能是，hide它
    if (m_Page_A == m_Page)
    {
        ui->pushButton_next->setEnabled(false);
    }
    else
    {
        ui->pushButton_next->setEnabled(true);
    }
    if ( m_Page_A== 0||m_Page==0)
    {
        ui->pushButton_pre->setEnabled(false);
    }
    else
    {
        ui->pushButton_pre->setEnabled(true);
    }

    for (int i=m_Page*10; i<HzList.length(); i++)
    {
        Temp = HzList.at(i);

      //  Temp = QStringLiteral(Temp);

        m_Display[i%10]->setText(Temp);
        m_Display[i%10]->setEnabled(true);
        if ((i+1) % 10 == 0 && i != 0) break;
    }
}

/*********鼠标拖动键盘处理部分************/
//键盘拖动
void Keyboard::mouseMoveEvent(QMouseEvent *event){
    return;
    if (event->buttons() == Qt::LeftButton && m_MouseDown)
    {
        move(event->globalPos() - m_DragPos);
        event->accept();
    }
}
//读取键盘左击位置
void Keyboard::mousePressEvent(QMouseEvent *event){
    if (event->button() == Qt::LeftButton)
    {
        m_DragPos = event->globalPos() - frameGeometry().topLeft();
        event->accept();
        qDebug()<<"press";
        m_MouseDown = true;
    }
}
//鼠标释放
void Keyboard::mouseReleaseEvent(QMouseEvent *event){
    Q_UNUSED(event);
    m_MouseDown = false;
}
//通过键盘输入字符QLineEdit
void Keyboard::Input_letter_to_linEdit(const QString letter){
    //if(Flag_InputMode==LETTER)
     QWidget *q = QApplication::focusWidget();
     QLineEdit *e;
     QTextEdit *t;
     /** 加了这些不太对   须设置键盘不抢占焦点*/
     if (q != NULL)
     {
         e = dynamic_cast<QLineEdit *>(q);//dynamic_cast用于判断q的类型是否为QLineEdit如果是，那么e就为QLineEdit。
         if (e != NULL){

             e->insert(letter);
         qDebug()<<"Focus";
         }

         t = dynamic_cast<QTextEdit *>(q);
         if (t != NULL) t->insertPlainText(letter);
     }
    else
    {
         qDebug()<<"No Focus";
             if(gpskEdit)
             {
                 gpskEdit->insert(letter);
             }
     emit send_letter(letter);
     }
}

/******存储输入的字符到拼音框中*****/

void Keyboard::get_key_letter(QString letter){
    m_Page = 0;
    if(k_letter_index++<6){
        /** m_CurPy 在使用汉字输入时，用于存放区当前输入框中的值 QString
        *m_CurPy为全局变量  输入字符
        * */
        m_CurPY = m_CurPY + letter;
    }
    ui->pinyin->setText(m_CurPY);
    hanzi_zk_set();
}

//关闭按钮
void Keyboard::on_pushButton_esc_clicked()
{
    close();
}

//中英文切换button
void Keyboard::on_pushButton_en_ch_clicked()
{
    //汉字->letter->汉字
    if(Flag_InputMode==HANZI)
    {
        KeyBoardLetterMode();
    }
    else if(Flag_InputMode==LETTER)
    {
        KeyBoardHanziMode();
    }
    else if(Flag_InputMode==CAP_LETTER){
        for(int i=0; i<26; i++)
        {
            QString Letter_Set="a";
            Letter_Set.fill('a'+i,1);
            m_letter_a_z[i]->setEnabled(true);
            m_letter_a_z[i]->setText(Letter_Set);
        }
        ui->pushButton_cap->setStyleSheet("background-color:black; \
                                            color:white;font-size:28px;font-weight:bold");
        KeyBoardHanziMode();
    }

}
//大小写字母切换
void Keyboard::on_pushButton_cap_clicked()
{
    //初始化汉字部分的button
    //clean_piy_and_hanzi_while_clicked();
    char flag=Flag_InputMode;
    //大小写切换
    if(flag==CAP_LETTER)
    {
        Flag_InputMode=Flag_Mid_Mode;
        ui->pushButton_cap->setStyleSheet("background-color:black; \
                                            color:white;font-size:28px;font-weight:bold");
        for(int i=0; i<26; i++)
        {
            QString Letter_Set="a";
            Letter_Set.fill('a'+i,1);
            m_letter_a_z[i]->setEnabled(true);
            m_letter_a_z[i]->setText(Letter_Set);
        }
    }
    else
    {
        Flag_Mid_Mode=Flag_InputMode;
        Flag_InputMode=CAP_LETTER;
        //background-color:rgb(0,0,0);color:white;font-size:28px;font-weight:bold;
        ui->pushButton_cap->setStyleSheet("background-color:white; \
                                            color:black;font-size:28px;font-weight:bold");
        for(int i=0; i<26; i++)
        {
            QString Letter_Set="A";          //直接‘a’+i是不能实现的，需用fill来填充才能实现。
            Letter_Set.fill('A'+i,1);
            m_letter_a_z[i]->setEnabled(true);
            m_letter_a_z[i]->setText(Letter_Set);
        }
    }
}

//当选择需要的汉字后清除拼音和汉字栏，执行此函数删除
void Keyboard::clean_piy_and_hanzi_while_clicked(){

    //此时清楚了m_CurPy 执行hanzi_zk_set()即为NULL
    m_Page=0;//清当前页。
    k_letter_index=0;
    m_CurPY="";
    ui-> pinyin ->setText(m_CurPY);//要用ui指向前面所定义的指针
    hanzi_zk_set();
}

void Keyboard::on_pushButton_q_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        //输出汉字
        get_key_letter("q");
    }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("q");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("Q");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("~");
    }
}

void Keyboard::on_pushButton_w_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        get_key_letter("w");
    }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("w");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("W");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("`");
    }
}

void Keyboard::on_pushButton_e_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        get_key_letter("e");
    }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("e");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("E");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("@");
    }
}

void Keyboard::on_pushButton_r_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        get_key_letter("r");
    }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("r");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("R");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("#");
    }
}

void Keyboard::on_pushButton_t_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("t");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("t");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("T");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("$");
    }
}

void Keyboard::on_pushButton_y_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("y");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("y");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("Y");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("%");
    }
}

void Keyboard::on_pushButton_u_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("u");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("u");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("U");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("^");
    }
}

void Keyboard::on_pushButton_i_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("i");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("i");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("I");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("&");
    }
}

void Keyboard::on_pushButton_o_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("o");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("o");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("O");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("(");
    }
}

void Keyboard::on_pushButton_a_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        get_key_letter("a");
    }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("a");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("A");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("_");
    }
}
void Keyboard::on_pushButton_s_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("s");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("s");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("S");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("\"");
    }
}

void Keyboard::on_pushButton_d_clicked()
{
    if(Flag_InputMode == HANZI)
     {
        get_key_letter("d");
     }
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("d");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("D");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("'");
    }
}

void Keyboard::on_pushButton_f_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("f");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("f");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("F");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("|");
    }
}

void Keyboard::on_pushButton_g_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("g");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("g");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("G");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("\\");
    }
}

void Keyboard::on_pushButton_h_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("h");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("h");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("H");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit("<");
    }
}

void Keyboard::on_pushButton_j_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("j");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("j");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("J");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit(">");
    }
}

void Keyboard::on_pushButton_k_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("k");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("k");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("K");
    }
}

void Keyboard::on_pushButton_l_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("l");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("l");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("L");
    }
}

void Keyboard::on_pushButton_p_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("p");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("p");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("P");
    }
    else if(Flag_InputMode ==NUMBER)
    {
        Input_letter_to_linEdit(")");
    }
}

void Keyboard::on_pushButton_z_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("z");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("z");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("Z");
    }
}

void Keyboard::on_pushButton_x_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("x");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("x");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("X");
    }
}

void Keyboard::on_pushButton_c_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("c");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("c");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("C");
    }
}

void Keyboard::on_pushButton_v_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("v");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("v");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("V");
    }
}

void Keyboard::on_pushButton_b_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("b");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("b");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("B");
    }
}

void Keyboard::on_pushButton_n_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("n");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("n");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("N");
    }
}

void Keyboard::on_pushButton_m_clicked()
{
    if(Flag_InputMode == HANZI)
        get_key_letter("m");
    else if(Flag_InputMode == LETTER)
    {
        Input_letter_to_linEdit("m");
    }
    else if(Flag_InputMode ==CAP_LETTER)
    {
        Input_letter_to_linEdit("M");
    }
}
//找到汉字  清空操作
void Keyboard::on_hz_1_clicked()
{
    m_Page = 0;
    QString hz_n=ui->hz_1->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }

}

void Keyboard::on_hz_2_clicked()
{
    m_Page=0;
    QString hz_n=ui->hz_2->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_3_clicked()
{
    m_Page=0;
    QString hz_n=ui->hz_3->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_4_clicked()
{
    m_Page=0;
    QString hz_n=ui->hz_4->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_5_clicked()
{
    m_Page=0;
    QString hz_n=ui->hz_5->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_6_clicked()
{
    m_Page=0;
    QString hz_n=ui->hz_6->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_7_clicked()
{
    QString hz_n=ui->hz_7->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_8_clicked()
{
    QString hz_n=ui->hz_8->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_9_clicked()
{
    QString hz_n=ui->hz_9->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}

void Keyboard::on_hz_10_clicked()
{
    QString hz_n=ui->hz_10->text();
    Input_letter_to_linEdit(hz_n);
    if(Flag_InputMode == HANZI)
    {
        clean_piy_and_hanzi_while_clicked();
    }
}
//下一页
void Keyboard::on_pushButton_next_clicked()
{
    if(Flag_InputMode == HANZI)
    {
        if(m_Page<m_Page_A)
        {
            m_Page++;
            hanzi_zk_set();
        }
    }
}
//上一页
void Keyboard::on_pushButton_pre_clicked()
{
    if(m_Page==0) return;
    m_Page--;
    hanzi_zk_set();
}

//删除button
void Keyboard::on_pushButton_del_clicked()
{
    qDebug()<<m_CurPY;
    if(m_CurPY == "") //如果当前拼音为空
    {
        //使用汉字输入时，m_CurPy才累积  当为英文输入时都进入该函数 即m_CUrPy为空
        QWidget *q = QApplication::focusWidget();
        QLineEdit *e;
//      QTextEdit *t;
        if (q != NULL)
        {
            e = dynamic_cast<QLineEdit *>(q);//dynamic_cast用于判断q的类型是否为QLineEdit如果是，那么e就为QLineEdit。
            if (e != NULL) e->backspace ();  //删除
    //        t = dynamic_cast<QTextEdit *>(q);
    //       if (t != NULL) t->insertPlainText(letter);
        }
        else
        {
//            if(gpskEdit)
//        {
//        gpskEdit->backspace();
//        }
        }
    }
    else
    {
        qDebug()<<"here";
        if(k_letter_index--!=0)
        {
            m_CurPY.remove(m_CurPY.size()-1,1);  //remove ( int position, int n )position:要删除字符的起始位置，n：要删除几个
        }
        ui-> pinyin ->setText(m_CurPY);//要用ui指向前面所定义的指针
        hanzi_zk_set();
    }
}

//未实现
void Keyboard::on_pinyin_clicked()
{

}
void Keyboard::on_pushButton_Enter_clicked()
{
    if(m_CurPY=="")//如果当前拼音为空
    {
        //如果英文输入模式，指输入完毕
        send_inputvale("over");
        //Input_letter_to_linEdit("\r\n");
    }
    else
    {
        //如果为汉字输入模式，则将m_CurPy转为字母输入并清除汉字输入
        Input_letter_to_linEdit(m_CurPY);
        clean_piy_and_hanzi_while_clicked();
    }
}
//空格
void Keyboard::on_pushButton_space_clicked()
{
    if(m_CurPY == "")//如果当前拼音为空格
    {
        Input_letter_to_linEdit(" ");
    }
    //如果是汉字输入模式，默认第一个汉字为确认
    else {
       on_hz_1_clicked();
    }
}
//感叹号或者+号 如果为数字时为+号
void Keyboard::on_pushButton_sign_tan_clicked()
{
    Input_letter_to_linEdit(ui->pushButton_sign_tan->text());
}
//问号或者减号，如果为数字时为-号
void Keyboard::on_pushButton_sign_wen_clicked()
{
    Input_letter_to_linEdit(ui->pushButton_sign_wen->text());
}
//分号或者等号，如果为数字时为=
void Keyboard::on_pushButton_sign_fen_clicked()
{
    Input_letter_to_linEdit(ui->pushButton_sign_fen->text());
}
//逗号或者* 如果为数字时为*
void Keyboard::on_pushButton_sign_dou_clicked()
{
    Input_letter_to_linEdit(ui->pushButton_sign_dou->text());
}
//句号或者/，如果为数字时为/
void Keyboard::on_pushButton_sign_ju_clicked()
{
    Input_letter_to_linEdit(ui->pushButton_sign_ju->text());
}

//进入键盘初始输入法
void Keyboard::KeyBoardStartMode(int mode){
    if(mode == CAP_LETTER)
    {
        on_pushButton_cap_clicked();   //输入大小写字母
    }
    else if(mode == HANZI)
    {
        KeyBoardHanziMode(); //汉字
    }
    else if(mode == NUMBER)
    {
        KeyBoardNumMode();   //数字
    }
    else
    {
        KeyBoardLetterMode(); //输入小写字母
    }
}
//键盘输入汉字模式
void Keyboard::KeyBoardHanziMode(){
    ui-> pushButton_en_ch->setText(QString::fromLocal8Bit("中文"));
    Flag_InputMode=HANZI;

    m_CurPY="";
    ui-> pinyin ->setText(m_CurPY);//要用ui指向前面所定义的指针
    hanzi_zk_set();

    //修改一些button 可能后续需要去掉

    for(int i=0;i<26;i++)
    {
        QString Letter_Set="a";
        Letter_Set.fill('a'+i,1);
        m_letter_a_z[i]->setText(Letter_Set);
        m_letter_a_z[i]->setEnabled(true);
        //在汉字模式下不能设置打开大写
        ui->pushButton_cap->setEnabled(false);
    }


}
//键盘输入数字模式
void Keyboard::KeyBoardNumMode(){
    int index;
    ui-> pushButton_en_ch->setText(QString::fromLocal8Bit("数字"));
    Flag_InputMode=NUMBER;

    for(index=0;index<10;index++){
        m_Display[index]->setText(QString("%1").arg(index));
    }
}
//键盘输入小写字母模式
void Keyboard::KeyBoardLetterMode(){
    Flag_InputMode=LETTER;
    k_letter_index=0;
    m_CurPY="";
    ui-> pinyin ->setText(m_CurPY);//要用ui指向前面所定义的指针，清空on_hz_i_clicked
    hanzi_zk_set();
    ui-> pushButton_en_ch->setText(QString::fromLocal8Bit("英文"));

    for(int i=0;i<26;i++)
    {
       // m_letter_a_z[i]->setEnabled(true);
        QString Letter_Set="a";
        Letter_Set.fill('a'+i,1);
        m_letter_a_z[i]->setText(Letter_Set);
        m_letter_a_z[i]->setEnabled(true);
        ui->pushButton_cap->setEnabled(true);
    }
    int index;
    for(index=0;index<10;index++){
        m_Display[index]->setText(QString("%1").arg(index));
        m_Display[index]->setEnabled(true);
    }
}
