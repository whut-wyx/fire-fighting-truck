#ifndef GPSWIDGET_H
#define GPSWIDGET_H

#include <QWidget>
#include <QWebEngineView>
#include <QGestureEvent>

//class QGestureEvent;
namespace Ui {
class GpsWidget;
}
class Keyboard;

class GpsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit GpsWidget(QWidget *parent = nullptr);
    ~GpsWidget();
     QWebEngineView *view;

private slots:
     void on_pathPlanning_clicked();
     void on_currentLocation_clicked();

     void handleLineeditClicked();

private:
    Ui::GpsWidget *ui;
    Keyboard* k_board;
    QString goalLocation;

};

#endif // GPSWIDGET_H
