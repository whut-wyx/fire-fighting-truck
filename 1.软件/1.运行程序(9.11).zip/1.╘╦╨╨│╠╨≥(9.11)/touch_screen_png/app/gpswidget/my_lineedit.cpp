﻿#include "my_lineedit.h"

#include <QMouseEvent>

My_lineEdit::My_lineEdit(QWidget* parent):QLineEdit(parent)
{

}

My_lineEdit::~My_lineEdit()
{

}

void My_lineEdit::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
        {
            //触发clicked信号
            emit clicked();
        }
        //将该事件传给父类处理
        QLineEdit::mousePressEvent(event);
}
