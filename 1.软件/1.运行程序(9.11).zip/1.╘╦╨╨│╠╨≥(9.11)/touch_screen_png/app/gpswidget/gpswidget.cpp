#include "gpswidget.h"
#include "ui_gpswidget.h"
#include "my_lineedit.h"
#include "keyboard.h"

My_lineEdit* gpskEdit;

GpsWidget::GpsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GpsWidget),
    k_board(new Keyboard)
{
    ui->setupUi(this);
    //this->setCursor(Qt::BlankCursor);
    view = new QWebEngineView(this);
    view->setGeometry(0,60,1908,850);
    view->load(QUrl("http://119.96.188.175:9000/general/system/real_time/carsiteall_new.php?DEPT_ID=33&V_GPSID=ZD000028&V_NUM=%CB%D5B00001"));
    view->show();
    gpskEdit = new My_lineEdit(this);
    gpskEdit->setGeometry(1463,10,200,50);
    connect(gpskEdit,SIGNAL(clicked()),this,SLOT(handleLineeditClicked()));

}

GpsWidget::~GpsWidget()
{
    delete ui;
}

void GpsWidget::on_pathPlanning_clicked()
{
    goalLocation = gpskEdit->text();
    QString UR = "http://119.96.188.175:9000/general/system/real_time/lujingguihua.php?DEPT_ID=33&V_GPSID=ZD000028&end_location=";
    QString strUR = QString("%1%2").arg(UR).arg(goalLocation);
    view->load(QUrl(strUR));

}

void GpsWidget::on_currentLocation_clicked()
{
    view->load(QUrl("http://119.96.188.175:9000/general/system/real_time/carsiteall_new.php?DEPT_ID=33&V_GPSID=ZD000028&V_NUM=%CB%D5B00001"));

}

void GpsWidget::handleLineeditClicked(){
    k_board->show();
}
