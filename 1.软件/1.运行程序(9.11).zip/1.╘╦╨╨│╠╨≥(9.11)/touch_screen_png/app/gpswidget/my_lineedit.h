﻿#ifndef MY_LINEEDIT_H
#define MY_LINEEDIT_H

#include <QObject>
#include <QLineEdit>

class My_lineEdit : public QLineEdit
{
    Q_OBJECT

public:
    explicit My_lineEdit(QWidget* parent = nullptr);
    ~My_lineEdit();

signals:
    void clicked();

protected:
    virtual void mousePressEvent(QMouseEvent* event);

private:


};

#endif // MY_LINEEDIT_H
