#include "signals.h"
#include <QPainter>

Signals::Signals()
{

}
QPixmap Signals::GetPixmap(const int ping)
{

    return GetSignalPixmap(GetColor(),GetLineNum(ping));
}

//获取颜色
QColor Signals::GetColor(){

    return  QColor(0xff,0xff,0xff);

}
// 获取线条数量
int Signals :: GetLineNum(const int ping){

    if(ping<=25)
        return 4;         //4格信号
    else if(ping<=50)
        return 3;
    else if (ping<=75)
        return 2;
    else if (ping<=100)
        return 1;
    else
        return 0;

}
//获取信号位图
QPixmap Signals::GetSignalPixmap(const QColor &color, const int lineNum){

    int recWidth  = 26;  // 绘制区域的宽度和高度
    int recHeight = 22;
    int signalWidth  =  recWidth/4;
    int signalHeight = recHeight/4;
    QPixmap pixmap(recWidth,recHeight+2);
    QBrush brush(color);
    pixmap.fill(QColor(0xd9,0xd9,0xd9,0));
    QPainter painter(&pixmap);
    painter.setPen(QColor(0xd9,0xd9,0xd9));

    painter.drawRect(0,            recHeight-signalHeight*1,signalWidth-3,signalHeight*1);
    painter.drawRect(signalWidth*1,recHeight-signalHeight*2,signalWidth-3,signalHeight*2);
    painter.drawRect(signalWidth*2,recHeight-signalHeight*3, signalWidth-3,signalHeight*3);
    painter.drawRect(signalWidth*3,recHeight-signalHeight*4, signalWidth-3,signalHeight*4);


    switch(lineNum)
        {
            case 4:
                painter.setBrush(brush);
                painter.drawRect(0,            recHeight-signalHeight*1, signalWidth-3,signalHeight*1);
                painter.drawRect(signalWidth*1,recHeight-signalHeight*2, signalWidth-3,signalHeight*2);
                painter.drawRect(signalWidth*2,recHeight-signalHeight*3, signalWidth-3,signalHeight*3);
                painter.drawRect(signalWidth*3,recHeight-signalHeight*4, signalWidth-3,signalHeight*4);
            break;
            case 3:
                painter.setBrush(brush);
                painter.drawRect(0,            recHeight-signalHeight*1, signalWidth-3,signalHeight*1);
                painter.drawRect(signalWidth*1,recHeight-signalHeight*2, signalWidth-3,signalHeight*2);
                painter.drawRect(signalWidth*2,recHeight-signalHeight*3, signalWidth-3,signalHeight*3);
            break;
            case 2:
                painter.setBrush(brush);
                painter.drawRect(0,            recHeight-signalHeight*1, signalWidth-3,signalHeight*1);
                painter.drawRect(signalWidth*1,recHeight-signalHeight*2, signalWidth-3,signalHeight*2);
            break;
            case 1:
                painter.setBrush(brush);
                painter.drawRect(0,            recHeight-signalHeight*1, signalWidth-3,signalHeight*1);
            break;
        }
    return pixmap;

}


