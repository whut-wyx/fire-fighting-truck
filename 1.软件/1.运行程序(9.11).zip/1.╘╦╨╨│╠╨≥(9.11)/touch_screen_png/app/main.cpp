#include "mainwidget.h"

#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    mainWidget w;
    w.show();
   // QApplication::setOverrideCursor(Qt::BlankCursor);
    return a.exec();
}
