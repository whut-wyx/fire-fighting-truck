#ifndef HARDWARETEST_H
#define HARDWARETEST_H

#include <QWidget>

namespace Ui {
class HardwareTest;
}

class HardwareTest : public QWidget
{
    Q_OBJECT

public:
    explicit HardwareTest(QWidget *parent = nullptr);
    ~HardwareTest();

private:
    Ui::HardwareTest *ui;
};

#endif // HARDWARETEST_H
