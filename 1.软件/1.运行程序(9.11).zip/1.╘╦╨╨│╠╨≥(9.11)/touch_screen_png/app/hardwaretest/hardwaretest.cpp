#include "hardwaretest.h"
#include "ui_hardwaretest.h"

HardwareTest::HardwareTest(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HardwareTest)
{
    ui->setupUi(this);
}

HardwareTest::~HardwareTest()
{
    delete ui;
}
