#include "dataprocess.h"
#include "rfidwidget/rfidwidget.h"

#include <stdio.h>
#include <QDebug>


static int shm_id = 0;
static int sem_id = 0;

void* shm = NULL;
struct screenStruct *shm_p;

//读写数据

screenStr screen;





DataProcess::DataProcess()
{
    rfid_flag = 0;
    rfid_value = 1;
    screen.rfidFlag = 1;
}


DataProcess::~DataProcess()
{
    quit();
    wait();
}

void DataProcess::setRfidFlag(int rfidValue,int flag)
{
    rfid_value = rfidValue;
    rfid_flag = flag;
    qDebug()<<rfid_value;
}

char *DataProcess::getDataBuff()
{
    return  rwBuff;
}

void DataProcess::run()
{

    while (1) {

        if(rfid_flag){
            //如果为1则写进去
            screen.rfidFlag = (unsigned char)rfid_value;
            qDebug()<<"---while----"<<rfid_value;
            rfid_flag = 0;
        }
       semaphore_P();
       memcpy(rwBuff,shm_p,SHMSIZE);
       if(!screen.rfidFlag){
           memcpy(shm_p,&screen,SHMSIZE);
       }
       qDebug()<<"--------------"<<(screenStr*)(shm_p)->rfidFlag;
       semaphore_v();
       screen.rfidFlag = 1;
       emit datasend();
       sleep(2);
    }
}


//创建共享内存
void creatShm(){
    shm_id = shmget((key_t)2000,SHMSIZE,0666|IPC_CREAT);
    if(shm_id == -1){
        perror("shm failed:");
        return;
    }
    shm = shmat(shm_id,0,0);
   if(shm == (void*)-1 ){
        perror("shmat failed:");
        return;
    }
   shm_p = (struct screenStruct*)shm;
   memset(shm_p,1,sizeof (screenStr));
   //bzero(shm_p,sizeof (screenStr));//置0操作
}
//创建信号量
void creatSem(){
   sem_id = semget((key_t)1000,1,0666|IPC_CREAT);
   if(sem_id == -1){
       perror("sem failed:");
       return;
   }

}

int semaphore_P(){
    //p操作
    struct sembuf sem_b;
    sem_b.sem_num = 0;
    sem_b.sem_op = -1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(sem_id,&sem_b,1) == -1){
        perror("p error:");
        return 0;
    }
    return 1;
}

int semaphore_v(){
    //v操作
    struct sembuf sem_b;
    sem_b.sem_num = 0;
    sem_b.sem_op = 1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(sem_id,&sem_b,1) == -1){
        perror("v error:");
        return 0;
    }
    return 1;
}


