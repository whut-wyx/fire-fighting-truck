#ifndef DATAPROCESS_H
#define DATAPROCESS_H

#include <QThread>
#include <sys/shm.h>
#include <stdio.h>
#include <sys/sem.h>
#include <string.h>

typedef struct screenStruct{
    unsigned char rfidFlag;     //获取rfid标识
    unsigned char door[7];      //开关门状态
    unsigned char distance[3];  //测距
    unsigned char warn[6];      //BBM报警
    unsigned char tool[39];     //器具缺失情况
    //BBM相关值
    unsigned char engine[2];
    unsigned char coolLiquid[2];
    unsigned char oilLevel[2];

    //周围温度和有害气体浓度
    unsigned char fireTemp;
    unsigned char gasRate;

}screenStr;

union semun{
    int val;
    struct semid_ds* buf;
    unsigned short* array;
};
#define SHMSIZE (sizeof(screenStr))

//创建共享内存和信号量
 void creatShm();
 void creatSem();
//创建线程
 void creatRXthreads();
//读取共享内存
 void readShm();
//p操作
int semaphore_P();
//v操作
int semaphore_v();


class DataProcess : public QThread
{
    Q_OBJECT
public:
    DataProcess();
    ~DataProcess();

public slots:
     void setRfidFlag(int rfidValue,int flag);
     char *getDataBuff();
protected:
    virtual void run();
private:
    int rfid_value;
    int rfid_flag;
    char rwBuff[SHMSIZE];
signals:
    void datasend();

};

#endif // DATAPROCESS_H
