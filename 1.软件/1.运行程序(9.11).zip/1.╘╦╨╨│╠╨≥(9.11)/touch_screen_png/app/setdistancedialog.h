#ifndef SETDISTANCEDIALOG_H
#define SETDISTANCEDIALOG_H

#include <QDialog>
#include "keyboarddialog.h"
#include <QTableWidgetItem>

namespace Ui {
class SetDistanceDialog;
}

class SetDistanceDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SetDistanceDialog(QWidget *parent = nullptr);
    ~SetDistanceDialog();
    void getSetDistance();

    float left,right,behind ;


private slots:


    void on_cancelbutton_clicked();

    void on_tableWidget_cellDoubleClicked(int row, int column);
public slots:
     void on_OKbutton_clicked();

signals:


private:
    Ui::SetDistanceDialog *ui;
    int myRow;
    int myColumn;
    KeyBoardDialog *keyboard;
};

#endif // SETDISTANCEDIALOG_H
