#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QTimer>
#include "BBMwidget/bbmwidget.h"
#include "gpswidget/gpswidget.h"
#include "rfidwidget/rfidwidget.h"
#include "hardwaretest/hardwaretest.h"
#include "setdistancedialog.h"
#include "dataprocess.h"



QT_BEGIN_NAMESPACE
namespace Ui { class mainWidget; }
QT_END_NAMESPACE

class mainWidget : public QWidget
{
    Q_OBJECT

public:
    mainWidget(QWidget *parent = nullptr);
    ~mainWidget();

private slots:
    void on_BBMdata_clicked();

    void on_HOMEButton_clicked();

    void on_RFIDdata_clicked();

    void on_Gpsdata_clicked();

    void on_DistanceSet_clicked();

    void doorstatusFlash(int door,int value);

    void doorStatus(unsigned char* doorData);

    void fillData();


public slots:
    void TimerTimeout();
    void runthread();



signals:


private:
    void InitTimeout();

    void distanceJudgeDefined(float leftdata);

    void rightdistanceJudgeDefined(float rightdata);

    Ui::mainWidget *ui;
    BBMWidget *bbmwidget_page;
    GpsWidget *gpswidget_page;
    RFIDWidget *rfidwidget_page;
    HardwareTest *hardwidget_page;
    SetDistanceDialog *setdistancedialog_page;

    QTimer *timer;
    QTimer *timerReadData;
    DataProcess *thread;

    char dataBuff[62];

    QString left,right,behind;
    unsigned char distanceLeft,distanceRight,distanceBehind;

    QString aroundTemp,harmfulGDensity;

};
#endif // MAINWIDGET_H
