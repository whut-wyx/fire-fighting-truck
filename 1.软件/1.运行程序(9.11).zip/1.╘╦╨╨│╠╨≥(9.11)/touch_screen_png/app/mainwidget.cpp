#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "signals.h"
#include <QDate>
#include <QTime>
#include <QDebug>


extern float leftinfo,rightinfo,behindinfo;
extern int RFIDFlag;

mainWidget::mainWidget(QWidget *parent)
    : QWidget(parent),thread(new DataProcess),
     ui(new Ui::mainWidget),setdistancedialog_page(new SetDistanceDialog(this))
{
    ui->setupUi(this);
    ui->badgelabel->setPixmap(QPixmap("://image/badge.jpg"));
    ui->carlabel->setPixmap(QPixmap("://image/car.jpg"));
    //四个按钮跳转页面
    bbmwidget_page = new BBMWidget(this);
    gpswidget_page = new GpsWidget(this);
    rfidwidget_page = new RFIDWidget(this);
    hardwidget_page = new HardwareTest(this);
    timer  = new QTimer;
    timerReadData = new QTimer;

    ui->stackedWidget->addWidget(bbmwidget_page);
    ui->stackedWidget->addWidget(gpswidget_page);
    ui->stackedWidget->addWidget(rfidwidget_page);
    ui->stackedWidget->addWidget(hardwidget_page);

    //rfid触发信号
    connect(rfidwidget_page,&RFIDWidget::rfidFlag,[=](int rfidValue,int rfidFalg){
        thread->setRfidFlag(rfidValue,rfidFalg);

    });
    //线程
    runthread();
    screenStr tempScreen;
    memset(&tempScreen,1,sizeof (screenStr));
    tempScreen.distance[0] = 0;
    tempScreen.distance[1] = 0;
    tempScreen.distance[2] = 0;
    tempScreen.engine[0] = 0 ;
    tempScreen.engine[1] = 0;
    tempScreen.coolLiquid[0] = 0;
    tempScreen.coolLiquid[1] = 0;
    tempScreen.oilLevel[0] = 0;
    tempScreen.oilLevel[1] = 0;
    tempScreen.fireTemp = 0;
    tempScreen.gasRate = 0;

    memcpy(dataBuff,&tempScreen,SHMSIZE);

    //填页面数据
     timerReadData->start(2000);
     connect(timerReadData,&QTimer::timeout,[=](){
           fillData();
     });

   //4G信号强弱
    Signals signal;
    ui->signalsLabel->setPixmap(signal.GetPixmap(30));

    //日期
    ui->dateEdit->setDisplayFormat("yyyy年MM月dd日");
    //时间
    ui->timeEdit->setDisplayFormat("hh:mm:ss");
    InitTimeout();

    //widget边框颜色
    ui->widget_3->setStyleSheet("border:2px solid rgb(105,105,105);border-radius:10px");

    ui->widget_2->setStyleSheet("border:2px solid rgb(105,105,105);border-radius:30px;");

    ui->widget_4->setStyleSheet("border:2px solid rgb(105,105,105);border-radius:30px;");

    ui->widget_6->setStyleSheet("border:2px solid rgb(105,105,105);border-radius:30px;");



}

mainWidget::~mainWidget()
{
    delete ui;
}

//跑共享内存线程
void mainWidget::runthread(){


    creatSem();
    creatShm();
    thread->start();
    connect(thread,&DataProcess::datasend,[=]()
    {
        screenStr* screen = NULL;
        memcpy(dataBuff,thread->getDataBuff(),sizeof (screenStr));
        screen = (screenStr*)dataBuff;
       // for (int i = 0;i<39;i++) {
       //     printf("the rfid 第%d个 is %d\n",i,screen->tool[i]);
       // }
    });

}

//填各模块的数据
void mainWidget::fillData()
{
    screenStr* screen = NULL;
    screen = (screenStr*)dataBuff;
    //BBM
    bbmwidget_page->BBMdata(screen->warn,screen->engine,screen->coolLiquid,screen->oilLevel);

    /*************首页底盘数据填写**********/
    ui->motorSpeed->setText(QString("%1").arg(screen->engine[0]*100+screen->engine[1]));
    ui->coodTemp->setText(QString("%1.%2").arg((int)screen->coolLiquid[0]).arg((int)screen->coolLiquid[1]));
    ui->oilLevel->setText(QString("%1.%2").arg(screen->oilLevel[0]).arg(screen->oilLevel[1]));

    if((QString("%1").arg(screen->engine[0]*100 + screen->engine[1])).toFloat() == 0){
        ui->motorSpeed->setText("");
    }
    if((QString("%1.%2").arg(screen->coolLiquid[0]).arg(screen->coolLiquid[1])).toFloat() == 0){
        ui->coodTemp->setText("");
    }
    if((QString("%1.%2").arg(screen->oilLevel[0]).arg(screen->oilLevel[1])).toFloat() == 0){
        ui->oilLevel->setText("");
    }

    //开关门
    doorStatus(screen->door);


    //RFID
    rfidwidget_page->getRfidData(screen->tool);
    //遍历rfid数据 如果有报警按钮字体变为红色
    for (int i=0;i<39;i++) {
        if(screen->tool[i]){
          ui->RFIDdata->setStyleSheet("color: red");
        }
    }

   /*************周围温度和有害气体浓度**********/
    ui->aroundTempture->setText(QString("%1").arg(screen->fireTemp));
    ui->harmfulGasD->setText(QString("%1").arg(screen->gasRate));
    if(QString("%1").arg(screen->fireTemp).toFloat() == 0){
        ui->aroundTempture->setText("");
    }
    if(QString("%1").arg(screen->gasRate).toFloat() == 0){
        ui->harmfulGasD->setText("");
    }

    /*************测距***********/
    distanceLeft   = screen->distance[0];
    distanceRight  = screen->distance[1];
    distanceBehind = screen->distance[2];
    left   = QString("%1.%2").arg((int)((int)distanceLeft/10)).arg((int)((int)distanceLeft%10));
    right  = QString("%1.%2").arg((int)((int)distanceRight/10)).arg((int)((int)distanceRight%10));
    behind = QString("%1.%2").arg((int)((int)distanceBehind/10)).arg((int)((int)distanceBehind%10));
    /*****左侧*****/
    if(left.toFloat()>2){
        ui->leftDistance->setText("");
        ui->label_9->clear();
        distanceJudgeDefined(left.toFloat());
    }
    else if (left.toFloat()== 0){
         ui->leftDistance->setText("");
    }
    else{
        ui->leftDistance->setText(left);
        distanceJudgeDefined(left.toFloat());
    }
    /*****右侧*****/
    if(right.toFloat()>2){
        ui->rightDistance->setText("");
        ui->label_15->clear();
        rightdistanceJudgeDefined(right.toFloat());
    }
    else if (right.toFloat()== 0){
         ui->rightDistance->setText("");
    }
    else{
        ui->rightDistance->setText(right);
        rightdistanceJudgeDefined(right.toFloat());
    }


    /*if((left.toFloat()<3&&left.toFloat()>0)&&(right.toFloat()<3&&right.toFloat()>0)){
        ui->leftDistance->setText(left);
        ui->rightDistance->clear();
        ui->rightDistance->setText(right);
        //ui->behindDistance->clear();
        //ui->behindDistance->setText(behind);
        distanceJudgeDefined(left.toFloat(),right.toFloat());

    }
    else if((left.toFloat()>3)&&(right.toFloat()<3&&right.toFloat()>0)){
        ui->leftDistance->setText("");
        ui->rightDistance->clear();
        ui->rightDistance->setText(right);
        //ui->behindDistance->clear();
        //ui->behindDistance->setText(behind);
        distanceJudgeDefined(left.toFloat(),right.toFloat());

    }
    else if((left.toFloat()<3&&left.toFloat()>0)&&(right.toFloat()>3)){
        ui->leftDistance->setText(left);
        ui->rightDistance->clear();
        ui->rightDistance->setText("");
        //ui->behindDistance->clear();
        //ui->behindDistance->setText(behind);
        distanceJudgeDefined(left.toFloat(),right.toFloat());
    }

    else if(left.toFloat()==0&&right.toFloat()==0) {
        ui->leftDistance->setText("");
        ui->rightDistance->setText("");
        //ui->behindDistance->setText("");
        ui->distancewarn->clear();
        ui->distancewarnRight->clear();

    }
    else{
        ui->leftDistance->setText("");
        ui->rightDistance->setText("");
        //ui->behindDistance->setText("");
        ui->distancewarn->clear();
        ui->distancewarnRight->clear();
    }*/

}


//页面切换
void mainWidget::on_HOMEButton_clicked()
{
  ui->stackedWidget->setCurrentIndex(0);
}


void mainWidget::on_BBMdata_clicked()
{
  ui->stackedWidget->setCurrentWidget(bbmwidget_page);

}

void mainWidget::on_RFIDdata_clicked()
{
    ui->stackedWidget->setCurrentWidget(rfidwidget_page);
}

void mainWidget::on_Gpsdata_clicked()
{
   ui->stackedWidget->setCurrentWidget(gpswidget_page);
}

//打开测距条件的设置
void mainWidget::on_DistanceSet_clicked()
{
    setdistancedialog_page->setModal(false);
    setdistancedialog_page->show();
}
//Gif
void mainWidget::doorstatusFlash(int door,int value)
{
    int temp = door;
    switch(temp){
    case 0:
           if(value){

               ui->door1->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door1->setPixmap(QPixmap("://image/green.jpg"));
           }
        break;
        case 1:
           if(value){

               ui->door2->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door2->setPixmap(QPixmap("://image/green.jpg"));
           }
        break;
        case 2:
           if(value){

               ui->door3->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door3->setPixmap(QPixmap("://image/green.jpg"));
           }
        break;
        case 3:
           if(value){

               ui->door4->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door4->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
        case 4:
           if(value){

               ui->door5->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door5->setPixmap(QPixmap("://image/green.jpg"));
           }
          break;
      /* case  5:
           if(value){

               ui->door6->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door6->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;
       case  6:
           if(value){

               ui->door7->setPixmap(QPixmap("://image/red.png"));
           }
           else{
               ui->door7->setPixmap(QPixmap("://image/green.jpg"));
           }
           break;*/
       default:break;
   }

}

//开关门状态
void mainWidget::doorStatus(unsigned char* doorData)
{
    unsigned char door[7];
    memset(door,1,7);
    memcpy(door,doorData,7);
    for (int i = 0;i<7;i++) {
        doorstatusFlash(i,(int)door[i]);
    }
}



        /****司机自定义的距离判断****/
//左侧距离判断
void mainWidget::distanceJudgeDefined(float leftdata)
{
   // qDebug()<<leftinfo;
    if(leftdata<leftinfo){
    ui->distancewarn->setPixmap(QPixmap("://image/warnstatic.jpg"));
    }
    else{
    ui->distancewarn->setPixmap(QPixmap("://image/green.jpg"));
    }


}
//右侧距离判断
void mainWidget::rightdistanceJudgeDefined(float rightdata){

    if(rightdata<rightinfo){
    ui->distancewarnRight->setPixmap(QPixmap("://image/warnstatic.jpg"));
    }
    else{
    ui->distancewarnRight->setPixmap(QPixmap("://image/green.jpg"));
    }
}
//定时器
void mainWidget::InitTimeout()
{
    connect(timer,SIGNAL(timeout()),this,SLOT(TimerTimeout()));
    timer->start(500);
}

void mainWidget::TimerTimeout()
{
     ui->dateEdit->setDate(QDate::currentDate());
     ui->timeEdit->setTime(QTime::currentTime());
}






