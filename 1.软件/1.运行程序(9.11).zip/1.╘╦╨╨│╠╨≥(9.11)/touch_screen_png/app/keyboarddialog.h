#ifndef KEYBOARDDIALOG_H
#define KEYBOARDDIALOG_H

#include <QDialog>
#include <QLineEdit>

namespace Ui {
class KeyBoardDialog;
}

class KeyBoardDialog : public QDialog
{
    Q_OBJECT

public:
    explicit KeyBoardDialog(QWidget *parent = nullptr);
    ~KeyBoardDialog();
signals:
    void outputNumToTable(const QString& numStr);

private slots:
    void on_Backspace_clicked();

    void on_num1_clicked();

    void on_OK_clicked();

    void on_num2_clicked();

    void on_num3_clicked();

    void on_num4_clicked();

    void on_num5_clicked();

    void on_num6_clicked();

    void on_num7_clicked();

    void on_num8_clicked();

    void on_num9_clicked();

    void on_num0_clicked();

    void on_pointer_clicked();

    void on_pushButton_clicked();

private:
    Ui::KeyBoardDialog *ui;
    QLineEdit *lineEdit;
    QString strContent;
};

#endif // KEYBOARDDIALOG_H
