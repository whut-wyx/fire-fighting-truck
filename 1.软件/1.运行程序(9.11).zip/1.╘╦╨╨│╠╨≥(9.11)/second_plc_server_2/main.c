#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <time.h>

#define PORT 8000
#define MAXLINE 1000
#define IP "127.0.0.1"

union semun{
    int val;
    struct semid_ds* buf;
    unsigned short* array;
};

unsigned char plcSendData[3] = {0};
unsigned char plcRecvData[20] = {0};
unsigned char recvBuff[3] = {0};
#define SHMSIZE (sizeof(plcSendData) + sizeof(plcRecvData))
#define RECVSIZE (sizeof(plcRecvData))

#define msleep(ms) usleep((ms)*1000)
void* shm_void = NULL;
unsigned char* shmBuff;                        //指向共享内存的指针
unsigned char poll_plcData[SHMSIZE] = {0};          //用来做数据交换 接收和发送
unsigned char push_plcData[RECVSIZE] = {0};

//存储从plc过来的结构体数据

static int sem_id = 0;
static int shm_id = 0;

//接收并发送客户端数据
int recvFromPlc(int arg);
//recv客户端数据
int recvClientData(int socketfd,unsigned char* buff,int needlen,int* recvlen);
//创建共享内存
void createShm();
//创建信号量
void createSem();
//初始化信号量
int set_semvalue();
//P操作
int semaphore_p();
//V操作
int semaphore_v();

int main()
{
    //初始化共享内存和信号量
    createShm();
    createSem();
SERVERAGAIN:
    {
        int socketfd,connectfd;
        int opt = 1;
        int status = 0;
        struct sockaddr_in servaddr;
        if((socketfd = socket(AF_INET,SOCK_STREAM,0)) == -1){
            perror("plc server error:");
            exit(0);
        }
        setsockopt(socketfd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof (opt));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port = htons(PORT);

        //将本地地址绑定在套接字上
        if(bind(socketfd,(struct sockaddr*)&servaddr,sizeof (servaddr)) == -1){
            perror("plc bind error:");
            exit(0);
        }
        printf("绑定\n");
        //监听套接字
        if(listen(socketfd,800) == -1){
            perror("plc listen error:");
            exit(0);
        }
        printf("监听\n");
        /** 设定管道初始液位*/
        while(1){
            if((connectfd = accept(socketfd,(struct sockaddr*)NULL,NULL)) == -1){
                //perror("plc accpet error:");
                printf("请求失败\n");
                continue;
            }
            //接受并发送数据
            printf("connectfd is %d\n",connectfd);
            status = recvFromPlc(connectfd);
            printf("status is %d\n",status);
            if(status == -1 || status == -2){
                break;
            }
        }
        shutdown(socketfd,SHUT_RDWR);
        close(socketfd);
    }
    msleep(1000);
    goto SERVERAGAIN;
    shmdt(shm_void);
    shmctl(shm_id,IPC_RMID,0);
    return 0;
}

void createShm(){

    shm_id = shmget((key_t)2100,SHMSIZE,0666|IPC_CREAT); //得到一个共享内存标识符或创建一个共享内存对象
    if(shm_id == -1){
        perror("server shm falied:");
        return ;
    }
    shm_void = shmat(shm_id,0,0);  //shmat函数：把共享内存区对象映射到调用进程的
    memset(shmBuff,0,SHMSIZE);
    //设定初始值
    plcRecvData[0] = 15;
    plcRecvData[1] = 15;
    memcpy(shmBuff+sizeof (plcSendData),plcRecvData,RECVSIZE);
    return;
}

void createSem(){
    sem_id = semget((key_t)1100,1,0666|IPC_CREAT);
    return;
}

int set_semvalue(){
    //初始化信号量
    union semun sem_union;
    sem_union.val = 1;
    if(semctl(sem_id,0,SETVAL,sem_union) == -1){
        printf("init sem:");
        return 0;
    }
    return 1;
}

int semaphore_p(){
    //p操作
    struct sembuf sem_b;
    sem_b.sem_num = 0;          //下标为0的信号量
    sem_b.sem_op = -1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(sem_id,&sem_b,1) == -1){
        perror("p error:");
        return 0;
    }
    return 1;
}

int semaphore_v(){
    //v操作
    struct sembuf sem_b;
    sem_b.sem_num = 0;
    sem_b.sem_op = 1;
    sem_b.sem_flg = SEM_UNDO;
    if(semop(sem_id,&sem_b,1) == -1){
        perror("v error:");
        return 0;
    }
    return 1;
}

int recvFromPlc(int arg){semaphore_p;


    int socketfd = arg;
    int status = 0;
    int recvLen;
    int continueErr = 0;
    int sendSize = sizeof (plcSendData);
    while (1) {
        status = recvClientData(socketfd,recvBuff,sendSize,&recvLen);
        if(status == -2){ //超时
            continue ;
        }else if (status == -1) {
            //perror("plc recv error:");
            break ;
        }
        if(recvLen == 0){
            continueErr++;
            if(continueErr > 40){
                perror("plc recv error:");
                break;
            }
            sleep(2);
            continue;
        }
        continueErr = 0;
        {
            //接收来自plc的两个数据 管道压力和开度
            memcpy(plcSendData,recvBuff,sizeof(plcSendData));
            //从共享内存拿数据
            semaphore_p();
            memcpy(poll_plcData,shmBuff,SHMSIZE);                     //读数据
            memcpy(shmBuff,plcSendData,sizeof(plcSendData));          //写数据
            semaphore_v();
            //发送数据
            memcpy(plcRecvData,poll_plcData+sizeof (plcSendData),RECVSIZE);
            send(socketfd,(char*)plcRecvData,RECVSIZE,0);
            for(int i = 0;i < 3;i++){
                printf("接收到的第%d个数据：%d\n",i,plcSendData[i]);
            }
            for(int i = 0;i < 20;i++){
                printf("发送的第%d个数据:%d\n",i,plcRecvData[i]);
            }
            printf("888888888\n");
        }
    }
}

int recvClientData(int socketfd,unsigned char* buff,int needlen,int* recvlen){
    int iErr = 0;
    int bytes_read = 0,bytes_left = needlen,totalr = 0;
    char *ptr = (char*)buff;
    fd_set rfds,maskfds;
    struct timeval timeout = {3,0};
    FD_ZERO(&rfds); //清空文件标识符
    FD_SET(socketfd,&rfds); //将文件标识符放入集合中
    if(bytes_left > 0){
        maskfds = rfds;
        iErr = select(socketfd+1,&maskfds,NULL,NULL,&timeout);
        if(iErr <=0 ){
           if (iErr == 0)
               return -2; //超时
           else
               return -1; //错误
        }
        if(FD_ISSET(socketfd,&maskfds))
        {
             printf("1111\n");
            bytes_read = recv(socketfd,ptr,bytes_left,0);
            printf("2222\n");
            if(bytes_read < 0){
                if(errno = EINTR) //操作信号被中断
                    bytes_read = 0;
                else
                    return -1;
            }
            bytes_left -= bytes_read;
            ptr += bytes_read;
            totalr += bytes_read;
        }
    }
    *recvlen = totalr;
    ptr = (char*)buff;
    ptr[totalr] = '\0';
    return 0;
}
